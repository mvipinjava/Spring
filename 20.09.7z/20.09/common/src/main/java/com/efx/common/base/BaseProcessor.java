package com.efx.common.base;

import java.util.Map;
import java.util.logging.Logger;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.efx.common.constants.TopicNameConstants;
import com.efx.common.logging.LogManager;
import com.efx.common.pubsub.Publisher;
import com.efx.common.pubsub.PublisherManager;
import com.efx.common.pubsub.Subscriber;
import com.efx.common.pubsub.SubscriberManager;
import com.efx.common.shared.TransactionMap;
import com.efx.common.utils.TransactionUtils;

import javax.annotation.PostConstruct;

import lombok.*;

public abstract class BaseProcessor implements TopicNameConstants
{
	public Logger logger = null;

	@Getter
	String name;
    String inputTopic;
    
    @Getter
    @Setter
    String outputSuffix = PROCESSOR_TOPIC_SUFFIX;
    
    Subscriber sub;
    Publisher pub;
    
    TransactionUtils transactionUtils;
    
    @Getter
    @Setter
    PublisherManager mgr = PublisherManager.getInstance();
    SubscriberManager subMgr = SubscriberManager.getInstance();

    public BaseProcessor(String name)
    {
    	this.name = name;
    }
    
    @PostConstruct
    public void init ()
    {
//    	System.err.println("Got to init");
 
    	logger = LogManager.getInstance().getLogger(this.getClass().getName());

    	// Open up the Pub/Sub topic
    	pub = mgr.getPublisher(REPLY_TOPIC_NAME);
    	
    	if (transactionUtils == null)
    	{
    		transactionUtils = TransactionUtils.getInstance();
    	}
    	
    	inputTopic = name + PROCESSOR_TOPIC_SUFFIX;
    	sub = subMgr.getSubscriber(inputTopic);
    	sub.startConsumer(s -> onMessage(s));
    	local_init();
    }
    
    public void local_init() { }

	public void onMessage(Object obj)
	{
		String sha = (String) obj;
		// We received a string from a Hazelcast Subscriber Topic
		
//		System.err.println("Got here via Hazelcast");
		_process(sha);
	}

    @PostMapping("/process/{sha}")
    public void process (@RequestParam @NonNull String sha)
    {
    	// We received a string via REST - this should only be used in testing
    	
//    	System.err.println("Got here via REST");
    	_process(sha);
    }
    
    public TransactionMap getMapBySha (String sha)
    {
    	return transactionUtils.getTransactionMap(sha);
    }
    
    void _process (String sha)
    {
    	processRequest (sha, getMapBySha(sha));
    }

    public abstract void processRequest (String sha, TransactionMap tMap);
    
    public void sendResponse (String sha, Map<String, String> responseData)
    {
    	transactionUtils.addResponseMap(sha, responseData);
    	// modify the TransactionMap with the RequestService, using responseData
    	pub.publish(sha);
    }
    
    public void publishToNextProcessor (String sha, String name)
    {
    	String outputTopic = name + outputSuffix;
    	Publisher output = mgr.getPublisher(outputTopic);
    	output.publish(sha);
    }
}
