package com.efx.common.base;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.annotation.PostConstruct;

import com.efx.common.constants.AllConstants;
import com.efx.common.logging.LogManager;
import com.efx.common.pubsub.Publisher;
import com.efx.common.pubsub.PublisherManager;
import com.efx.common.pubsub.Subscriber;
import com.efx.common.pubsub.SubscriberManager;
import com.efx.common.shared.TransactionWrapper;
import com.hazelcast.core.HazelcastInstance;

import lombok.Getter;
import lombok.Setter;

public abstract class BaseRequester implements AllConstants
{
	public Logger logger = null;

	@Getter
	String name;
	@Getter
	String inputTopicName;
	@Setter
	String outputTopicName = REQUEST_TOPIC_NAME;
	
    PublisherManager mgr = PublisherManager.getInstance();
    SubscriberManager subMgr = SubscriberManager.getInstance();

    Subscriber inputTopic;
    Publisher outputTopic;
    
    HazelcastInstance hazelcastInstance;
    
    int relativeCounter = 1;
    
    @Getter
    ExecutorService executor;
    
    int serverPortNumber = 0;
	ServerSocket serverSocket;
	
    @Getter
    Map<String, Object> connectionData = new HashMap<String, Object>();
    
    public BaseRequester(String name, int serverPortNumber, HazelcastInstance hazelcastInstance)
    {
    	this.hazelcastInstance = hazelcastInstance;
    	this.name = name;
    	this.serverPortNumber = serverPortNumber;
    	this.inputTopicName = name + REPLY_TOPIC_SUFFIX;
    }
    
    @PostConstruct
    public void init ()
    {
 //   	System.err.println("Got to init");

    	logger = LogManager.getInstance().getLogger(this.getClass().getName());

    	inputTopic = subMgr.getSubscriber(inputTopicName);
    	outputTopic = mgr.getPublisher(outputTopicName);

    	// Add a Listener to the inputTopic
    	inputTopic.startConsumer(s -> onMessage(s));
    	
    	executor = Executors.newFixedThreadPool(1000);

    	if (this.serverPortNumber != 0)
    	{
        	executor.execute(() -> openServerSocket());
    	}
    }
    
    synchronized int getRelativeCounter ()
    {
    	int retval = relativeCounter;
    	if (relativeCounter == Integer.MAX_VALUE)
    	{
    		relativeCounter = 1;
    	} else {
    		relativeCounter++;
    	}
    	return retval;
    }
    
    public void openServerSocket()
    {
		logger.info("Creating Socket for host...");
		try {
			serverSocket = new ServerSocket(serverPortNumber);		// define in config file?!?!?
		} catch (IOException e) {
			e.printStackTrace();
		}
		Runtime.getRuntime().addShutdownHook(new Thread(() -> closeServerSocket()));
		
		acceptConnections(serverSocket);
    }
	
	void closeServerSocket()
	{
		try {
			serverSocket.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Accepts incoming connections and schedules task
	 * 
	 * @param serverSocket
	 */
	public void acceptConnections(ServerSocket serverSocket) {
		try {
			logger.info("Accepting SSL Socket Connections at host on port: " + serverSocket.getLocalPort());
			while (true) {
				Socket socket = serverSocket.accept();
				logger.info("Accepted connection from" + socket.getRemoteSocketAddress());
				executor.execute(() -> onConnection(socket)); 
			}
		} catch (IOException e) {
			logger.log(Level.SEVERE, e, () -> "Unable to instantiate a ServerSocket on port: " + serverSocket.getLocalPort());
		} catch (Exception e) {
			logger.log(Level.SEVERE, e, () -> "Unable to bind to port " + serverSocket.getLocalPort());
		}
	}

	public void closeConnection(Object connection)
	{
		// default does nothing. Override as needed for Requesters
	}
	
	public void onConnection(Object connection)
	{
		Object data = readData (connection);
		Map<String, String> map = getRequestMap (data);
		processData (map, connection);
	}
	
	public Object processData (Map<String, String> map, Object connection)
	{
		int counter = getRelativeCounter();
		map.put(TM_REQUESTER_NAME, name);
		map.put(TM_RELATIVE_COUNTER, "" + counter);
		modifyRequestMap (map);
		return storeDataAndPublish(counter, map, connection);
	}
	
	public Object storeDataAndPublish(int counter, Map<String, String> map, Object connection)
	{
		connectionData.put("" + counter, connection);
		outputTopic.publish(map);
		return null;
	}
	
	public Object retrieveDataConnection(TransactionWrapper wrapper)
	{
		Map<String, String> mapData = wrapper.getTransactionMap();
		try
		{
			String counter = mapData.get(TM_RELATIVE_COUNTER);
			return connectionData.remove(counter);
		} catch (NumberFormatException e) {
			return null;
		}
	}
	
	public Object readData(Object connection)
	{
		// default does nothing. Override as needed for Requesters
		return null;
	}
	
	public boolean writeData(Object connection, Object response)
	{
		// default does nothing. Override as needed for Requesters
		return true;
	}
	
	public abstract Map<String, String> getRequestMap(Object data);
	
	public abstract Object getResponseFromMap (TransactionWrapper wrapper);
	
	public void modifyRequestMap(Map<String, String> map)
	{
		// the default is to do nothing
		// Requesters that need to add fields need to override this method
	}
	
	// this is the response at the end of processing
	public void onMessage(Object obj)
	{
		// We received a response map from a Hazelcast Topic
//		System.err.println("Got here via Hazelcast");
		
		TransactionWrapper wrapper = (TransactionWrapper) obj;
		
		// get connection data based on info in this mapData
		Object connection = retrieveDataConnection(wrapper);
		
		Object response = getResponseFromMap (wrapper);
		
		boolean status = writeData (connection, response);
		if (!status)
		{
			// TODO - check for errors, here			
		} 
		closeConnection (connection);
	}
}
