package com.efx.common.base;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.logging.Logger;

import javax.annotation.PostConstruct;

import org.jpos.iso.ISOBasePackager;
import org.jpos.iso.ISOComponent;
import org.jpos.iso.ISOException;
import org.jpos.iso.ISOMsg;
import org.jpos.iso.packager.GenericPackager;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.efx.common.constants.*;
import com.efx.common.logging.LogManager;
import com.efx.common.pubsub.Publisher;
import com.efx.common.pubsub.PublisherManager;
import com.efx.common.pubsub.Subscriber;
import com.efx.common.pubsub.SubscriberManager;
import com.efx.common.shared.TransactionMap;
import com.efx.common.utils.TransactionUtils;

import lombok.*;

public abstract class BaseSubmitter implements TopicNameConstants,TransactionMapConstants
{
	public Logger logger = null;

	String name;
    String inputTopic;
    
    String xmlFileName;
    
    int port;
    
    ServerSocket serverSocket;
    boolean running;
    boolean verbose = true;

    // this variable indicates whether we are logically connected to the network (loged in, etc)
    Boolean isConnected;

    // this variable being non null incates we are physically connected to the network
    Socket socket;

    String outputSuffix = PROCESSOR_TOPIC_SUFFIX;
    
    Subscriber sub;
    Publisher pub;
    
    TransactionUtils transactionUtils;
    
    SubmitterUtils submitterUtils;
    
    ExecutorService executor;

    @Getter
    public static ISOBasePackager packager;
    
    PublisherManager mgr = PublisherManager.getInstance();
    SubscriberManager subMgr = SubscriberManager.getInstance();

    Map<String, ConnectionDetails> detailsMap = new HashMap<String, ConnectionDetails>();
    
    public BaseSubmitter(String name, int port, String xmlFileName)
    {
    	this.name = name;
    	this.port = port;
    	this.xmlFileName = xmlFileName;
    }
    
    @PostConstruct
    public void init ()
    {
//    	System.err.println("Got to init");
 
    	logger = LogManager.getInstance().getLogger(this.getClass().getName());

    	// Open up the Pub/Sub topic
    	pub = mgr.getPublisher(RESPONSE_TOPIC_NAME);
    	
    	if (transactionUtils == null)
    	{
    		transactionUtils = TransactionUtils.getInstance();
    	}
    	
    	if (submitterUtils == null)
    	{
    		submitterUtils = new SubmitterUtils();
    	}
    	
    	inputTopic = name + SUBMITTER_TOPIC_SUFFIX;
    	sub = subMgr.getSubscriber(inputTopic);
    	sub.startConsumer(s -> onMessage(s));
    	packager = initializeFormatter(this.xmlFileName);

    	local_init();
    	running = true;
    	executor.execute(() -> establishConnection());
		executor.execute(() -> listenForResponses());
    }
    
    public void local_init() { }

    public void exit ()
    {
    	System.exit(1);
    }
    
    public abstract ISOMsg getLoginRequest ();
    
    public void establishConnection()
    {
		try {
			serverSocket = new ServerSocket(port);
		} catch (IOException e1) {
			e1.printStackTrace();
			exit();
		}

		while (running)
    	{
			try {
				socket = serverSocket.accept();
				ISOMsg login = getLoginRequest();
				sendRequest (login);
			} catch (IOException e) {
				e.printStackTrace();
			}
    	}
    }
    
    public void onMessage(Object obj)
	{
		String sha = (String) obj;
		// We received a string from a Hazelcast Subscriber Topic
		
//		System.err.println("Got here via Hazelcast");
		_process(sha);
	}

    @PostMapping("/process/{sha}")
    public void process (@RequestParam @NonNull String sha)
    {
    	// We received a string via REST - this should only be used in testing
    	
//    	System.err.println("Got here via REST");
    	_process(sha);
    }
    
    public TransactionMap getMapBySha (String sha)
    {
    	return transactionUtils.getTransactionMap(sha);
    }
    
    void _process (String sha)
    {
    	try {
			processRequest (sha, getMapBySha(sha));
		} catch (ISOException e) {
			e.printStackTrace();
		}
    }

    public abstract String getTransactionKeyValue (ISOMsg message);
    public abstract String getTransactionKeyValueFromMap (TransactionMap message);

    public void processRequest (String sha, TransactionMap tMap) throws ISOException
    {
    	String uniqueId = getTransactionKeyValueFromMap(tMap);
		ConnectionDetails details = new ConnectionDetails(uniqueId);
		detailsMap.put(uniqueId, details);

		ISOMsg message = createMessageFromMap (tMap);
 
		// send data to network
	   	sendRequest (message);

		// now wait for the response
		try {
			synchronized (details)
			{
				details.wait();
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
    	// get ISOMsg
    	Map<String, String> responseMap = createMapFromMessage("", details.getResponse(), details.getResponse());
    	sendResponse (sha, responseMap);
    }
    
   public void sendResponse (String sha, Map<String, String> responseData)
    {
    	
    	transactionUtils.addResponseMap(sha, responseData);
    	// modify the TransactionMap with the RequestService, using responseData
    	pub.publish(sha);
    }
    
    public void publishToNextProcessor (String sha, String name)
    {
     	pub.publish(sha);
    }
    
    public abstract Map<String, String> getRequestMap (Map<String, String> originalMap);
    public abstract Object getResponseMsg (ISOMsg originalMsg, Boolean isConnected);
    
    // override this if you need to add or remove network-specific fields
    ISOMsg createMessageFromMap (Map<String, String> originalMap) throws ISOException
    {
    	Map<String, String> map = getRequestMap (originalMap);
    	
    	ISOMsg retval = new ISOMsg();
    	retval.setPackager(packager);
    	for (String key : map.keySet())
    	{
    		try
    		{
	    		float keyValue = Float.parseFloat(key);
	    		if (keyValue < 129.0f)
	    		{
	    			// skip our internal use fields
	    			retval.set(key, map.get(key));
	    		}
    		} catch (NumberFormatException e) {
    			// shouldn't happen
    			e.printStackTrace();
    		}
    	}
    	return retval;
    }
    
    // override this if any network-specific fields need to be added or removed
    Map<String, String> createMapFromMessage (String keyPrefix, ISOMsg message, ISOMsg outterMsg)
    {
    	Map<String, String> retval = new HashMap<String, String> ();
        ISOComponent c;

        @SuppressWarnings("unchecked")
		Map<Integer,Object> fields = message.getChildren();
        for (int fieldNumber : fields.keySet())
        {
        	c = message.getComponent(fieldNumber);
       		String fieldString = keyPrefix + c.getFieldNumber();
            if (c != null)
            {
            	if (c instanceof ISOMsg)
            	{
            		ISOMsg innerMsg = (ISOMsg) c;
             		if (innerMsg.getChildren().size() > 0)
            		{
            			Map<String, String> innerMap = createMapFromMessage (fieldString + ".", innerMsg, outterMsg);
            			retval.putAll(innerMap);
            		}
        		} else {
        			retval.put(fieldString, outterMsg.getString(fieldString));
            	}
            }
    	}
    	return retval;
    }
    
    ISOBasePackager initializeFormatter(String xml)
    {
    	ISOBasePackager retval = null;
    	try {
			retval =  new GenericPackager(xml);
		} catch (ISOException e) {
			e.printStackTrace();
		}
    	return retval;
    }
    
    void sendRequest(ISOMsg message)
    {
    	try {
			sendRequestByteArray (message.pack());
		} catch (ISOException e1) {
			e1.printStackTrace();
		}
    }
    
    void sendRequestByteArray(byte[] bytes)
    {
    	OutputStream os;
		try {
			os = this.socket.getOutputStream();
	    	os.write(bytes);
	    	os.flush();
		} catch (Exception e) {
			e.printStackTrace();
		}
   	
    }
    
    void listenForResponses()
    {
		DataInputStream in = null;
    	while (running)
    	{
			try {
				if (socket != null)
				{
					in = new DataInputStream(socket.getInputStream());
					byte[] bytes = new byte[500];
					int count = in.read(bytes);
					if (count > 0)
					{
						byte[] newBytes = new byte[bytes.length];
						System.arraycopy(bytes, 0, newBytes, 0, bytes.length);
						executor.execute(() -> parseResponse(newBytes));
					}
					continue;
				}
	 		} catch (IOException e) {
	 			e.printStackTrace();
	 			socket = null;
	 		}
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e1) { }
 		}
    }
    
    public abstract byte[] removeHeaderAndFooterFromDataReceived (byte[] bytes);

    void parseResponse (byte[] bytes)
    {
    	bytes = removeHeaderAndFooterFromDataReceived(bytes);
		try {
			ISOMsg message = new ISOMsg();
			message.setPackager(packager);
			message.unpack(bytes);
			
			submitterUtils.logFieldsReceived(message, logger, verbose);

			Object obj = getResponseMsg(message, isConnected);
			// this might be a response to a request, or it could be some other incoming message (byte[])
			// if null, no response came in and no message needs to go out
			if (obj == null)
			{
				return;
			}
			
			if (obj instanceof ISOMsg)
			{
				// this is a response to a request
				message = (ISOMsg) obj;
				
				// get connection data based on info in this mapData
				String uniqueId = getTransactionKeyValue(message);
				ConnectionDetails details = detailsMap.get(uniqueId);
				detailsMap.remove(uniqueId);
				
				details.response = message;
				synchronized (details)
				{
					details.notify();
				}
			}
			if (obj instanceof byte[])
			{
				// send this response to the network
				this.sendRequestByteArray((byte[]) obj);
			}
		} catch (ISOException e) {
			e.printStackTrace();
		}
    }
    
	@Getter
    @Setter
    class ConnectionDetails
    {
		String uniqueId;		// TM_UNIQUE_REQUEST_ID
    	ISOMsg response;
    	
    	public ConnectionDetails (String uniqueId)
    	{
    		this.uniqueId = uniqueId;
    	}
    }
    

//	public static void main (String[] args) throws ISOException
//	{
//		BaseSubmitter submitter = new BaseSubmitter("foo", "bar");
//		
//		Map<String, String> map = new HashMap<String, String> ();
//		map.put (TM_MERCHANT_NUMBER, "123");
//		map.put(TM_UNIQUE_REQUEST_ID, "789");
//		map.put(TM_RESPONSE_CODE, "done");
//		
//		ISOMsg message = submitter.createMessageFromMap (map);
//		Map<String, String> newMap = submitter.createMapFromMessage("", message, message);
//		System.err.println ("Done");
//	}
}
