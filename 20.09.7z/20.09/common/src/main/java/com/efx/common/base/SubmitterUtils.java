package com.efx.common.base;

import java.util.Calendar;
import java.util.TimeZone;
import java.util.logging.Logger;

import javax.xml.bind.ValidationException;

import org.apache.commons.lang3.ArrayUtils;
import org.jpos.iso.ISOException;
import org.jpos.iso.ISOMsg;
import org.jpos.iso.ISOUtil;

import com.efx.common.constants.*;
import com.efx.common.logging.LogManager;

public class SubmitterUtils implements TransactionMapConstants
{
	public Logger logger = null;

	public SubmitterUtils ()
	{
		logger = LogManager.getInstance().getLogger(this.getClass().getName());
	}
	
	public void logFieldsReceived(ISOMsg message, Logger logger, boolean verbose)
    {
		for (int i = 1; i <= message.getMaxField(); i++)
		{
			String dataElements = new String();
            if (message.hasField(i)) 
            {
    			if (verbose)
    			{
    				System.out.printf("Field (%s) = %s%n", i, message.getString(i));
    			}
            	
				switch (i) {
					case 2:
						dataElements = panMask(message.getString(i));
						break;
					case 35:
						dataElements = track2Mask(message.getString(i));
						break;
					case 52:
						dataElements = pinMask(message.getString(i));
						break;
					default:
						dataElements = message.getString(i);
						break;
				}

				StringBuilder dataElementsLog = new StringBuilder();
				dataElementsLog.append("From Pulse >[Field]: ");
				dataElementsLog.append(i);
				dataElementsLog.append(" [Length]: ");
				dataElementsLog.append(message.getString(i).length());
				dataElementsLog.append(" [Value]: ");
				dataElementsLog.append(dataElements);
				logger.info(dataElementsLog.toString());
            }
		}
		if (verbose)
		{
			System.out.println("----------------------------------------------------------------------------------------");
		}
    }

	public String panMask(String pan) {
		String panMasked = null;
		if (!pan.isEmpty()) {
			StringBuilder s = new StringBuilder(pan);
			for (int j = 6; j < pan.length() - 4; j++) {
				s.setCharAt(j, '*');
			}
			panMasked = s.toString();
		}
		return panMasked;
	}

	public String track2Mask(String trackData) {
		String trackDataMasked = null;
		if (!trackData.isEmpty()) {
			StringBuilder s = new StringBuilder(trackData);
			for (int j = 6; j < trackData.indexOf("=") - 4; j++) {
				s.setCharAt(j, '*');
			}
			for (int j = trackData.indexOf("=") + 1; j < trackData.indexOf("=") + 5; j++) {
				s.setCharAt(j, '*');
			}
			trackDataMasked = s.toString();
		}
		return trackDataMasked;
	}

	public String pinMask(String pin) {
		String pinMasked = null;
		if (!pin.isEmpty()) {
			StringBuilder s = new StringBuilder(pin);
			for (int j = 4; j < pin.length() - 4; j++) {
				s.setCharAt(j, '*');
			}
			pinMasked = s.toString();
		}
		return pinMasked;
	}

    // copied from com.asai.common.utils.GenericMethods
	public byte[] getHexLengthOfFourBytes(int commandLength) {
		byte[] lengthBytes = null;
		if (commandLength <= 255) {
			lengthBytes = ArrayUtils.addAll(ISOUtil.int2byte(0), ISOUtil.int2byte(commandLength));
		} else {
			lengthBytes = ISOUtil.int2byte(commandLength);
		}
		return lengthBytes;
	}
	
	public Object packResponse (ISOMsg msg, String transactionType)
	{
		try {
			byte[] response = msg.pack();
			logger.info("Data sent to Pulse: " + response);
			int comdlen1 = response.length;
			return ArrayUtils.addAll(getHexLengthOfFourBytes(comdlen1), response);
		} catch (ISOException e) {
			logger.severe(() -> "Error occurred while processing a " + transactionType + " response: " + e.getMessage());
		}
		return null;
	}

	public StringBuilder getTimeZoneCAPDATEMMDD(final String strTimeZone) throws ValidationException
	{
		StringBuilder strNewDate = new StringBuilder();
		java.util.Date utilDate ;
		try {
			TimeZone timeZone;
			timeZone = TimeZone.getTimeZone(strTimeZone);
			Calendar calendar = Calendar.getInstance();
			utilDate = calendar.getTime();
			/*if (utilDate != null) {
				calendar.setTime(utilDate);
			if (calendar.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY)
				calendar.add(Calendar.DATE, 2);
			else if (calendar.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY)
				calendar.add(Calendar.DATE, 1);
			
			*/
			Calendar cal = Calendar.getInstance();

			// Set time of calendar to 02:30
			cal.set(Calendar.HOUR_OF_DAY, 16);
			cal.set(Calendar.MINUTE, 00);
			cal.set(Calendar.SECOND, 0);
			cal.set(Calendar.MILLISECOND, 0);
			
			System.out.println(cal.getTime());
			System.out.println(calendar.getTime());
			
			if(calendar.after(cal))
				calendar.add(Calendar.DAY_OF_MONTH,1);
			

			int intYear = calendar.get(Calendar.YEAR);
			int intMonth = calendar.get(Calendar.MONTH) + 1;
			int intDay = calendar.get(Calendar.DAY_OF_MONTH);
			int intHour = calendar.get(Calendar.HOUR_OF_DAY);
			int intMinutes = calendar.get(Calendar.MINUTE);
			
			System.out.println(intHour+"Hours and minutes"+intMinutes+"DAY"+intDay);
			strNewDate.append(intMonth < 10 ? ("0" + intMonth) : intMonth);
			strNewDate.append(intDay < 10 ? ("0" + intDay) : intDay);
		} catch (Exception exception) {
				throw new ValidationException("Exception in CardValidation.getCType : "
						+ "Failed To get Transaction Time :" + exception);
		}
		return strNewDate;
	}
}
