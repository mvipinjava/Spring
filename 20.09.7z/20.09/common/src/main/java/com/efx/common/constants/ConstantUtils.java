package com.efx.common.constants;

public interface ConstantUtils
{
	public static final int WPATM = 1;
	public static final int WPPOS = 2;
	public static final String STR_CARTRIDGE_URL = "http://localhost:8080/asai-cartridge/CartridgeServlet";
	public static final String BalEnq ="31";
	public static final String WPBalEnq ="06";
	public static final String WPTransfer ="05";
	public static final String WPWithdrawal ="01";
	public static final String WPReversal ="04";
	public static final String Withdrawal ="11";
	public static final String Reversal ="29";
	public static final String Transfer ="21";
	public static final String BalEnqCHK ="31";
	public static final String BalEnqSAV ="32";
	public static final String BalEnqCRD ="35";
	public static final String WithdrawalCHK ="11";
	public static final String WithdrawalSAV ="12";
	public static final String WithdrawalCRD ="15";
	public static final String TransferCHKTOSAV ="21";
	public static final String TransferSAVTOCHK ="22";
	public static final String TransferCRDTOCHK ="25";
	public static final String BalanceEnquiry ="Balance Enquiry";
	public static final String CashWithdrawal ="Withdrawal";
	public static final String BalanceTransfer ="Transfer";
	public static final String SAVING ="10";
	public static final String CHECKING ="20";
	public static final String CREDIT ="30";
	public static final String RESOURCE_FILE = "http://localhost:8080/asai-cartridge/CartridgeServlet";

	/** RBS(Worldpay) BAL ENQ Req
	 */
	public static final String BALENQSAV  = "311000";
	public static final String BALENQCHK  = "312000";
	public static final String BALENQCRD  = "313000";

	/** RBS(Worldpay) CASH WITHDRAWAL  Req
	 */
	public static final String CASHWTHSAV  = "011000";
	public static final String CASHWTHCHK  = "012000";
	public static final String CASHWTHCRD  = "013000";

	/** RBS(Worldpay) Constants
	 */
	public static final String CHEKINGWP = "CHK";
	public static final String CREDITWP = "CRD";
	public static final String SAVINGWP  = "SAV";
	
	/** RBS(Worldpay) Constants
	 */
	public static final String TSFSAV_TO_CHK  = "401020";
	public static final String TSFSAV_TO_SAV  = "401010";
	public static final String TSFSAV_TO_CRD  = "403020";
	public static final String TSFCHK_TO_SAV  = "402010";
	public static final String TSFCHK_TO_CHK  = "402020";
	public static final String TSFCHK_TO_CRD  = "402030";
	public static final String TSFCRD_TO_CHK  = "403020";
	public static final String TSFCRD_TO_SAV  = "403020";
	

	
}
