package com.efx.common.constants;

/**
 * The Interface GatewaySwitchConstants.
 * 
 * @author Paycube
 */
public class GatewaySwitchConstants {

	/*
	 * Please change this path when deploy on server Local Machine Path
	 */

	/** The Constant RESOURCE_FILE_PATH. */
	public static final String RESOURCE_FILE_PATH = "gateway-fileconfig.cfg";
	/**         */
	public static final String MAIL_CONFIG_FILE_PATH = "resources/mail-config.xml";
	/** The Constant WS_ROOT_URL. */
	public static final String WS_ROOT_URL = "WS_ROOT_URL";
	/** The Constant Q2_FILE_PATH. */
	public static final String Q2_FILE_PATH = "Q2_SERVER_TRANSMNGR";
	/** The Constant CONNECTION_FILE_PATH. */
	public static final String CONNECTION_FILE_PATH = "QSP_CONNECTION_POOL";
	/** The Constant DEVELOPER_ID. */
	public static final String DEVELOPER_ID = "DEVELOPER_ID";
	/** The Constant VERSION_ID. */
	public static final String VERSION_ID = "VERSION_ID";
	/** The Constant CA. */
	public static final String CA = "CA";
	/** The Constant CC. */
	public static final String CC = "CC";
	/** The Constant DC. */
	public static final String DC = "DC";
	/** The Constant BATCH. */
	public static final String BATCH = "00";
	/** The Constant SALE. */
	public static final String SALE = "01";
	/** The Constant VOID. */
	public static final String VOID = "02";
	/** The Constant REFUND. */
	public static final String REFUND = "03";
	/** The Constant SALE_REVERSAL. */
	public static final String SALE_REVERSAL = "04";
	/** The Constant VOID_REVERSAL. */
	public static final String VOID_REVERSAL = "05";
	/** The Constant REFUND_REVERSAL. */
	public static final String REFUND_REVERSAL = "06";
	/** The Constant OFFLINE_SALE. */
	public static final String OFFLINE_SALE = "07";
	/** The Constant REFUND_VOID. */
	public static final String REFUND_VOID = "08";
	/** The Constant OFFLINE_VOID. */
	public static final String OFFLINE_VOID = "09";
	/** The Constant RECORD_FORMAT_DEBIT_RESPONSE. */
	public static final String RECORD_FORMAT_DEBIT_RESPONSE = "U";
	/** The Constant RECORD_FORMAT_SALE_REFUND. */
	public static final String RECORD_FORMAT_SALE_REFUND = "G";
	/** The Constant MANUAL. */
	public static final String MANUAL = "T";
	/** The Constant TRACK_1. */
	public static final String TRACK_1 = "H";
	/** The Constant TRACK_2. */
	public static final String TRACK_2 = "D";
	/** The Constant CVV_CODE. */
	public static final String CVV_CODE = "Y";
	/** The Constant AVS_FLAG. */
	public static final String AVS_FLAG = "Y";
	/** The Constant COMMER_CARD_REQUEST_INDICATOR_CODE. */
	public static final String COMMER_CARD_REQUEST_INDICATOR_CODE = "Y";
	/** The Constant MOTO_INDICATOR_CODE. */
	public static final String MOTO_INDICATOR_CODE = "2";
	/** The Constant RESPONSE_FROM_GATEWAY. */
	public static final String RESPONSE_FROM_GATEWAY = "0";
	/** The Constant RESPONSE_FROM_PROCESSOR. */
	public static final String RESPONSE_FROM_PROCESSOR = "1";
	/** The Constant ACI_YES. */
	public static final String ACI_YES = "Y";
	/** The Constant ACI_NO. */
	public static final String ACI_NO = "N";
	/** The Constant ACI_RECURRING. */
	public static final String ACI_RECURRING = "R";
	/** The Constant GOOD_BATCH. */
	public static final String GOOD_BATCH = "GB";
	/** The Constant REJECTED_BATCH. */
	public static final String REJECTED_BATCH = "RB";
	/** The Constant DUPLICATE_BATCH. */
	public static final String DUPLICATE_BATCH = "QD";
	/** The Constant CARD_NAME_VISA. */
	public static final String CARD_NAME_VISA = "Visa";
	/** The Constant CARD_NAME_MASTERCARD. */
	public static final String CARD_NAME_MASTERCARD = "Mastercard";
	/** The Constant CARD_NAME_DISCOVER. */
	public static final String CARD_NAME_DISCOVER = "Discover";
	/** The Constant CARD_NAME_AMEX. */
	public static final String CARD_NAME_AMEX = "Amex";
	/** The Constant CARD_NAME_DINER. */
	public static final String CARD_NAME_DINER = "Diners";
	/** The Constant CARD_NAME_JCB. */
	public static final String CARD_NAME_JCB = "JCB";
	/** The Constant CARD_NAME_PIN_DEBIT. */
	public static final String CARD_NAME_PIN_DEBIT = "Pin Debit";
	/** The Constant CARD_NAME_DISCOVER. */
	public static final String GAS_CARDS = "GAS Cards";
	/** The Constant LEVEL_NOT_PRESENT. */
	public static final String LEVEL_NOT_PRESENT = "0";
	/** The Constant LEVEL_II_DATA. */
	public static final String LEVEL_II_DATA = "1";
	/** The Constant LEVEL_III_DATA. */
	public static final String LEVEL_III_DATA = "2";
	/** The Constant TIP_FLAG_PRESENT. */
	public static final String TIP_FLAG_PRESENT = "1";
	/** The Constant TIP_FLAG_NOT_PRESENT. */
	public static final String TIP_FLAG_NOT_PRESENT = "0";
	/** The Constant DETAIL_DATA_DESCRIPTION. */
	public static final String DETAIL_DATA_DESCRIPTION = " FOR DETAIL DATA,RECORD NO:";
	/** The Constant LEVEL_II_DATA_FOR_VISA. */
	public static final String LEVEL_II_DATA_FOR_VISA = " OF LEVEL II DATA FOR VISA,RECORD NO:";
	/** The Constant LEVEL_III_DATA_FOR_VISA. */
	public static final String LEVEL_III_DATA_FOR_VISA = " OF LEVEL III DATA FOR VISA,RECORD NO:";
	/** The Constant LEVEL_II_DATA_FOR_MASTERCARD. */
	public static final String LEVEL_II_DATA_FOR_MASTERCARD = " OF LEVEL II DATA FOR MASTERCARD,RECORD NO:";
	/** The Constant LEVEL_III_DATA_FOR_MASTERCARD. */
	public static final String LEVEL_III_DATA_FOR_MASTERCARD = " OF LEVEL III DATA FOR MASTERCARD,RECORD NO:";
	/** The Constant LEVEL_II_DATA_FOR_AMEX. */
	public static final String LEVEL_II_DATA_FOR_AMEX = " OF LEVEL II DATA FOR AMEX,RECORD NO:";
	/** The Constant LINE_ITEM_DATA. */
	public static final String LINE_ITEM_DATA = " OF LINE ITEM DATA,RECORD NO:";
	/** The Constant LINE_ITEM_NUMBER. */
	public static final String LINE_ITEM_NUMBER = " ,LINE ITEM NO:";
	/** The Constant RISK_STATUS_UNRESOLVED. */
	public static final String RISK_STATUS_UNRESOLVED = "U";
	/** The Constant RISK_NOTES_HIGH_VOLUME_LIMIT. */
	public static final String RISK_NOTES_HIGH_VOLUME_LIMIT = "1";
	/** The Constant RISK_NOTES_HIGH_TICKET_LIMIT. */
	public static final String RISK_NOTES_HIGH_TICKET_LIMIT = "2";
	/** The Constant RISK_NOTES_BIN_FILTER. */
	public static final String RISK_NOTES_BIN_FILTER = "3";
	/** The Constant DEFAULT_RISK_NOTES. */
	public static final String DEFAULT_RISK_NOTES = "0";
	/** The Constant TSYS_PROCESSOR_NAME. */
	public static final String TSYS_PROCESSOR_NAME = "TSYS";
	/** The Constant BIN_SEPARATOR. */
	public static final String BIN_SEPARATOR = ",";
	/** The Constant BIN_RECORD_SEPARATOR. */
	public static final String BIN_RECORD_SEPARATOR = ";";
	/** The Constant BATCH_TRANS_REF_NO_SEPARATOR. */
	public static final String BATCH_TRANS_REF_NO_SEPARATOR = ";";
	/** The Constant BCH_IS_REPORT_DB_UPDATE_FLAG. */
	int BCH_IS_REPORT_DB_UPDATE_FLAG = 1;
	/** The Constant BCH_IS_REPORT_DB_UPDATE_FLAG_NO. */
	int BCH_IS_REPORT_DB_UPDATE_FLAG_NO = 0;
	/** The Constant GATEWAY_SUPPORT_SUPER_USER. */
	long GATEWAY_SUPPORT_SUPER_USER = 10002;
	/** The Constant MESSAGE_PRIORITY. */
	public static final String MESSAGE_PRIORITY = "m";
	/** The Constant MSG_BODY_TEXT_PRESTRING. */
	public static final String MSG_BODY_TEXT_PRESTRING = "Transaction ID:";
	/** The offline sale trn resp aci. */
	public static final String OFFLINE_SALE_TRN_RESP_ACI = " ";
	/** The offline sale auth src cd. */
	public static final String OFFLINE_SALE_AUTH_SRC_CD = "E";
	/** The offline sale avs resp. */
	public static final String OFFLINE_SALE_AVS_RESP = "0";
	/** The offline sale trn resp identifier. */
	public static final String OFFLINE_SALE_TRN_RESP_IDENTIFIER = "000000000000000";
	/** The offline sale validation cd. */
	public static final String OFFLINE_SALE_VALIDATION_CD = "    ";
	/** The refund trn resp aci. */
	public static final String REFUND_TRN_RESP_ACI = " ";
	/** The refund auth src cd. */
	public static final String REFUND_AUTH_SRC_CD = "9";
	/** The refund avs resp. */
	public static final String REFUND_AVS_RESP = "0";
	/** The refund trn resp identifier. */
	public static final String REFUND_TRN_RESP_IDENTIFIER = "000000000000000";
	/** The refund validation cd. */
	public static final String REFUND_VALIDATION_CD = "    ";
	/** The date format now. */
	public static final String DATE_FORMAT_NOW = "yyyy-MM-dd HH:mm:ss";
	/** The vt update flag. */
	public static final String VT_UPDATE_FLAG = "1";
	/** The gw risk source. */
	public static final String GW_RISK_SOURCE = "2";
	/** The vt risk source. */
	public static final String VT_RISK_SOURCE = "1";
	/** The no auth trn. */
	public static final int NO_AUTH_TRN = 0;
	/** The recurring auth. */
	public static final int RECURRING_AUTH = 1;
	/** The auth only transaction. */
	public static final int AUTH_ONLY_TRANSACTION = 2;
	/**
	 * Account Data Source - Card holder signature; assume no PIN pad available.
	 */
	public static final String ACCOUNT_DATA_SOURCE_CARD_HOLDER_SIGNATURE = "@";
	/** Account Data Source - Card present - unable to read mag stripe. */
	public static final String ACCOUNT_DATA_SOURCE_CARD_PRESENT = "M";
	/** Account Data Source - PIN pad (NOT from Automated Dispensing Machine). */
	public static final String ACCOUNT_DATA_SOURCE_PIN_PAD_DUKPT = "K";
	/** Account Data Source - Card Not Present transactions. */
	public static final String ACCOUNT_DATA_SOURCE_CARD_NOT_PRESENT = "N";
	/** The x char. */
	public static final String X_CHAR = "X";
	/** The underscor char. */
	public static final String UNDERSCOR_CHAR = "_";
	/** The space char. */
	public static final String SPACE_CHAR = " ";

	/** contant for withdrawal checking */
	public static final String WITHDRAWAL_CHECKING = "11";
	/** contant for withdrawal saving */
	public static final String WITHDRAWAL_SAVING = "12";
	/** contant for withdrawal credit */
	public static final String WITHDRAWAL_CREDIT = "15";
	/** contant for reverse previous withdrawal */
	public static final String REVERSE_PREVIOUS_WITHDRAWAL = "29";
	/** contant for balance inquiry checking constant */
	public static final String BALANCE_INQUIRY_CHECKING = "31";
	/** contant for balance inquiry saving constant */
	public static final String BALANCE_INQUIRY_SAVING = "32";
	/** contant for balance inquiry credit constant */
	public static final String BALANCE_INQUIRY_CREDIT = "35";
	/** constant for checking to saving */
	public static final String TRANSFER_PRIMARY_CHECKING_TO_SAVING = "21";
	/** constant for checking to saving */
	public static final String TRANSFER_PRIMARY_SAVING_TO_CHECKING = "22";

	public static final String TRANSFER_PRIMARY_CREDIT_PRIMARY_CHECKING="25";
	public static final String HOST_TOTAL_DOWNLOAD_STR="50";
	public static final String RESET_BDATE_AND_TOTAL_HOST_TOTAL_DOWNLOAD_STR="51";
	
	// processor processing code
	public static final String PRO_WITHDRAWAL = "01";
	public static final String PRO_TRANFER = "40";
	public static final String PRO_INQUIRY = "31";

	// processor account type worldPay
	public static final String PRO_SAVING_ACCOUNT = "01";
	public static final String PRO_CURRENT_ACCOUNT = "02";
	public static final String PRO_CREDIT_ACCOUNT = "03";
	public static final String PRO_UNSPECIFIED = "00";

	// processor account type USBank
	public static final String PRO_SAVING_ACCOUNT_USBank = "10";
	public static final String PRO_CURRENT_ACCOUNT_USBank = "20";
	public static final String PRO_CREDIT_ACCOUNT_USBank = "30";
	
	// processor response code
	public static final String APPROVED = "00";
	public static final String RETAIN_CARD = "04";
	public static final String CALL_AUTHORIZATION_CENTER = "01";
	public static final String DECLINED = "05";
	public static final String INVALID_PIN = "50";
	public static final String EXPIRED_CARD = "54";
	public static final String UNABLE_TO_AUTHORIZE_TRANSACTION = "91";
	public static final String WORLDPAYDOWN = "99";

	// TermSetData table column names
	public static final String WTHCOUNT = "WthCount";
	public static final String INQCOUNT = "InqCount";
	public static final String TSFCOUNT = "TsfCount";
	public static final String REVCOUNT = "RevCount";
	public static final String REQUEST_MTI="0200";
	
	//Adapter Transaction Request Constants for Triton ATM
	public static final int CHK_BALANCE_INQUIRY=31;
	public static final int SAV_BALANCE_INQUIRY=32;
	public static final int CRD_BALANCE_INQUIRY=35;
	public static final int REVERSAL_REQUEST=29;
	public static final int CHK_WITHDRAWAL_REQUEST=11;
	public static final int SAV_WITHDRAWAL_REQUEST=12;
	public static final int CRD_WITHDRAWAL_REQUEST=15;
	public static final int BALANCE_TRANSFER_REQUEST=21;
	public static final int CONFIG_TABLE_DOWNLOAD_REQUEST=60;
	public static final int BALANCE_TRANSFER_REQUEST_SAVING_TO_CHECKING=22;
	public static final int BALANCE_TRANSFER_REQUEST_CREDIT_TO_CHECKING=25;
	public static final int HOST_TOTAL_DOWNLOAD=50;
	public static final int RESET_BDATE_AND_TOTAL_HOST_TOTAL_DOWNLOAD=51;
	public static final int DCC_RATE_LOOKUP=70;
	
	public static final String ComponentSeparator=":";
	
	// processor type
	
	public static final String WP="WORLDPAY";
	public static final String US="USBANK";
	
	public static final String VTWO_PRIMARY_HSM="V2 PRIMARY HSM";
	public static final String VTWO_SECONDARY_HSM="VTWO SECONDARY HSM";
	public static final String VTHREE_PRIMARY_HSM="VTHREE PRIMARY HSM";
	public static final String VTHREE_SECONDARY_HSM="VTHREE SECONDARY HSM";
	
	public static final String TRITON_EMULATION ="TRITON_EMULATION";
	public static final String CASHSOURCE_EMULATION ="CASHSOURCE_EMULATION";
	
}
