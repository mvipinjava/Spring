package com.efx.common.constants;

public interface MessageResponseCode
{
	/*
	 * These constants have to be set into "11.1" ISOMsg Field which is used for Action code.
	 * (Example: "0000" for Approved ,"0030" for General Decline)
	 */
	/** The gw approval. */
	public static final String GW_APPROVAL = "00"; // Transaction is Approved
	/** The partial approval response code. */
	public static final String PARTIAL_APPROVAL_RESPONSE_CODE = "10";
	/** The approval. */
	public static final String APPROVAL = "0000"; // Transaction is Approved
	/** The refer to card issuer. */
	public static final String REFER_TO_CARD_ISSUER = "0001"; // Card referred
	/** The call acquirer. */
	public static final String CALL_ACQUIRER = "0002"; // Call acquirer
	/** The invalid merchant. */
	public static final String INVALID_MERCHANT = "0003"; // Merchant number error
	/** The pick up card. */
	public static final String PICK_UP_CARD = "0004"; // Pick up card
	/** The do not honor. */
	public static final String DO_NOT_HONOR = "0005"; // Decline
	/** The error. */
	public static final String ERROR = "0006"; // "Error" received from Processor
	/** The pick up card special condition. */
	public static final String PICK_UP_CARD_SPECIAL_CONDITION = "0007"; // "Pick Up Card Special Condition" received from Processor
	/** The honor with id. */
	public static final String HONOR_WITH_ID = "0008"; // "Honor With Id" received from Processor
	/** The approved for partial amount. */
	public static final String APPROVED_FOR_PARTIAL_AMOUNT = "0009"; // "Approved For Partial Amount" received from Processor
	/** The approved. */
	public static final String APPROVED = "0010"; // "Approved" received from Processor
	/** The invalid transaction. */
	public static final String INVALID_TRANSACTION = "0011"; // "Invalid Transaction" received from Processor
	/** The invalid amount. */
	public static final String INVALID_AMOUNT = "0012"; // Invalid Amount error
	/** The invalid account number. */
	public static final String INVALID_ACCOUNT_NUMBER = "0013"; // Card number error
	/** The no such issuer. */
	public static final String NO_SUCH_ISSUER = "0014"; // "No Such Issuer" received from Processor
	/** The re enter transaction. */
	public static final String RE_ENTER_TRANSACTION = "0015"; // "Re-enter Transaction" received from Processor
	/** The no action taken. */
	public static final String NO_ACTION_TAKEN = "0016"; // "No Action Taken" received from Processor
	/** The unable to locate. */
	public static final String UNABLE_TO_LOCATE = "0017"; // "Unable To Locate" received from Processor
	/** The no reply. */
	public static final String NO_REPLY = "0018"; // "No Reply" received from Processor
	/** The format error. */
	public static final String FORMAT_ERROR = "0019"; // "Format Error" received from Processor
	/** The bank not supported. */
	public static final String BANK_NOT_SUPPORTED = "0020"; // Bank not supported by switch
	/** The expired card. */
	public static final String EXPIRED_CARD = "0021"; // The card used is an expired card
	/** The suspected fraud. */
	public static final String SUSPECTED_FRAUD = "0022"; // Fraud is suspected on the card being used
	/** The card acceptor contact acquirer. */
	public static final String CARD_ACCEPTOR_CONTACT_ACQUIRER = "0023"; // "Card Acceptor contact Acquirer" received from Processor
	/** The restricted card. */
	public static final String RESTRICTED_CARD = "0024"; // "Restricted Card" received from Processor
	/** The allowable pin retries exceeded. */
	public static final String ALLOWABLE_PIN_RETRIES_EXCEEDED = "0025"; // Pin exceeded
	/** The no credit account. */
	public static final String NO_CREDIT_ACCOUNT = "0026"; // "No Credit Account" received from Processor
	/** The requested function not supported. */
	public static final String REQUESTED_FUNCTION_NOT_SUPPORTED = "0027"; // "Requested Function Not Supported" received from Processor
	/** The lost card. */
	public static final String LOST_CARD = "0028"; // Pickup card (lost card)
	/** The stolen card. */
	public static final String STOLEN_CARD = "0029"; // Pickup card (stolen card)
	/** The processor decline. */
	public static final String PROCESSOR_DECLINE = "0030"; // Processor declined the transaction
	/** The no checking account. */
	public static final String NO_CHECKING_ACCOUNT = "0031"; // No checking account against the card
	/** The no saving account. */
	public static final String NO_SAVING_ACCOUNT = "0032"; // No savings account against the card
	/** The invalid pin. */
	public static final String INVALID_PIN = "0033"; // Wrong pin
	/** The no card record. */
	public static final String NO_CARD_RECORD = "0034"; // The card information was not found with the acquirer
	/** The service not allowed. */
	public static final String SERVICE_NOT_ALLOWED = "0035"; // Service not allowed
	/** The transaction not allowed at terminal. */
	public static final String TRANSACTION_NOT_ALLOWED_AT_TERMINAL = "0036"; // Service not allowed
	/** The activity amount limit exceeded. */
	public static final String ACTIVITY_AMOUNT_LIMIT_EXCEEDED = "0037"; // Decline
	/** The security violation. */
	public static final String SECURITY_VIOLATION = "0038"; // "Security Violation" received from Processor
	/** The original amount incorrect. */
	public static final String ORIGINAL_AMOUNT_INCORRECT = "0039"; // "Original Amount Incorrect" received from Processor
	/** The hard capture. */
	public static final String HARD_CAPTURE = "0040"; // Hard capture (required ATM pickup)
	/** The response received too late. */
	public static final String RESPONSE_RECEIVED_TOO_LATE = "0041"; // "Response Received Too Late" received from Processor
	/** The invalid account. */
	public static final String INVALID_ACCOUNT = "0042"; // No account
	/** The already reversed. */
	public static final String ALREADY_REVERSED = "0043"; // "Already Reversed" received from Processor
	/** The invalid date. */
	public static final String INVALID_DATE = "0044"; // Date error
	/** The encryption error. */
	public static final String ENCRYPTION_ERROR = "0045"; // "Encryption Error" received from Processor
	/** The cash back not approved. */
	public static final String CASH_BACK_NOT_APPROVED = "0046"; // "Cash Back Not Approved" received from Processor
	/** The cant verify pin. */
	public static final String CANT_VERIFY_PIN = "0047"; // The pin could not be verified
	/** The duplicate transmission. */
	public static final String DUPLICATE_TRANSMISSION = "0048"; // Duplicate transmission detected
	/** The network unavailable. */
	public static final String NETWORK_UNAVAILABLE = "0049"; // No reply
	/** The system error. */
	public static final String SYSTEM_ERROR = "0050"; // "System Error" received from Processor
	/** The issuer unavailable. */
	public static final String ISSUER_UNAVAILABLE = "0051"; // Issuer Unavailable or switch inoperative
	/** The invalid routing number. */
	public static final String INVALID_ROUTING_NUMBER = "0052"; // Invalid routing
	/** The violation of law. */
	public static final String VIOLATION_OF_LAW = "0053"; // Transaction cannot be completed, violation of law
	/** The duplicate transaction. */
	public static final String SANITY_ERROR = "028"; // sanity Error
	/** The duplicate transaction. */
	public static final String DUPLICATE_TRANSACTION = "0054"; // Duplication transaction detected
	/** The batch not open. */
	public static final String BATCH_NOT_OPEN = "0055"; // Open batch not found
	/** The invalid batch. */
	public static final String INVALID_BATCH = "0056"; // Invalid batch number
	/** The invalid section. */
	public static final String INVALID_SECTION = "0057"; // Invalid or unsupported section
	/** The avs required. */
	public static final String AVS_REQUIRED = "0058"; // AVS data required
	/** The CV v2_ required. */
	public static final String CVV2_REQUIRED = "0059"; // CVV2 data required
	/** The account length error. */
	public static final String ACCOUNT_LENGTH_ERROR = "0060"; // The length of the account number was not correct
	/** The check digit error. */
	public static final String CHECK_DIGIT_ERROR = "0061"; // "Check Digit Error" received from Processor
	/** The cid format error. */
	public static final String CID_FORMAT_ERROR = "0062"; // "CID format error" received from Processor
	/** The cash service not available. */
	public static final String CASH_SERVICE_NOT_AVAILABLE = "0063"; // Cash back not available
	/** The CV v2_ mismatch. */
	public static final String CVV2_MISMATCH = "0064"; // CVV did not match
	/** The card auth failed. */
	public static final String CARD_AUTH_FAILED = "0065"; // Card authentication failed
	/** The contact processor. */
	public static final String CONTACT_PROCESSOR = "0066"; // Card acceptor contact acquirer
	/** The activity count limit exceeded. */
	public static final String ACTIVITY_COUNT_LIMIT_EXCEEDED = "0067"; // Exceeded the number of card usage count
	/** The transaction not allowed at merchant. */
	public static final String TRANSACTION_NOT_ALLOWED_AT_MERCHANT = "0901"; // The type of transaction not allowed for the merchant sending the
														 // request
	/** The invalid terminal. */
	public static final String INVALID_TERMINAL = "0902"; // Terminal ID in request is not valid
	/** The invalid acquirer. */
	public static final String INVALID_ACQUIRER = "0903"; // Acquirer ID in request is not valid
	/** The duplicate transaction information. */
	public static final String DUPLICATE_TRANSACTION_INFORMATION = "0904"; // The same transaction information was sent twice
	/** The invalid response code. */
	public static final String INVALID_RESPONSE_CODE = "0905"; // "Invalid Response Code" received from Processor
	/** The invalid response. */
	public static final String INVALID_RESPONSE = "0906"; // "Invalid Response" received from Processor
	/** The offline decline. */
	public static final String OFFLINE_DECLINE = "0907"; // "Offline Decline" received from Processor
	/** The request in progress. */
	public static final String REQUEST_IN_PROGRESS = "0908"; // "Request in Progress" received from Processor
	/** The customer cancellation. */
	public static final String CUSTOMER_CANCELLATION = "0909"; // "Customer Cancellation" received from Processor
	/** The illegal acquirer status. */
	public static final String ILLEGAL_ACQUIRER_STATUS = "0910"; // "Illegal Acquirer Status" received from Processor
	/** The institution not supported. */
	public static final String INSTITUTION_NOT_SUPPORTED = "0911"; // "Institution Not Supported" received from Processor
	/** The issuer not supported. */
	public static final String ISSUER_NOT_SUPPORTED = "0912"; // Issuer is not supported
	/** The transation fee unacceptable. */
	public static final String TRANSATION_FEE_UNACCEPTABLE = "0913"; // "Transaction Fee Unacceptable" received from Processor
	/** The transaction not permitted. */
	public static final String TRANSACTION_NOT_PERMITTED = "0914"; // The type of transaction not allowed for the merchant sending the request
	/** The cutoffs in progress. */
	public static final String CUTOFFS_IN_PROGRESS = "0915"; // "Cutoffs In Progress" received from Processor
	/** The file related error. */
	public static final String FILE_RELATED_ERROR = "0916"; // Any error related to terminal config and ATM logs related transactions
	/** The gain error. */
	public static final String GAIN_ERROR = "0917"; // Returned when patron's entry is in GAIN database
	/** The invalid expiry date. */
	public static final String INVALID_EXPIRY_DATE = "0918"; // Expiry date of card is invalid
	/** The processor down transaction will saf. */
	public static final String PROCESSOR_DOWN_TRANSACTION_WILL_SAF = "0919"; // While sending VOID and if processor is down. SmartR will handle the
														 // auto VOID of such transactions.
	/** The processor down transaction will be sent in batch. */
	public static final String PROCESSOR_DOWN_TRANSACTION_WILL_BE_SENT_IN_BATCH = "0920"; // While sending Post-Auth and if processor is down. SmartR
	// will handle the auto Capture.
	/** The merchant id and acquirer institution id do not match. */
	public static final String MERCHANT_ID_AND_ACQUIRER_INSTITUTION_ID_DO_NOT_MATCH = "0921"; // Declined due to merchant id and acquirer were not
	// same
	/** The fee not found for merchant. */
	public static final String FEE_NOT_FOUND_FOR_MERCHANT = "0922"; // When no fee is found in SLP database for requested merchant
	/** The invalid card type selection. */
	public static final String INVALID_CARD_TYPE_SELECTION = "0923"; // When field 48 contains value as "DB" and PAN entered or swiped is credit card
	/** The processor mid tid do not exist. */
	public static final String PROCESSOR_MID_TID_DO_NOT_EXIST = "0924"; // When the passed in merchant id and terminal id is not mapped to any
													// merchant number and terminal number of processor.
	/** The invalid zip code. */
	public static final String INVALID_ZIP_CODE = "0925"; // Returned when card is US issued and zipcode is not available in request
	/** The merchant card processor not found. */
	public static final String MERCHANT_CARD_PROCESSOR_NOT_FOUND = "0926"; // Returned when Merchant Card Processar not found.
	/** The merchant card permission not found. */
	public static final String MERCHANT_CARD_PERMISSION_NOT_FOUND = "0927"; // Returened when Merchant Card Permission not found.
	/** The gw merchant id and processor tid not found. */
	public static final String GW_MERCHANT_ID_AND_PROCESSOR_TID_NOT_FOUND = "0928"; // Returned when Gateways Merchant Id and Processor Terminal Id
																// not found.
	/** The unable to connect tsys. */
	public static final String UNABLE_TO_CONNECT_TSYS = "0929"; // Returned when can't connect to Tsys.
	/** The request time out. */
	public static final String REQUEST_TIME_OUT = "0930"; // Returned when unable to get response
	/** The general decline. */
	public static final String GENERAL_DECLINE = "9999"; // All other codes received from processor
	/** The invalid mti. */
	public static final String INVALID_MTI = "1000"; // MTI is invalid
	/** The null mti. */
	public static final String NULL_MTI = "1001"; // MTI is null
	/** The invalid mti length. */
	public static final String INVALID_MTI_LENGTH = "1002"; // MTI length is not 4,it should be.
	/** The invalid mti version. */
	public static final String INVALID_MTI_VERSION = "1003"; // MTI version is not 2003,it should be.
	/** The invalid trans type. */
	public static final String INVALID_TRANS_TYPE = "1004"; // Transaction type is not 1(Auth) or 4(void),it should be 1 or 4.
	/** The invalid mti request. */
	public static final String INVALID_MTI_REQUEST = "1005"; // MTI request is not 0.
	/** The invalid mti request type. */
	public static final String INVALID_MTI_REQUEST_TYPE = "1006"; // If MTI id third character is not 3 or 1, then it is invalid request.
	/** The failed to cretae transaction id. */
	public static final String FAILED_TO_CRETAE_TRANSACTION_ID = "1007"; // If transaction_id is failed to create for any DB problem.
	/** The invalid time. */
	public static final String INVALID_TIME = "1008"; // Time error
	/** The invalid reference number. */
	public static final String INVALID_REFERENCE_NUMBER = "1009"; // INVALID RETRIVAL REFERENCE NUMBER
	/** The invalid reversal approval code. */
	public static final String INVALID_REVERSAL_APPROVAL_CODE = "1010"; // INVALID REVERSAL APPROVAL TEXT
	/** The invalid reversal transaction id. */
	public static final String INVALID_REVERSAL_TRANSACTION_ID = "1011"; // INVALID REVERSAL TRANSACTION ID
	/** The invalid reversal date time. */
	public static final String INVALID_REVERSAL_DATE_TIME = "1012"; // INVALID REVERSAL DATE TIME
	/** The invalid transaction card type. */
	public static final String INVALID_TRANSACTION_CARD_TYPE = "1013"; // INVALID TRANSACTION CARD TYPE
	/** The invalid transaction type. */
	public static final String INVALID_TRANSACTION_TYPE = "1014"; // INVALID TRANSACTION TYPE
	/** The invalid system trace audit number. */
	public static final String INVALID_SYSTEM_TRACE_AUDIT_NUMBER = "1015"; // INVALID SYSTEM TRACE AUDIT NUMBER
	/** The invalid network identification code. */
	public static final String INVALID_NETWORK_IDENTIFICATION_CODE = "1016"; // INVALID NETWORK IDENTIFICATION CODE
	/** The invalid transaction sequence number. */
	public static final String INVALID_TRANSACTION_SEQUENCE_NUMBER = "1017"; // INVALID TRANSACTION SEQUENCE NUMBER
	/** The invalid date time. */
	public static final String INVALID_DATE_TIME = "1018"; // INVALID DATE TIME
	/** The inactive merchant. */
	public static final String INACTIVE_MERCHANT = "1019"; // INACTIVE MERCHANT
	/** The inactive terminal. */
	public static final String INACTIVE_TERMINAL = "1020"; // INACTIVE TERMINAL
	/** The invalid request aci. */
	public static final String INVALID_REQUEST_ACI = "1021"; // INVALID REQUEST ACI
	/** The invalid moto e commerce for request aci. */
	public static final String INVALID_MOTO_E_COMMERCE_FOR_REQUEST_ACI = "1022"; // INVALID MOTO E COMMERCE FOR REQUEST ACI
	/** The invalid cvv code. */
	public static final String INVALID_CVV_CODE = "1023"; // INVALID CVV CODE
	/** The invalid terminal for merchant. */
	public static final String INVALID_TERMINAL_FOR_MERCHANT = "1024"; // INVALID TERMINAL FOR MERCHANT
	/** The invalid secondary amount. */
	public static final String INVALID_SECONDARY_AMOUNT = "1025"; // INVALID SECONDARY AMOUNT
	/** The invalid commercial card request code. */
	public static final String INVALID_COMMERCIAL_CARD_REQUEST_CODE = "1026"; // INVALID COMMERCIAL CARD REQUEST CODE
	/** The invalid transaction request type. */
	public static final String INVALID_TRANSACTION_REQUEST_TYPE = "1027"; // INVALID TRANSACTION REQUEST TYPE
	/** The invalid batch transaction count. */
	public static final String INVALID_BATCH_TRANSACTION_COUNT = "1028"; // INVALID BATCH TRANSACTION COUNT
	/** The invalid batch transmission date. */
	public static final String INVALID_BATCH_TRANSMISSION_DATE = "1029"; // INVALID BATCH TRANSMISSION DATE
	/** The invalid batch hashing total. */
	public static final String INVALID_BATCH_HASHING_TOTAL = "1030"; // INVALID BATCH HASHING TOTAL
	/** The invalid batch net deposit. */
	public static final String INVALID_BATCH_NET_DEPOSIT = "1031"; // INVALID BATCH NET DEPOSIT
	/** The invalid batch detail data. */
	public static final String INVALID_BATCH_DETAIL_DATA = "1032"; // INVALID BATCH DETAIL DATA
	/** The unable to build request. */
	public static final String UNABLE_TO_BUILD_REQUEST = "1033"; // INVALID PARAMETER TO BUILD TSYS REQUEST
	/** The invalid refund request. */
	public static final String INVALID_REFUND_REQUEST = "1034"; // INVALID REFUND REQUEST
	/** The invalid card holder id code. */
	public static final String INVALID_CARD_HOLDER_ID_CODE = "1035"; // INVALID CARD HOLDER ID CODE
	/** The invalid account data source. */
	public static final String INVALID_ACCOUNT_DATA_SOURCE = "1036"; // INVALID ACCOUNT DATA SOURCE
	/** The invalid returned aci. */
	public static final String INVALID_RETURNED_ACI = "1037"; // INVALID RETURNED ACI
	/** The invalid authorization source code. */
	public static final String INVALID_AUTHORIZATION_SOURCE_CODE = "1038"; // INVALID AUTHORIZATION SOURCE CODE
	/** The invalid approval code. */
	public static final String INVALID_APPROVAL_CODE = "1039"; // INVALID APPROVAL CODE
	/** The invalid avs result code. */
	public static final String INVALID_AVS_RESULT_CODE = "1040"; // INVALID AVS RESULT CODE
	/** The invalid transaction identifier. */
	public static final String INVALID_TRANSACTION_IDENTIFIER = "1041"; // INVALID TRANSACTION IDENTIFIER
	/** The invalid validation code. */
	public static final String INVALID_VALIDATION_CODE = "1042"; // INVALID VALIDATION CODE Void Indicator
	/** The invalid void indicator. */
	public static final String INVALID_VOID_INDICATOR = "1043"; // INVALID VOID INDICATOR
	/** The invalid transaction status code. */
	public static final String INVALID_TRANSACTION_STATUS_CODE = "1044"; // INVALID TRANSACTION STATUS CODE
	/** The invalid reimbursement attribute. */
	public static final String INVALID_REIMBURSEMENT_ATTRIBUTE = "1045"; // INVALID REIMBURSEMENT ATTRIBUTE
	/** The invalid settlement amount. */
	public static final String INVALID_SETTLEMENT_AMOUNT = "1046"; // INVALID SETTLEMENT AMOUNT
	/** The invalid auth amount. */
	public static final String INVALID_AUTH_AMOUNT = "1047"; // INVALID AUTH AMOUNT
	/** The invalid card level result. */
	public static final String INVALID_CARD_LEVEL_RESULT = "1048"; // INVALID CARD LEVEL RESULT
	/** The invalid level flag. */
	public static final String INVALID_LEVEL_FLAG = "1049"; // INVALID LEVEL FLAG
	/** Invalid Transaction Code. */
	public static final String INVALID_TRANSACTION_CODE = "1152";
	/*
	 * Message Response Code of Level II and III for Visa, Mastercard and Amex
	 */
	/** The invalid optional amount identifier. */
	public static final String INVALID_OPTIONAL_AMOUNT_IDENTIFIER = "1050";
	/** The invalid optional amount. */
	public static final String INVALID_OPTIONAL_AMOUNT = "1051";
	/** The invalid purchase order no. */
	public static final String INVALID_PURCHASE_ORDER_NO = "1052";
	/** The invalid group length. */
	public static final String INVALID_GROUP_LENGTH = "1053";
	/** The invalid payment transaction indicator. */
	public static final String INVALID_PAYMENT_TRANSACTION_INDICATOR = "1054";
	/** The invalid mc iias indicator. */
	public static final String INVALID_MC_IIAS_INDICATOR = "1055";
	/** The invalid merchant seller id. */
	public static final String INVALID_MERCHANT_SELLER_ID = "1056";
	/** The invalid custom identifier detail. */
	public static final String INVALID_CUSTOM_IDENTIFIER_DETAIL = "1057";
	/** The invalid association timestamp. */
	public static final String INVALID_ASSOCIATION_TIMESTAMP = "1058";
	/** The invalid supplier reference number. */
	public static final String INVALID_SUPPLIER_REFERENCE_NUMBER = "1059";
	/** The invalid cardholder reference number. */
	public static final String INVALID_CARDHOLDER_REFERENCE_NUMBER = "1060";
	/** The invalid shipped to zip code. */
	public static final String INVALID_SHIPPED_TO_ZIP_CODE = "1061";
	/** The invalid sales tax. */
	public static final String INVALID_SALES_TAX = "1062";
	/** The invalid charge descriptor. */
	public static final String INVALID_CHARGE_DESCRIPTOR = "1063";
	/** The invalid requester name. */
	public static final String INVALID_REQUESTER_NAME = "1064";
	/** The invalid total tax amount. */
	public static final String INVALID_TOTAL_TAX_AMOUNT = "1065";
	/** The invalid tax type code. */
	public static final String INVALID_TAX_TYPE_CODE = "1066";
	/** The invalid total authorized amount. */
	public static final String INVALID_TOTAL_AUTHORIZED_AMOUNT = "1067";
	/** The invalid purchase identifier format code. */
	public static final String INVALID_PURCHASE_IDENTIFIER_FORMAT_CODE = "1068";
	/** The invalid purchase identifier. */
	public static final String INVALID_PURCHASE_IDENTIFIER = "1069";
	/** The invalid local tax included flag. */
	public static final String INVALID_LOCAL_TAX_INCLUDED_FLAG = "1070";
	/** The invalid local tax. */
	public static final String INVALID_LOCAL_TAX = "1071";
	/** The invalid national tax included flag. */
	public static final String INVALID_NATIONAL_TAX_INCLUDED_FLAG = "1072";
	/** The invalid national tax amount. */
	public static final String INVALID_NATIONAL_TAX_AMOUNT = "1073";
	/** The invalid merchant vat registration number. */
	public static final String INVALID_MERCHANT_VAT_REGISTRATION_NUMBER = "1074";
	/** The invalid customer vat registration number. */
	public static final String INVALID_CUSTOMER_VAT_REGISTRATION_NUMBER = "1075";
	/** The invalid summary commodity code. */
	public static final String INVALID_SUMMARY_COMMODITY_CODE = "1076";
	/** The invalid discount amount. */
	public static final String INVALID_DISCOUNT_AMOUNT = "1077";
	/** The invalid freight amount. */
	public static final String INVALID_FREIGHT_AMOUNT = "1078";
	/** The invalid duty amount. */
	public static final String INVALID_DUTY_AMOUNT = "1079";
	/** The invalid destination zip code. */
	public static final String INVALID_DESTINATION_ZIP_CODE = "1080";
	/** The invalid ship from zip code. */
	public static final String INVALID_SHIP_FROM_ZIP_CODE = "1081";
	/** The invalid destination country code. */
	public static final String INVALID_DESTINATION_COUNTRY_CODE = "1082";
	/** The invalid unique vat invoice reference number. */
	public static final String INVALID_UNIQUE_VAT_INVOICE_REFERENCE_NUMBER = "1083";
	/** The invalid order date. */
	public static final String INVALID_ORDER_DATE = "1084";
	/** The invalid vat tax amount. */
	public static final String INVALID_VAT_TAX_AMOUNT = "1085";
	/** The invalid vat tax rate. */
	public static final String INVALID_VAT_TAX_RATE = "1086";
	/** The invalid line item count. */
	public static final String INVALID_LINE_ITEM_COUNT = "1087";
	/** The invalid line item string. */
	public static final String INVALID_LINE_ITEM_STRING = "1088";
	/** The invalid alternate tax amount indicator. */
	public static final String INVALID_ALTERNATE_TAX_AMOUNT_INDICATOR = "1089";
	/** The invalid alternate tax amount. */
	public static final String INVALID_ALTERNATE_TAX_AMOUNT = "1090";
	/*
	 * Message Response Code For Line Items for Visa and Master
	 */
	/** The invalid line item card type. */
	public static final String INVALID_LINE_ITEM_CARD_TYPE = "1091";
	/** The invalid item commodity code. */
	public static final String INVALID_ITEM_COMMODITY_CODE = "1092";
	/** The invalid item content. */
	public static final String INVALID_ITEM_CONTENT = "1093";
	/** The invalid product code. */
	public static final String INVALID_PRODUCT_CODE = "1094";
	/** The invalid item quantity. */
	public static final String INVALID_ITEM_QUANTITY = "1095";
	/** The invalid unit of measure code. */
	public static final String INVALID_UNIT_OF_MEASURE_CODE = "1096";
	/** The invalid unit cost. */
	public static final String INVALID_UNIT_COST = "1097";
	/** The invalid discount per line item. */
	public static final String INVALID_DISCOUNT_PER_LINE_ITEM = "1098";
	/** The invalid line item total. */
	public static final String INVALID_LINE_ITEM_TOTAL = "1099";
	/** The invalid item description. */
	public static final String INVALID_ITEM_DESCRIPTION = "1100";
	/** The invalid alternate tax identifier. */
	public static final String INVALID_ALTERNATE_TAX_IDENTIFIER = "1101";
	/** The invalid alternate rate applied. */
	public static final String INVALID_ALTERNATE_RATE_APPLIED = "1102";
	/** The invalid tax type applied. */
	public static final String INVALID_TAX_TYPE_APPLIED = "1103";
	/** The invalid tax amount. */
	public static final String INVALID_TAX_AMOUNT = "1104";
	/** The invalid discount indicator. */
	public static final String INVALID_DISCOUNT_INDICATOR = "1105";
	/** The invalid net gross indicator. */
	public static final String INVALID_NET_GROSS_INDICATOR = "1106";
	/** The invalid extended item amount. */
	public static final String INVALID_EXTENDED_ITEM_AMOUNT = "1107";
	/** The invalid debit credit indicator. */
	public static final String INVALID_DEBIT_CREDIT_INDICATOR = "1108";
	/** The invalid item discount rate. */
	public static final String INVALID_ITEM_DISCOUNT_RATE = "1109";
	/** The invalid item qunty expnt ind. */
	public static final String INVALID_ITEM_QUNTY_EXPNT_IND = "1110";
	/** The invalid item dscnt expnt ind. */
	public static final String INVALID_ITEM_DSCNT_EXPNT_IND = "1111";
	/** The invalid tax rate applied. */
	public static final String INVALID_TAX_RATE_APPLIED = "1112";
	/** The invalid tip. */
	public static final String INVALID_TIP = "1113";
	/** The invalid processor. */
	public static final String INVALID_PROCESSOR = "1114";
	/** The invalid merchant name. */
	public static final String INVALID_MERCHANT_NAME = "1115";
	/** The invalid merchant city. */
	public static final String INVALID_MERCHANT_CITY = "1116";
	/** The invalid merchant state. */
	public static final String INVALID_MERCHANT_STATE = "1117";
	/** The invalid merchant zipcode. */
	public static final String INVALID_MERCHANT_ZIPCODE = "1118";
	/** The invalid merchant time zone. */
	public static final String INVALID_MERCHANT_TIME_ZONE = "1119";
	/** The invalid merchant industry id. */
	public static final String INVALID_MERCHANT_INDUSTRY_ID = "1120";
	/** The invalid card permission merchant id. */
	public static final String INVALID_CARD_PERMISSION_MERCHANT_ID = "1121";
	/** The invalid card processor merchant id. */
	public static final String INVALID_CARD_PROCESSOR_MERCHANT_ID = "1122";
	/** The invalid processor store number. */
	public static final String INVALID_PROCESSOR_STORE_NUMBER = "1123";
	/** The invalid processor terminal number. */
	public static final String INVALID_PROCESSOR_TERMINAL_NUMBER = "1124";
	/** The invalid processor agent settle number. */
	public static final String INVALID_PROCESSOR_AGENT_SETTLE_NUMBER = "1125";
	/** The invalid processor chain number. */
	public static final String INVALID_PROCESSOR_CHAIN_NUMBER = "1126";
	/** The bin filter deny. */
	public static final String BIN_FILTER_DENY = "1127";
	/** The invalid bin filter. */
	public static final String INVALID_BIN_FILTER = "1128";
	/** The invalid transaction ref no. */
	public static final String INVALID_TRANSACTION_REF_NO = "1129";
	/** The failed to cretae batch id. */
	public static final String FAILED_TO_CRETAE_BATCH_ID = "1130";
	/** The failed to connect db. */
	public static final String FAILED_TO_CONNECT_DB = "1131"; // If transaction_id is failed to create for any DB problem.
	/** The failed to handle cash transaction. */
	public static final String FAILED_TO_HANDLE_CASH_TRANSACTION = "1132";
	/** The invalid tip flag. */
	public static final String INVALID_TIP_FLAG = "1133";
	/** The avs zip format error. */
	public static final String AVS_ZIP_FORMAT_ERROR = "1134";
	/** The invalid vt batch id. */
	public static final String INVALID_VT_BATCH_ID = "1135";
	/** The invalid merchant category code. */
	public static final String INVALID_MERCHANT_CATEGORY_CODE = "1136";
	/** The invalid acquirer bin. */
	public static final String INVALID_ACQUIRER_BIN = "1137";
	/** The invalid agent bank number. */
	public static final String INVALID_AGENT_BANK_NUMBER = "1138";
	/** The invalid developer id. */
	public static final String INVALID_DEVELOPER_ID = "1139";
	/** The invalid version id. */
	public static final String INVALID_VERSION_ID = "1140";
	/** The invalid terminal location code. */
	public static final String INVALID_TERMINAL_LOCATION_CODE = "1141";
	/** The invalid terminal id number. */
	public static final String INVALID_TERMINAL_ID_NUMBER = "1142";
	/** The invalid merchant offline approval code. */
	public static final String INVALID_MERCHANT_OFFLINE_APPROVAL_CODE = "1143";
	/** The invalid agent settlement number. */
	public static final String INVALID_AGENT_SETTLEMENT_NUMBER = "1144";
	/** The invalid merchant aba number. */
	public static final String INVALID_MERCHANT_ABA_NUMBER = "1145";
	/** The invalid batch number. */
	public static final String INVALID_BATCH_NUMBER = "1146";
	/** The invalid user name. */
	public static final String INVALID_USER_NAME = "1147";
	/** The invalid user password. */
	public static final String INVALID_USER_PASSWORD = "1148";
	/** The unknown batch error. */
	public static final String UNKNOWN_BATCH_ERROR = "1149";
	/** The invalid sharing grp. */
	public static final String INVALID_SHARING_GRP = "1150";
	/** The invalid terminal zip code  */
	public static final String INVALID_TERMINAL_ZIPCODE = "1151";
	
	public static final String CANNOT_PROCESS_TRANSACTION="011";
}
