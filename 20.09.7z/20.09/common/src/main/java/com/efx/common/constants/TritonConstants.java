package com.efx.common.constants;

public interface TritonConstants
{
	static final int TRITON_LISTENPORT=4000;
	
	public static final String REQUEST_MTI="0200";

//	public static final int TRITON = 1;
//	public static final int M91X = 2;
//	public static final int TIDEL = 3;
//	public static final int CSP = 4;
	
	public static final char STX_VALUE = (char)0x02;
	public static final String STX = "" + STX_VALUE;
	public static final String FS = "" + (char)0x1c;
	public static final char ETX_VALUE = (char)0x03;
	public static final String ETX = "" + ETX_VALUE;
//	public static final String EOT = "" + (char)0x04;
//	public static final String ENQ = "" + (char)0x05;
	public static final char ACK_VALUE = (char)0x06;
	public static final String ACK = "" + ACK_VALUE;
//	public static final String EMPTY = "";
//	public static final String SYNC = ""+ (char)0x16;
	public static final String AF0 = "af0";
	public static final String AF1 = "af1";
	
	/** The Constant TILDE. */
	public static final String TILDE = "" + (char) 0x7E;
	
	/** The Constant TILDE. */
	public static final String CURL = "" + (char) 0x7B;


	public static final int CHK_BALANCE_INQUIRY=31;
	public static final int SAV_BALANCE_INQUIRY=32;
	public static final int CRD_BALANCE_INQUIRY=35;
	public static final int BALANCE_TRANSFER_REQUEST=21;
	public static final int BALANCE_TRANSFER_REQUEST_SAVING_TO_CHECKING=22;
	public static final int BALANCE_TRANSFER_REQUEST_CREDIT_TO_CHECKING=25;
	public static final int DCC_RATE_LOOKUP=70;
	public static final int CHK_WITHDRAWAL_REQUEST=11;
	public static final int SAV_WITHDRAWAL_REQUEST=12;
	public static final int CRD_WITHDRAWAL_REQUEST=15;
	public static final int REVERSAL_REQUEST=29;
	public static final int CONFIG_TABLE_DOWNLOAD_REQUEST=60;
	public static final int HOST_TOTAL_DOWNLOAD=50;
	public static final int RESET_BDATE_AND_TOTAL_HOST_TOTAL_DOWNLOAD=51;

	public static final String TRITON_EMULATION ="TRITON_EMULATION";
	public static final String CASHSOURCE_EMULATION ="CASHSOURCE_EMULATION";

	// Triton specific error codes 

	/** The approval. */
	public static final String APPROVAL = "000"; 
	public static final String EXPIRED_CARD="001";
	public static final String UNAUTHORIZED_USAGE="002";
	public static final String PIN_ERROR="003";
	public static final String INVALID_PIN="004";
	public static final String BANK_UNAVAILABLE="005";
	public static final String CARD_NOT_SUPPORTED ="006"; 
	public static final String 	INSUFFICIENT_FUNDS="007";
	public static final String INELIGIBLE_TRANSACTION="008";
	public static final String INELIGIBLE_ACCOUNT="009";
	public static final String NUMBR_OF_DAILY_WITHDRAWLS_EXCEEDED="010";
	public static final String CANNOT_PROCESS_TRANSACTION="011";
	public static final String AMOUNT_TOO_LARGE="012";
	public static final String ACCOUNT_CLOSE="013";
	public static final String PIN_TRIES_EXCCEDED="014";
	public static final String DATABASE_PROBLEM="015";
	public static final String WITHDRAWAL_LIMIT_ALREADY_REACHED="016";
	public static final String INVALID_AMOUNT = "017";
	public static final String EXTERNAL_DECLINE="018";
	public static final String SYSTEM_ERROR="019";
	public static final String CONTACT_CARD_ISSUER="020";
	public static final String ROUTING_LOOKUP_PROBLEM="021";
	public static final String MESSAGE_EDIT_ERROR="022";
//	public static final String INVALID_TRANSACTION_TYPE = "023"; 
    public static final String TRANSACTION_NOT_SUPPORTED="023";
    public static final String 	INSUFFICIENT_FUNDS2="024";
	public static final String WESTERN_UNION_SENDER_DATA_ERROR="025";
	public static final String WESTERN_UNION_RECEIVER_DATA_ERROR="026";
	public static final String CRC_ERROR="027";
	public static final String PRE_PAY_TRANSACTION_FAILED="028";
	public static final String PRE_PAY_TRANSACTION_REJECTED="029";
	public static final String INVALID_MOBILE_PHONE_NUMBER="030";
	public static final String PRE_PAY_ACCOUNT_LIMIT_REACHED="031";
	public static final String PRE_PAY_SYSTEM_UNAVAILABLE="032";
	public static final String RESPONSE_WOULD_EXCEED_MESSAGE_SIZE_LIMIT="033";
	public static final String NECESSARY_INFORMATION_MISSING_TO_PROCESS_TRANSACTION="034";
	public static final String SECOND_INVALID_PIN="035";
	public static final String REVERSAL_DECLINED="111";
	public static final String PIN_CHANGE_DECLINED="222";
	
	// not triton specific error code 
	public static final String INVALID_REFERENCE_NUMBER="";
	public static final String INVALID_REVERSAL_APPROVAL_CODE="";
	public static final String INVALID_REVERSAL_DATE_TIME="";
	public static final String INVALID_REVERSAL_TRANSACTION_ID="";
	public static final String INVALID_SYSTEM_TRACE_AUDIT_NUMBER="";
	public static final String INVALID_TRANSACTION_SEQUENCE_NUMBER="";
	public static final String BLOCKED_EBT = "301";
	public static final String FullReversal = "400"; 
	public static final String PARTIALReversal = "401"; 

}
