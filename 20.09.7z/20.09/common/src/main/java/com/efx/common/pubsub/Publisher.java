package com.efx.common.pubsub;

public interface Publisher
{
	public void publish (Object value);
	public String getTopicName();
}
