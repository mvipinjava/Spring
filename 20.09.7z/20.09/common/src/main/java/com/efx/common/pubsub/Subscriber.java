package com.efx.common.pubsub;

import java.util.function.Consumer;

public interface Subscriber
{
	public void startConsumer (Consumer<Object> consumer);
	public String getTopicName();
}
