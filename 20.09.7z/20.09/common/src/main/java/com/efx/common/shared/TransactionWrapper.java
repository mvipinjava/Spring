package com.efx.common.shared;

import java.util.Map;

import lombok.*;

import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
public class TransactionWrapper implements Serializable
{
	private static final long serialVersionUID = 1L;

	TransactionMap transactionMap;
	Map<String, String> responseMap;
	
	public TransactionWrapper(TransactionMap map)
	{
		this.transactionMap = map;
	}
}
