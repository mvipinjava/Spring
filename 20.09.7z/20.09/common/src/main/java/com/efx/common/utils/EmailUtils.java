package com.efx.common.utils;

import java.io.File;
import java.util.Map;
import java.util.StringTokenizer;

import javax.mail.internet.MimeMessage;

import org.apache.commons.lang3.StringUtils;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.InputStreamSource;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;

import com.efx.common.constants.TransactionMapConstants;

public class EmailUtils implements TransactionMapConstants
{
	final String FROM_EMAIL = "email.from";
	final String TO_SANITY_ERROR_EMAILS = "email.sanity_errors.to";
	final String CC_SANITY_ERROR_EMAILS = "email.sanity_errors.cc";
	final String TO_SUBMITTER_ISSUE_EMAILS = "email.submitter_issue.to";
	final String CC_SUBMITTER_ISSUE_EMAILS = "email.submitter_issue.cc";
	final String TO_HSM_EMAILS = "email.hsm.to";
	final String CC_HSM_EMAILS = "email.hsm.cc";

	static EmailUtils instance = null;
	
	PropertyUtils propUtils;

	String from;

	JavaMailSender emailSender;
    JavaMailSenderImpl emailSenderImpl;
    
	EmailUtils (JavaMailSender emailSender, String from)
	{
		this.emailSender = emailSender;
		this.emailSenderImpl = (JavaMailSenderImpl) emailSender;
		this.from = from;
	}
	
	void init ()
	{
	    propUtils = PropertyUtils.getInstance("email.properties");
	    from = propUtils.getProperty(FROM_EMAIL, "sibisupport@efxfs.com");
	}

	void correctProtocol()
	{
	    if (emailSenderImpl.getPort() == 110)
	    {
	    	emailSenderImpl.setProtocol("pop");
	    }
	}
	
	public static EmailUtils getInstance(JavaMailSender emailSender, String from)
	{
		if (instance == null)
		{
			instance = new EmailUtils(emailSender, from);
			instance.correctProtocol();
			instance.init();
		}
		return instance;
	}
	
    public boolean sendMessage(String to, String cc, String subject, String text)
    {
    	boolean retval = false;
    	if (verifyParameters (to, subject))
    	{
            SimpleMailMessage message = new SimpleMailMessage(); 
            message.setFrom(from);
            message.setTo(parseSender(to)); 
		    if (! StringUtils.isBlank(cc))
		    {
		    	message.setCc(parseSender(cc));
		    }
            message.setSubject(subject); 
            message.setText(text);
            try
            {
            	emailSender.send(message);
            	retval = true;
            } catch (Exception e) {
    			e.printStackTrace();
            }
    	}
        return retval;
     }
    
    String[] parseSender (String sender)
    {
    	StringTokenizer tokenizer = new StringTokenizer(sender, ",");
    	int count = tokenizer.countTokens();
    	String[] tokens = new String[count];
    	for (int i = 0; i < count; i++)
    	{
    		tokens[i] = tokenizer.nextToken();
    	}
    	return tokens;
    }
    
    boolean verifyParameters (String to, String subject)
    {
    	if (StringUtils.isBlank(to))
    	{
    		return false;
    	}
    	if (StringUtils.isBlank(subject))
    	{
    		return false;
    	}
    	return true;
    }
    
    public boolean sendMessageWithFileAttachment(String to, String cc, String subject, String text, String attachmentLabel, String pathToAttachment)
    {
    	if (verifyParameters (to, subject))
    	{
    		InputStreamSource resource = new FileSystemResource(new File(pathToAttachment));
    		return sendMessageWithAttachment(to, cc, subject, text, true, attachmentLabel, resource);
    	}
    	return false;
    }

    public boolean sendMessageWithResourceAttachment(String to, String cc, String subject, String text, String attachmentLabel, String resourceName)
    {
    	if (verifyParameters (to, subject))
    	{
    		ClassPathResource resource = new ClassPathResource(resourceName);
    		return sendMessageWithAttachment(to, cc, subject, text, false, attachmentLabel, resource);
    	}
    	return false;
    }

    public boolean sendMessageWithAttachment(String to, String cc, String subject, String text, boolean isFile, String attachmentLabel, Object attachment)
    {
    	boolean retval = false;
    	if (verifyParameters (to, subject))
    	{
		    MimeMessage message = emailSender.createMimeMessage();
		      
		    MimeMessageHelper helper;
			try {
				helper = new MimeMessageHelper(message, true);
				helper.setFrom(from);
			    helper.setTo(parseSender(to));
			    if (! StringUtils.isBlank(cc))
			    {
			    	helper.setCc(parseSender(cc));
			    }
			    helper.setSubject(subject);
			    helper.setText(text);
			    
			    helper.addAttachment(attachmentLabel, (isFile) ? (InputStreamSource) attachment : (ClassPathResource) attachment);
			    emailSender.send(message);
			    retval = true;
			} catch (Exception e) {
				e.printStackTrace();
			}
    	}
	    return retval;
    }
    
	public void sendHSMDownMail(String failedHSM, String IPAddress)
	{
		String subject = "Critical Alert HSM Down " + failedHSM;
		String data = "HSM is down " + IPAddress;
		sendMessage(propUtils.getProperty(TO_HSM_EMAILS),
				propUtils.getProperty(CC_HSM_EMAILS),
				subject, data);

	}

	public void sendGatewayIssueMail(String submitterName, String gatewayIssue)
	{
		String subject = "Critical Alert " + gatewayIssue;
		String data = "Look into it ASAP";
		sendMessage(propUtils.getProperty(TO_SUBMITTER_ISSUE_EMAILS),
				propUtils.getProperty(CC_SUBMITTER_ISSUE_EMAILS),
				subject, data);
	}

	public void sendSanityErrorMail(Map<String, String> requestMap)
	{
		String data = "Sanity Error on terminal " + requestMap.get(TM_TERMINAL_NUMBER).trim();
		sendMessage(propUtils.getProperty(TO_SANITY_ERROR_EMAILS),
				propUtils.getProperty(CC_SANITY_ERROR_EMAILS),
				"Sanity Error", data);
	}

}
