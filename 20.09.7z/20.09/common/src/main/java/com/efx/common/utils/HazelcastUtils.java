package com.efx.common.utils;

import com.hazelcast.client.HazelcastClient;
import com.hazelcast.core.Hazelcast;
import com.hazelcast.core.HazelcastInstance;

public class HazelcastUtils
{
	public static HazelcastUtils instance = null;
	
	HazelcastInstance hazelcastInstance = null;
	
	HazelcastUtils () { }
	
	public static HazelcastUtils getInstance()
	{
		if (instance == null)
		{
			instance = new HazelcastUtils();
		}
		return instance;
	}
	
	public HazelcastInstance getHazelcastInstance()
	{
        return hazelcastInstance;

	}
	
	public HazelcastInstance createHazelcastInstance(boolean createServer)
	{
		if (hazelcastInstance == null)
		{
			if (createServer)
			{
				hazelcastInstance = Hazelcast.newHazelcastInstance();
			} else {
				hazelcastInstance = HazelcastClient.newHazelcastClient();
			}
		}
        return hazelcastInstance;
    }

}
