package com.efx.common.utils;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PropertyUtils
{
	static PropertyUtils instance = null;
	
	Properties properties = null;
	
	PropertyUtils () { }
	
	public static synchronized PropertyUtils getInstance()
	{
		return getInstance("application.properties");
	}
	
	public static synchronized PropertyUtils getInstance(String propertiesFile)
	{
		if (instance == null)
		{
			instance = new PropertyUtils();
			instance.loadProperties(propertiesFile);
		}
		return instance;
	}
	
	void loadProperties (String propertiesFile)
	{
		ClassLoader loader = Thread.currentThread().getContextClassLoader();
		properties = new Properties();
		try (InputStream resourceStream = loader.getResourceAsStream(propertiesFile))
		{
		    properties.load(resourceStream);
		} catch (IOException e) {
		    e.printStackTrace();
		}
	}
	
	public String getProperty (String name)
	{
		String retval = properties.getProperty(name);
		if (retval != null)
		{
			retval = retval.trim();
		}
		return retval;
	}


	public String getProperty (String name, String defaultValue)
	{
		String retval = getProperty(name);
		return (retval == null) ? defaultValue : retval;
	}
}
