package com.efx.common.base;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.*;
import org.mockito.junit.jupiter.*;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.*;
import static org.mockito.Mockito.*;

import com.efx.common.constants.TopicNameConstants;
import com.efx.common.logging.LogManager;
import com.efx.common.pubsub.Publisher;
import com.efx.common.pubsub.PublisherManager;
import com.efx.common.pubsub.Subscriber;
import com.efx.common.pubsub.SubscriberManager;
import com.efx.common.shared.TransactionMap;
import com.efx.common.utils.HazelcastUtils;
import com.efx.common.utils.TransactionUtils;
import com.hazelcast.core.HazelcastInstance;

@ExtendWith(MockitoExtension.class)
@DisplayName ("BaseProcessor")
class TestBaseProcessor implements TopicNameConstants
{
	// Cannot create an instance of the class under test (cut) as that class is abstract
	BaseProcessor cut = null;

	@Mock
	Publisher pub;
	
	@Mock
	Subscriber sub;
	
	@Mock
	PublisherManager mgr;
	
	@Mock
	SubscriberManager subMgr;
	
	@Mock
	TransactionUtils transactionUtils;
	
	@Mock
	HazelcastUtils utils;
	
	@Mock
	HazelcastInstance hazelcastInstance;
	
	class MockProcessor extends BaseProcessor
	{
		public MockProcessor(String name)
		{
			super(name);
		}

		@Override
		public void processRequest(String sha, TransactionMap tMap) { }
	}
	
	@BeforeEach
	void init()
	{
		cut = new MockProcessor("test");
	}
	
	@AfterEach
	void cleanup()
	{
		LogManager.instance = null;
	}
	
	// Constructor
	@Test
	@DisplayName("constructors act as expected")
	void testBaseProcessor ()
	{
		assertAll(() -> assertEquals ("test", cut.name, () -> "The constructor did not set the name property as expected"),
				  () -> assertNull (cut.logger, () -> "The constructor did not set the logger property as expected"),
				  () -> assertNull (cut.inputTopic, () -> "The constructor did not set the inputTopic property as expected"),
				  () -> assertEquals (PROCESSOR_TOPIC_SUFFIX, cut.outputSuffix, () -> "The constructor did not set the outputSuffix property as expected"),
				  () -> assertNull (cut.sub, () -> "The constructor did not set the sub property as expected"),
				  () -> assertNull (cut.pub, () -> "The constructor did not set the pub property as expected"),
				  () -> assertNull (cut.transactionUtils, () -> "The constructor did not set the transactionUtils property as expected"));
	}

	@Nested
	@DisplayName("initialization")
	class init
	{
		@Test
		@DisplayName("executes properly")
		void testInit ()
		{
			cut.mgr = mgr;
			cut.transactionUtils = transactionUtils;
			when(mgr.getPublisher(anyString())).thenReturn(pub);
			cut.subMgr = subMgr;
			when(subMgr.getSubscriber(anyString())).thenReturn(sub);
			cut.init();
			assertAll(() -> assertNotNull (cut.logger, () -> "The init method did not set the logger property as expected"),
					  () -> assertEquals (pub, cut.pub, () -> "The init method did not set the pub property as expected"),
					  () -> assertEquals (sub, cut.sub, () -> "The init method did not set the sub property as expected"),
					  () -> assertEquals ("test" + PROCESSOR_TOPIC_SUFFIX, cut.inputTopic, () -> "The init method did not set the inputTopic property as expected"));
	
		}
	
		@Test
		@DisplayName("added tests for code coverage")
		void testInit_ForCoverage ()
		{
			cut.mgr = mgr;
			when(mgr.getPublisher(anyString())).thenReturn(pub);
			cut.subMgr = subMgr;
			when(subMgr.getSubscriber(anyString())).thenReturn(sub);
			HazelcastUtils.instance = utils;
			when(utils.getHazelcastInstance()).thenReturn(hazelcastInstance);
			cut.init();
		}
	}
	
	@Test
	@DisplayName("onMessage works")
	void testOnMessage ()
	{
		BaseProcessor spy = spy(cut);
		doNothing().when(spy)._process(anyString());
		spy.onMessage("test");
	}

	@Nested
	@DisplayName("process method")
	class process
	{
		@Test
		@DisplayName ("executes properly")
		void testProcess ()
		{
			BaseProcessor spy = spy(cut);
			doNothing().when(spy)._process(anyString());
			spy.process("test");
		}
	
		@Test
		@DisplayName ("throws NullPointerException if passed a null string parameter")
		void testProcess_nullString ()
		{
			assertThrows(NullPointerException.class, () -> cut.process(null), () -> "The process method should have thrown a NullPointerException");
		}
	}
	
	@Test
	@DisplayName ("_process works")	
	void test_process ()
	{
		BaseProcessor spy = spy(cut);
		doReturn(null).when(spy).getMapBySha(any());
		spy._process(null);
	}

	@Test
	@DisplayName ("getMapBySha works")	
	void testGetMapBySha ()
	{
		cut.transactionUtils = this.transactionUtils;
		assertNull (cut.getMapBySha(null), () -> "The call to getMapBySha did not return the expected value");
	}

	@Test
	@DisplayName ("sendResponse works")	
	void testSendResponse ()
	{
		cut.pub = this.pub;
		cut.sendResponse(null, null);
	}

	@Test
	@DisplayName ("publishToNextProcessor works")	
	void testPublishToNextProcessor ()
	{
		cut.mgr = this.mgr;
		when(mgr.getPublisher(anyString())).thenReturn(pub);
		cut.publishToNextProcessor(null, "test");
	}

	@Test
	@DisplayName ("getOutputSuffix works")	
	void testGetOutputSuffix ()
	{
		java.lang.String val = "test";
		cut.outputSuffix = val;
		assertEquals (val, cut.getOutputSuffix(), "Test of getOutputSuffix did not return the expected results");
	}

	@Test
	@DisplayName ("setOutputSuffix works")	
	void testSetOutputSuffix ()
	{
		java.lang.String val = "test";
		cut.setOutputSuffix(val);
		assertEquals (val, cut.outputSuffix, "Test of setOutputSuffix did not return the expected results");
	}

}
