package com.efx.common.base;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.*;
import org.mockito.junit.jupiter.*;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.*;

import com.efx.common.constants.AllConstants;
import com.efx.common.logging.LogManager;
import com.efx.common.pubsub.Publisher;
import com.efx.common.pubsub.PublisherManager;
import com.efx.common.pubsub.Subscriber;
import com.efx.common.pubsub.SubscriberManager;
import com.efx.common.shared.TransactionMap;
import com.efx.common.shared.TransactionWrapper;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.core.Message;

import static org.mockito.Mockito.*;

import java.util.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("BaseRequester")
class TestBaseRequester implements AllConstants
{
	// Cannot create an instance of the class under test (cut) as that class is abstract
	BaseRequester cut = null;
	
	@Mock
	HazelcastInstance hazelcastInstance;
	
	@Mock
	Subscriber inputTopic;
    
	@Mock
    Publisher outputTopic;
	
	@Mock
	SubscriberManager subMgr;
	
	@Mock
	PublisherManager pubMgr;
	
	@Mock
	Message<Map<String, String>> mapMessage;
	
	@Mock
	TransactionWrapper wrapper;

    
	class MockRequester extends BaseRequester
	{
		public MockRequester(String name, HazelcastInstance hazelcastInstance)
		{
			super(name, 0, hazelcastInstance);
		}

		@Override
		public Map<String, String> getRequestMap(Object data)
		{
			return null;
		}

		@Override
		public Object getResponseFromMap(TransactionWrapper wrapper)
		{
			return null;
		}
	}
	
	@BeforeEach
	void init()
	{
		cut = new MockRequester("test", this.hazelcastInstance);
	}
	
	@AfterEach
	void cleanup()
	{
		LogManager.instance = null;
	}
	
	// Constructor
	@Test
	@DisplayName("constructor")
	void testBaseRequester ()
	{
		assertAll (() -> assertEquals (this.hazelcastInstance, cut.hazelcastInstance, () -> "The constructor did not initialize hazelcastInstance as expected"),
				   () -> assertEquals ("test", cut.name, () -> "The constructor did not initialize name as expected"),
				   () -> assertEquals ("test" + REPLY_TOPIC_SUFFIX, cut.inputTopicName, () -> "The constructor did not initialize inputTopicName as expected"),
				   () -> assertNull (cut.logger, () -> "The constructor did not initialize logger as expected"),
				   () -> assertEquals (1, cut.relativeCounter, () -> "The constructor did not initialize relativeCounter as expected"),
				   () -> assertNull (cut.inputTopic, () -> "The constructor did not initialize inputTopic as expected"),
				   () -> assertNull (cut.outputTopic, () -> "The constructor did not initialize outputTopic as expected"),
				   () -> assertNotNull (cut.connectionData, () -> "The constructor did not initialize connectionData as expected"),
				   () -> assertEquals (0, cut.connectionData.size(), () -> "The constructor did not initialize connectionData as empty map"));		
	}

	@Test
	@DisplayName("closeConnection method")
	void testCloseConnection ()
	{
		cut.closeConnection(null);
	}

	@Test
	@DisplayName("onConnection method")
	void testOnConnection ()
	{
		BaseRequester spy = Mockito.spy(cut);
		doNothing().when(spy).processData(any(), any());
		spy.onConnection(null);
	}

	@Test
	@DisplayName("processData method")
	void testProcessData ()
	{
		BaseRequester spy = spy(cut);
		doReturn(1).when(spy).getRelativeCounter();
		Map<String, String> map = new HashMap<String, String>();
		Object connection = new Object();
		doReturn(null).when(spy).storeDataAndPublish(1, map, connection);
		spy.processData(map, connection);
		assertEquals (2, map.size(), () -> "The call to processData method did not return the expected side effect");

	}
	
	@Nested
	@DisplayName("getRelativeCounter method")
	class getRelativeCounter
	{
		@Test
		@DisplayName("executes correctly")
		void testGetRelativeCounter()
		{
			int value = cut.getRelativeCounter();
			assertAll (() -> assertEquals (1, value, () -> "The call to getRelativeCounter did not return the expected value"),
					   () -> assertEquals (2, cut.relativeCounter, () -> "The call to getRelativeCounter did not update relativeCounter as expected"));
		}
	
		@Test
		@DisplayName("rolls over value from MAX_INT to 1")
		void testGetRelativeCounter_withRollover()
		{
			cut.relativeCounter = Integer.MAX_VALUE;
			int value = cut.getRelativeCounter();
			assertAll (() -> assertEquals (Integer.MAX_VALUE, value, () -> "The call to getRelativeCounter did not return the expected value"),
					   () -> assertEquals (1, cut.relativeCounter, () -> "The call to getRelativeCounter did not update relativeCounter as expected"));
		}
	}
	
	@Test
	@DisplayName("storeDataAndPublish method")
	void testStoreDataAndPublish ()
	{
		assertEquals (0, cut.connectionData.size(), () -> "Before the call to storeDataAndPublish connectionData was not empty");
		cut.outputTopic = this.outputTopic;
		assertAll (() -> assertNull (cut.storeDataAndPublish(0, null, new Object()), () -> "The call to storeDataAndPublish method did not return the expected results"),
				   () -> assertEquals (1, cut.connectionData.size(), () -> "The call to storeDataAndPublish connectionData was not updated"));
	}

	@Nested
	@DisplayName("retrieveDataConnection method")
	class retrieveDataConnection
	{
		@Test
		@DisplayName("executes correctly")
		void testRetrieveDataConnection ()
		{
			Map<String, String> mapData = new HashMap<String, String>();
			mapData.put(TM_RELATIVE_COUNTER, "101");
			Object testObj = new Object();
			cut.connectionData.put("101", testObj);
			when(wrapper.getTransactionMap()).thenReturn(new TransactionMap(mapData));
			Object results = cut.retrieveDataConnection(wrapper);
			assertEquals (results, testObj, () -> "The call to retrieveDataConnection did not return the expected value"); 
		}
	
		@Test
		@DisplayName("handles non-integer data correctly")
		void testRetrieveDataConnection_withBadData ()
		{
			Map<String, String> mapData = new HashMap<String, String>();
			mapData.put(TM_RELATIVE_COUNTER, "abc");
			Object results = cut.retrieveDataConnection(wrapper);
			when(wrapper.getTransactionMap()).thenReturn(new TransactionMap(mapData));
			assertNull (results, () -> "The call to retrieveDataConnection did not return the expected value"); 
		}
	}
	
	@Test
	@DisplayName("readData method")
	void testReadData ()
	{
		assertNull (cut.readData(null), () -> "The call to readData method did not return the expected results");
	}

	@Test
	@DisplayName("writeData method")
	void testWriteData ()
	{
		assertTrue (cut.writeData(null, null), () -> "The call to writeData method did not return the expected results");
	}

	@Test
	@DisplayName("getRequestMap method")
	void testGetRequestMap ()
	{
		assertNull (cut.getRequestMap(null), () -> "The call to getRequestMap method did not return the expected results");
	}

	@Test
	@DisplayName("getResponseFromMap method")
	void testGetResponseFromMap ()
	{
		assertNull (cut.getResponseFromMap(null), () -> "The call to getResponseFromMap method did not return the expected results");
	}

	@Test
	@DisplayName("modifyRequestMap method")
	void testModifyRequestMap ()
	{
		cut.modifyRequestMap(null);
	}

	@Test
	@DisplayName("getInputTopicName method")
	void testGetInputTopicName ()
	{
		java.lang.String val = "test";
		cut.inputTopicName = val;
		assertEquals (val, cut.getInputTopicName(), () -> "Test of getInputTopicName did not return the expected results");
	}

	@Test
	@DisplayName("outputTopicName method")
	void testSetOutputTopicName ()
	{
		java.lang.String val = "test";
		cut.setOutputTopicName(val);
		assertEquals (val, cut.outputTopicName, () -> "Test of setOutputTopicName did not return the expected results");
	}

	@Test
	@DisplayName("getConnectionData method")
	void testGetConnectionData ()
	{
		java.util.Map<String, Object> val = new java.util.HashMap<String, Object>();
		cut.connectionData = val;
		assertEquals (val, cut.getConnectionData(), () -> "Test of getConnectionData did not return the expected results");
	}

	@Test
	@DisplayName("init method")
	void testInit ()
	{
		cut.subMgr = this.subMgr;
		cut.mgr = this.pubMgr;
		when(subMgr.getSubscriber(anyString())).thenReturn(this.inputTopic);
		when(pubMgr.getPublisher(anyString())).thenReturn(this.outputTopic);
		cut.init();
		assertAll (() -> assertNotNull(cut.logger, () -> "The call to init did not initialize the logger property"),
				   () -> assertEquals(this.inputTopic, cut.inputTopic, () -> "The call to init did not initialize the inputTopic property"),
				   () -> assertEquals(this.outputTopic, cut.outputTopic, () -> "The call to init did not initialize the outputTopic property"));
	}

	@Test
	@DisplayName("onMessage method")
	void testOnMessage ()
	{
		BaseRequester spy = spy(cut);
		Map<String, String> mapData = new HashMap<String, String>();		
		doReturn(null).when(spy).retrieveDataConnection(wrapper);
		spy.onMessage(mapData);
		
		// test (currently empty) failure case writing data
		doReturn(false).when(spy).writeData(null, null);
		spy.onMessage(mapData);
	}

}
