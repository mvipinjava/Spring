package com.efx.common.logging;

import org.junit.jupiter.api.*;

import org.junit.jupiter.api.extension.*;
import org.mockito.junit.jupiter.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.util.logging.Level;
import java.util.logging.LogRecord;

import org.mockito.*;

import com.efx.common.pubsub.Publisher;
import com.efx.common.pubsub.PublisherManager;

@ExtendWith(MockitoExtension.class)
@DisplayName("EFXLogger")
class TestEFXLogger
{
	EFXLogger cut = null;	// cut = class under test

	@Mock
	PublisherManager mgr;
	
	@Mock
	Publisher pub;
	
	LogRecord record;
	
	@Mock
	LogRecord mockRecord;
	
	@BeforeEach
	void init()
	{
		cut = new EFXLogger();
		record = new LogRecord (Level.SEVERE, "This is a test");
	}
	
	@AfterEach
	void cleanup()
	{
		EFXLogger.pub = null;
	}
	
	// Tests both Constructors
	@Nested
	@DisplayName("constructors")
	class constructors
	{
		@Test
		@DisplayName("default constructor")
		void testEFXLogger ()
		{
			assertAll (() -> assertNull (EFXLogger.pub, () -> "The default constructor did not initialize the property pub as expected"),
					   () -> assertNotNull (EFXLogger.mgr, () -> "The default constructor did not initialize the property mgr as expected"),
					   () -> assertEquals (cut.LOGGING_PACKAGE, "com.efx.common.logging", () -> "The default constructor did not initialize the property LOGGING_PACKAGE as expected"),
					   () -> assertEquals (cut.API_LOGGING, "java.util.logging", () -> "The default constructor did not initialize the property API_LOGGING as expected"),
					   () -> assertFalse (cut.useAggregation, () -> "The default constructor did not initialize the property useAggregation as expected"));
		}
		
		@Test
		@DisplayName("constructor with false aggregation")
		void testEFXLogger_withFalseAggregation ()
		{
			cut = new EFXLogger ("test", false);
			assertFalse (cut.useAggregation, () -> "The 2nd constructor call did not initialize the property useAggregation as expected");
		}
		
		@Test
		@DisplayName("constructor with true aggregation")
		void testEFXLogger_withTrueAggregation ()
		{
			EFXLogger.mgr = mgr;
			when(mgr.getPublisher(anyString())).thenReturn (pub);
			cut = new EFXLogger ("test", true);
			assertAll (() -> assertTrue (cut.useAggregation, () -> "The 3rd constructor call did not initialize the property useAggregation as expected"),
					   () -> assertEquals (pub, EFXLogger.pub, () -> "The 3rd constructor call did not initialize the property pub as expected"));
		}
		
		@Test
		@DisplayName("constructor with true aggregation - for Coverage (1/2)")
		void testEFXLogger_forCoverage ()
		{
			EFXLogger.mgr = mgr;
			when(mgr.getPublisher(anyString())).thenReturn (pub);
			cut = new EFXLogger ("test", true);
			assertTrue (cut.useAggregation, () -> "The 4th constructor call did not initialize the property useAggregation as expected");
		}
		
		@Test
		@DisplayName("constructor with true aggregation - for Coverage (2/2)")
		void testEFXLogger_forMoreCoverage ()
		{
			cut = new EFXLogger ("test", false);
			assertFalse (cut.useAggregation, () -> "The 5th constructor call did not initialize the property useAggregation as expected");
		}
	}
	
	@Nested
	@DisplayName("log method")
	class log
	{
		@Test
		@DisplayName("executes properly")
		void testLog ()
		{
			EFXLogger spy = spy(cut);
			doNothing().when(spy).alterLogRecord(any());
			// regular logging
			spy.log(record);
		}
	
		@Test
		@DisplayName("executes with aggregation properly")
		void testLog_withAggregation () throws Exception
		{
			EFXLogger.pub = pub;
			cut.useAggregation = true;
			EFXLogger spy = spy(cut);
			doNothing().when(spy).alterLogRecord(any());
			doReturn("test").when(spy).format(record);
			spy.log(record);
		}
	
		@Test
		@DisplayName("executes with exception properly")
		void testLog_withException () throws Exception
		{
			EFXLogger.pub = pub;
			cut.useAggregation = true;
			EFXLogger spy = spy(cut);
			doNothing().when(spy).alterLogRecord(any());
	//		doReturn("test").when(spy).format(record);
			doThrow(Exception.class).when(spy).format(record);
			spy.log(record);
		}
	}
	
	@Test
	@DisplayName("alterLogRecord method")
	void testAlterLogRecord ()
	{
		cut.alterLogRecord(this.record);
	}
	
	@Nested
	@DisplayName("format method")
	class format
	{
		@Test
		@DisplayName("executes properly")
		void testFormat () throws Exception
		{
			when(mockRecord.getLevel()).thenReturn(Level.SEVERE);
			when(mockRecord.getSourceClassName()).thenReturn(this.getClass().getName());
			when(mockRecord.getSourceMethodName()).thenReturn("main");
			when(mockRecord.getSequenceNumber()).thenReturn(666L);
			String results = cut.format(mockRecord);
			assertNotNull (results, () -> "The call to the format method did not return the expected value");
		}
	
		@Test
		@DisplayName("executes with exception properly")
		void testFormat_withException () throws Exception
		{
			EFXLogger spy = spy(cut);
			doThrow(Exception.class).when(spy).forTestingFormatException();
	//		when(this.mockRecord.getLevel()).thenThrow(Exception.class);
			String results = spy.format(mockRecord);
			assertNull (results, () -> "The call to the format method (with an exception) did not return the expected value");
		}
	}
}
