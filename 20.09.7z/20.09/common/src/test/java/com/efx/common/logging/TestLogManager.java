package com.efx.common.logging;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.*;
import org.mockito.junit.jupiter.*;
import org.mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import com.efx.common.utils.PropertyUtils;

import static org.mockito.Mockito.*;

import java.util.logging.Logger;

@ExtendWith(MockitoExtension.class)
@DisplayName("LogManager")
class TestLogManager
{
	LogManager cut = null;	// cut = class under test

	@Mock
	PropertyUtils propertyUtils;
	
	@BeforeEach
	void init()
	{
		cut = new LogManager();
	}
	
	@AfterEach
	void cleanup()
	{
		LogManager.instance = null;
	}
	
	// Constructor
	@Test
	@DisplayName("constructor")
	void testLogManager ()
	{
		assertAll (() -> assertNull (LogManager.instance, () -> "The constructor did not properly set the property: instance"),
				   () -> assertNotNull (LogManager.propertyUtils, () -> "The constructor did not properly set the property: propertyUtils"),
				   () -> assertFalse (cut.useAggregation, () -> "The constructor did not properly set the property: useAggregation"),
				   () -> assertNotNull (cut.loggers, () -> "The constructor did not properly set the property: loggers"));
	}

	@Nested
	@DisplayName("static getInstance method")
	class getInstance
	{
		@Test
		@DisplayName("executes properly")
		void testGetInstance ()
		{
			// this is for testing the static method: getInstance
			LogManager.propertyUtils = propertyUtils;
			when(propertyUtils.getProperty(LogManager.PROPERTY_NAME, LogManager.DEFAULT_VALUE)).thenReturn(LogManager.DEFAULT_VALUE);
			LogManager mgr = LogManager.getInstance();
			assertAll (() -> assertEquals (mgr, LogManager.instance, () -> "Test of getInstance did not return the expected results"),
					   () -> assertFalse (mgr.useAggregation, () -> "Test of getInstance did not return the expected value for useAggregation"));
		}
		
		@Test
		@DisplayName("executes retrieving saved value properly")
		void testGetInstance_retrieved ()
		{
			com.efx.common.logging.LogManager val = new com.efx.common.logging.LogManager();
			LogManager.instance = val;
			val.useAggregation = true;
			LogManager mgr = LogManager.getInstance();
			assertAll (() -> assertEquals (val, mgr, () -> "Test of getInstance did not return the expected results"),
					   () -> assertTrue (mgr.useAggregation, () -> "Test of getInstance did not return the expected value for useAggregation"));
		}
	}

	@Test
	@DisplayName("getLogger method")
	void testGetLogger ()
	{
		Logger results = cut.getLogger("test");
		assertNotNull (results, () -> "The call to the getLogger method did not return the expected results");
		assertTrue (cut.loggers.containsKey("test"), () -> "The call to the getLogger method did not queue the results");
		
		Logger results2 = cut.getLogger("test");
		assertNotNull (results2, () -> "The call to the getLogger method did not return the expected results");
		assertEquals (results, results2, () -> "The call to the getLogger method did not returned queued value");
	}
}
