package com.efx.common.pubsub;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.*;
import org.mockito.junit.jupiter.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.efx.common.utils.HazelcastUtils;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.core.ITopic;
import org.mockito.*;


@ExtendWith(MockitoExtension.class)
@DisplayName("HazelcastPublisher")
class TestHazelcastPublisher
{
	HazelcastPublisher cut = null;	// cut = class under test

	@Mock
	ITopic<Object> topic;;
	
	@Mock
	HazelcastUtils utils;
	
	@Mock
	HazelcastInstance hazelcastInstance;

	@BeforeEach
	void init()
	{
		HazelcastPublisher.hazelcastInstance = null;
		cut = new HazelcastPublisher();
	}
	
	@AfterEach
	void cleanup()
	{
		HazelcastPublisher.hazelcastInstance = null;
		HazelcastPublisher.utils = null;
	}
	
	// Tests both Constructors
	@Nested
	@DisplayName("constructors")
	class constructor
	{
		@Test
		@DisplayName("default constructor")
		void testHazelcastPublisher_default ()
		{
			assertAll (() -> assertNull(HazelcastPublisher.hazelcastInstance, () -> "The default constructor did not initialize the property hazelcastInstance as expected"),
					   () -> assertNull(HazelcastPublisher.utils, () -> "The default constructor did not initialize the property utils as expected"),
					   () -> assertNull(cut.topicName, () -> "The default constructor did not initialize the property topicName as expected"),
					   () -> assertNull(cut.topic, () -> "The default constructor did not initialize the property topic as expected"));
		}
		
		@Test
		@DisplayName("constructor taking String parameter")
		void testHazelcastPublisher_withParameter ()
		{
			HazelcastPublisher.hazelcastInstance = hazelcastInstance;
			HazelcastPublisher.utils = utils;
			cut = new HazelcastPublisher("test");
		}
	
		@Test
		@DisplayName("constructor taking String parameter - added for code coverage (1/2)")
		void testHazelcastPublisher_forCoverage ()
		{
			when(utils.getHazelcastInstance()).thenReturn(hazelcastInstance);
			HazelcastPublisher.utils = utils;
			cut = new HazelcastPublisher("test");
		}
		
		@Test
		@DisplayName("constructor taking String parameter - added for code coverage (2/2)")
		void testHazelcastPublisher_forMoreCoverage ()
		{
			HazelcastPublisher.utils = null;
			HazelcastUtils.instance = utils;
			HazelcastPublisher.hazelcastInstance = hazelcastInstance;
			cut = new HazelcastPublisher("test");
		}
	}
	
	@Test
	@DisplayName("publish method")
	void testPublish ()
	{
		cut.topic = this.topic;
		cut.publish("test");
	}

	@Test
	@DisplayName("getTopicName method")
	void testGetTopicName ()
	{
		java.lang.String val = "test";
		cut.topicName = val;
		assertEquals (val, cut.getTopicName(), () -> "Test of getTopicName did not return the expected results");
	}

}
