package com.efx.common.pubsub;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.*;
import org.mockito.junit.jupiter.*;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.*;

import com.efx.common.utils.HazelcastUtils;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.core.ITopic;
import com.hazelcast.core.Message;

import static org.mockito.Mockito.*;

import java.util.function.Consumer;

@ExtendWith(MockitoExtension.class)
@DisplayName("HazelcastSubscriber")
class TestHazelcastSubscriber
{
	HazelcastSubscriber cut = new HazelcastSubscriber();	// cut = class under test

	@Mock
	ITopic<Object> topic;;
	
	@Mock
	HazelcastUtils utils;
	
	@Mock
	HazelcastInstance hazelcastInstance;

	@Mock
	Consumer<Object> consumer;
	
	@Mock
	Message<Object> message;
	
	@BeforeEach
	void init()
	{
	}
	
	@AfterEach
	void cleanup()
	{
		HazelcastSubscriber.hazelcastInstance = null;
		HazelcastSubscriber.utils = HazelcastUtils.getInstance();
	}
	
	// Tests both Constructors
	@Nested
	@DisplayName("constructors")
	class constructors
	{
		@Test
		@DisplayName("default constructor")
		void testHazelcastSubscriber_default ()
		{
			assertAll (() -> assertNull(HazelcastSubscriber.hazelcastInstance, () -> "The default constructor did not initialize the property hazelcastInstance as expected"),
					   () -> assertNotNull(HazelcastSubscriber.utils, () -> "The default constructor did not initialize the property utils as expected"),
					   () -> assertNull(cut.topicName, () -> "The default constructor did not initialize the property topicName as expected"),
					   () -> assertNull(cut.topic, () -> "The default constructor did not initialize the property topic as expected"),
					   () -> assertNull(cut.consumer, () -> "The default constructor did not initialize the property consumer as expected"));
		}		

		@Test
		@DisplayName("constructor with String parameter")
		void testHazelcastSubscriber_withParameters ()
		{
			HazelcastSubscriber.hazelcastInstance = hazelcastInstance;
			HazelcastSubscriber.utils = utils;
			cut = new HazelcastSubscriber("test");
		}
	
		@Test
		@DisplayName("constructor with String parameter for coverage (1/2)")
		void testHazelcastSubscriber_forCoverage ()
		{
			HazelcastSubscriber.hazelcastInstance = hazelcastInstance;
			HazelcastSubscriber.utils = null;
			cut = new HazelcastSubscriber("test");
		}
		
		@Test
		@DisplayName("constructor with String parameter for coverage (2/2)")
		void testHazelcastSubscriber_forMoreCoverage ()
		{
			HazelcastSubscriber.utils = utils;
			HazelcastSubscriber.hazelcastInstance = null;
			when(utils.getHazelcastInstance()).thenReturn(hazelcastInstance);
			cut = new HazelcastSubscriber("test");
		}
	}
	
	@Test
	@DisplayName("getTopicName method")
	void testGetTopicName ()
	{
		java.lang.String val = "test";
		cut.topicName = val;
		assertEquals (val, cut.getTopicName(), () -> "Test of getTopicName did not return the expected results");
	}

	@Test
	@DisplayName("startConsumer method")
	void testStartConsumer ()
	{
		cut.topic = this.topic;
		cut.startConsumer(consumer);
		assertEquals(consumer, cut.consumer, () -> "The call to startConsumer did not set the consumer given");
	}

	@Test
	@DisplayName("onMessage method")
	void testOnMessage ()
	{
		cut.consumer = this.consumer;
		cut.onMessage(message);
	}

}
