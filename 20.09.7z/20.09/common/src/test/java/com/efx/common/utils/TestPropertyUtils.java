package com.efx.common.utils;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.*;
import org.mockito.junit.jupiter.*;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Properties;

@ExtendWith(MockitoExtension.class)
@DisplayName("PropertyUtils")
class TestPropertyUtils
{
	PropertyUtils cut = null;	// cut = class under test

	@BeforeEach
	void init()
	{
		cut = new PropertyUtils();
	}
	
	@AfterEach
	void cleanup()
	{
		PropertyUtils.instance = null;
	}
	
	// Constructor
	@Test
	@DisplayName("constructor")
	void testPropertyUtils ()
	{
		assertAll (() -> assertNull (PropertyUtils.instance, () -> "The constructor did not initialize the instance property to the expected value"),
				   () -> assertNull (cut.properties, () -> "The constructor did not initialize the properties property to the expected value"));		
	}

	@Nested
	@DisplayName("getProperty method")
	class getProperty
	{
		@Test
		@DisplayName("missing property requested")
		void testGetProperty_missing ()
		{
			cut.properties = new Properties();
	
			// first test with it missing
			String results = cut.getProperty("test");
			assertNull (results, () -> "The 1st call to getProperty did not return the expected value");
		}
		
		@Test
		@DisplayName("found property requested")
		void testGetProperty ()
		{
			// now test with it found
			cut.properties = new Properties();
			cut.properties.put("test", "found");
			String results = cut.getProperty("test");
			assertEquals ("found", results, () -> "The 2nd call to getProperty did not return the expected value");
		}
	
		@Test
		@DisplayName("missed property requested, but returned default")
		void testGetProperty_withDefaultValue ()
		{
			cut.properties = new Properties();
			
			// first test with it missing
			String results = cut.getProperty("test", "missing");
			assertEquals ("missing", results, () -> "The 3rd call to getProperty did not return the expected value");
		}
		
		@Test
		@DisplayName("found property requested, and did not return default")
		void testGetProperty_withDefaultValueFound ()
		{
			// now test with it found
			cut.properties = new Properties();
			cut.properties.put("test", "found");
			String results = cut.getProperty("test", "missing");
			assertEquals ("found", results, () -> "The 4th call to getProperty did not return the expected value");
		}
	}
	
	@Nested
	@DisplayName("static getInstance method")
	class getInstance
	{
		@Test
		@DisplayName("executed properly")
		void testGetInstance ()
		{
			// this is for testing the static method: getInstance
			PropertyUtils results = PropertyUtils.getInstance();
			assertEquals (results, PropertyUtils.instance, () -> "Test of getInstance (with null) did not return the expected results");
		}
		@Test
		@DisplayName("retrieved save value properly")
		void testGetInstance_retrieved ()
		{
			com.efx.common.utils.PropertyUtils val = new com.efx.common.utils.PropertyUtils();
			PropertyUtils.instance = val;
			assertEquals (val, PropertyUtils.getInstance(), () -> "Test of getInstance did not return the expected results");
		}
	}
	
	@Test
	@DisplayName("loadProperties method")
	void testLoadProperties()
	{
		cut.loadProperties("test.xml");
	}
}
