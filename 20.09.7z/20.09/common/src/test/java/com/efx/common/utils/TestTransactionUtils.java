package com.efx.common.utils;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.*;
import org.mockito.junit.jupiter.*;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.*;

import com.efx.common.constants.TopicNameConstants;
import com.efx.common.shared.TransactionMap;
import com.efx.common.shared.TransactionWrapper;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.core.IMap;

@ExtendWith(MockitoExtension.class)
@DisplayName("TransactionUtils")
class TestTransactionUtils implements TopicNameConstants
{
	TransactionUtils cut = new TransactionUtils();	// cut = class under test

	@Mock
	HazelcastInstance hazelcastInstance;
	
	@Mock
	IMap<String, TransactionWrapper> queue;
	
	@BeforeEach
	void init()
	{
		cut = new TransactionUtils();
	}
	
	@AfterEach
	void cleanup()
	{
		HazelcastUtils.instance = null;
		TransactionUtils.instance = null;
	}
	
	// Constructor
	@Test
	@DisplayName("constructor")
	void testTransactionUtils ()
	{
		assertAll (() -> assertEquals (REQUEST_TOPIC_NAME, cut.queueName, () -> "The constructor did not initialize the queueName property to the expected value"),
				   () -> assertNull (cut.queue, () -> "The constructor did not initialize the queue property to the expected value"),
				   () -> assertNull (TransactionUtils.instance, () -> "The constructor did not initialize the instance property to the expected value"));
	}

	@Test
	@DisplayName("getTransactionMap method")
	void testGetTransactionMap ()
	{
		cut.queue = this.queue;
		TransactionMap results = cut.getTransactionMap(null);
		assertNull (results, () -> "The constructor did not initialize the queue property to the expected value");
	}

	@Nested
	@DisplayName("static getInstance method")
	class getInstance
	{
		@Test
		@DisplayName("executed properly")
		void testGetInstance ()
		{
			// this is for testing the static method: getInstance
			HazelcastUtils.getInstance().hazelcastInstance = hazelcastInstance;
			TransactionUtils results = TransactionUtils.getInstance();
			assertEquals (results, TransactionUtils.instance, () -> "The 1st call to getInstance did not return the expected results");
		}
		
		@Test
		@DisplayName("retrieved saved value properly")
		void testGetInstance_retrieved ()
		{
			com.efx.common.utils.TransactionUtils val = new com.efx.common.utils.TransactionUtils();
			TransactionUtils.instance = val;
			assertEquals (val, TransactionUtils.getInstance(), () -> "The 2nd call to getInstance did not return the expected results");
		}
	}
}
