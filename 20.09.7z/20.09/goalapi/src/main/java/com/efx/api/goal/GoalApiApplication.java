package com.efx.api.goal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.client.RestTemplate;

import com.efx.common.utils.SwaggerUtils;
import com.netflix.discovery.EurekaClient;

import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableSwagger2
@ComponentScan(basePackages = "com.efx")
@EnableFeignClients
public class GoalApiApplication
{
	// this variable is just used for unit testing
	static ConfigurableApplicationContext context = null;
	
	@Autowired
	EurekaClient eurekaClient;
  

	public static void main(String[] args)
	{
		context = SpringApplication.run(GoalApiApplication.class, args);
	}

	@LoadBalanced
    @Bean
    RestTemplate restTemplate()
    {
    	return new RestTemplate();
    }

    @Bean
    public Docket api() {
    	return SwaggerUtils.getInstance().getSwaggerDocket("Goal API",
    			"This API is used to set goals for individuals globally or by device");
    }
}
