package com.efx.api.goal;

import java.util.Optional;
import java.util.logging.Logger;

import javax.annotation.PostConstruct;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.efx.api.goal.clients.GoalServiceClient;
import com.efx.api.goal.clients.UserServiceClient;
import com.efx.api.goal.pojos.GoalRequest;
import com.efx.api.goal.pojos.ServiceRequest;
import com.efx.api.goal.pojos.TerminalGoalRequest;
import com.efx.common.logging.LogManager;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/api")
@Api(description = "REST APIs related to goals")
public class GoalApiController
{
	public static final String USERNAME_HEADER = "API_USERNAME";

	Logger logger = null;

    @Autowired
    RestTemplate restTemplate;
    
    @Autowired
    GoalServiceClient client;
    
    @Autowired
    UserServiceClient userClient;
    
    @PostConstruct
    public void init ()
    {
    	logger = LogManager.getInstance().getLogger(this.getClass().getName());
    }
    
   long getUserId (String username)
   {
	   long retval = 0;
	   Optional<Long> reply = userClient.getUserIdByUserName(username);
	   if (reply.isPresent())
	   {
		   retval = reply.get();
	   }
	   return retval;
   }
   
    @ApiOperation(value = "Update Global Goal by ID")
    @ApiResponses(value = {
                @ApiResponse(code = 200, message = "Success|OK"),
                @ApiResponse(code = 401, message = "not authorized!"),
                @ApiResponse(code = 403, message = "forbidden!!!"),
                @ApiResponse(code = 404, message = "not found!!!") })
    @GetMapping(path = "/goal/global/id/{id}", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> updateGlobalGoalById (@PathVariable @NotNull long id, @RequestBody @NotNull GoalRequest request, @RequestHeader(USERNAME_HEADER) String username)
    {
    	return updateGoalById (id, request.getGoal_value(), username, 0L);
    }

    @ApiOperation(value = "Update Global Goal by Type Name")
    @ApiResponses(value = {
                @ApiResponse(code = 200, message = "Success|OK"),
                @ApiResponse(code = 401, message = "not authorized!"),
                @ApiResponse(code = 403, message = "forbidden!!!"),
                @ApiResponse(code = 404, message = "not found!!!") })
    @GetMapping(path = "/goal/global/name/{name}", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> updateGlobalGoalByGoalTypeName (@PathVariable @NotNull String name, @RequestBody @NotNull GoalRequest request, @RequestHeader(USERNAME_HEADER) String username)
    {
    	return updateGoalByTypeName (name, request.getGoal_value(), username, 0L);
    }

    @ApiOperation(value = "Update Terminal Goal by ID")
    @ApiResponses(value = {
                @ApiResponse(code = 200, message = "Success|OK"),
                @ApiResponse(code = 401, message = "not authorized!"),
                @ApiResponse(code = 403, message = "forbidden!!!"),
                @ApiResponse(code = 404, message = "not found!!!") })
    @GetMapping(path = "/goal/terminal/id/{id}", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> updateTerminalGoalById (@PathVariable @NotNull long id, @RequestBody @NotNull TerminalGoalRequest request, @RequestHeader(USERNAME_HEADER) String username)
    {
    	return updateGoalById (id, request.getGoal_value(), username, request.getTerminal_id());
    }

    @ApiOperation(value = "Update Terminal Goal by Type Name")
    @ApiResponses(value = {
                @ApiResponse(code = 200, message = "Success|OK"),
                @ApiResponse(code = 401, message = "not authorized!"),
                @ApiResponse(code = 403, message = "forbidden!!!"),
                @ApiResponse(code = 404, message = "not found!!!") })
    @GetMapping(path = "/goal/terminal/name/{name}", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> updateTerminalGoalByGoalTypeName (@PathVariable @NotNull String name, @RequestBody @NotNull TerminalGoalRequest request, @RequestHeader(USERNAME_HEADER) String username)
    {
    	return updateGoalByTypeName (name, request.getGoal_value(), username, request.getTerminal_id());
    }

    public ResponseEntity<Void> updateGoalById (long id, long requestValue, String username, long terminal_id)
    {
    	ServiceRequest request = new ServiceRequest (id, null, requestValue, getUserId(username), terminal_id);
    	boolean results = client.updateGoalById(request);
    	if (results == false)
    	{
    		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    	}
    	return ResponseEntity.noContent().build();
    }

    public ResponseEntity<Void> updateGoalByTypeName (String goalTypeName, long requestValue, String username, long terminal_id)
    {
    	ServiceRequest request = new ServiceRequest (-1, goalTypeName, requestValue, getUserId(username), terminal_id);
    	boolean results = client.updateGoalByGoalTypeName(request);
    	if (results == false)
    	{
    		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    	}
    	return ResponseEntity.noContent().build();
    }
}
