package com.efx.api.goal.clients;

import java.util.Optional;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient("UserService")
public interface UserServiceClient
{
	@GetMapping(path = "/api/user/name/{name}")
	Optional<Long> getUserIdByUserName (String name);
}
