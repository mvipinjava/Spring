package com.efx.api.goal.pojos;

import java.io.Serializable;

import lombok.*;

@Setter
@Getter
public class GoalRequest implements Serializable
{
	private static final long serialVersionUID = 1L;

	long goal_value;
}
