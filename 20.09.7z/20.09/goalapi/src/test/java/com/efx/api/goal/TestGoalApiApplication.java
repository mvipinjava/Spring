package com.efx.api.goal;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
@DisplayName("GoalApiApplication")
public class TestGoalApiApplication
{
	GoalApiApplication cut = new GoalApiApplication();	// cut = class under test

	// Constructor
	@Test
	@DisplayName("constructor")
	void testDispatchServiceApplication ()
	{
		assertNotNull (new GoalApiApplication (), () -> "The call to the constructor did not return the expected results");
	}

	@Test
	@Tag("main")
	@DisplayName("static main method")
	void testMain ()
	{
		// this is for testing the static method: main
		GoalApiApplication.main(new String[0]);
		boolean worked = GoalApiApplication.context.isRunning();
		assertTrue (worked, () -> "The call to main did not provide a successful startup"); 
	}
	
	@Test
	@DisplayName("restTemplate method")
	void testRestTemplate()
	{
		assertNotNull (cut.restTemplate(), () -> "The call to restTemplate returned a null value");
	}

	@Test
	@DisplayName("api method")
	void testApi ()
	{
		assertNotNull (cut.api(), () -> "The call to api did not return the expected results");
	}


}
