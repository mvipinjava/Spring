package com.efx.api.session.pojos;

import java.io.Serializable;
import java.util.List;

import lombok.*;

@Setter
@Getter
public class LoginResponse implements Serializable
{
	private static final long serialVersionUID = 1L;

	String token;
	TermsData terms;
	PrivacyData privacy;
	List<UserPermissionData> userPermissions;
	List<AlarmData> alertTypes;
	List<GoalData> goalTypes;
	List<PhotoData> photoTypes;
	List<PermissionData> permissions;
}
