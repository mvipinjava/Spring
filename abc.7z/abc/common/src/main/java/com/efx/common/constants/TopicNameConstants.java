package com.efx.common.constants;

public interface TopicNameConstants
{
	public static String PROCESSOR_TOPIC_SUFFIX = "-processor";
	public static String VALIDATION_TOPIC_NAME = "validation" + PROCESSOR_TOPIC_SUFFIX;
	public static String LOG_TOPIC_NAME = "logger";
	
	public static String ALERT_TOPIC_NAME = "alert";
	public static String TRANSACTION_TOPIC_NAME = "transaction";
	public static String METRICS_TOPIC_NAME = "metrics";
	public static String STATUS_TOPIC_NAME = "status";

	public static String REQUEST_TOPIC_NAME = "requests";
	public static String REPLY_TOPIC_NAME = "replies";
	public static String REPLY_TOPIC_SUFFIX = "-reply";
	public static String ARCHIVE_TOPIC_NAME = "archive";

	public static String SUBMITTER_TOPIC_SUFFIX = "-submitter";

	public static String RESPONSE_TOPIC_NAME = "responses";

	// This topic is used to export data from TPS/TCC to be fed into the Data Warehouse via ETL
	public static String EXPORT_TOPIC_NAME = "export";
	

	// These topics are used to send data from TPS to SIBI TCC
	public static String NOTIFICATION_TOPIC = "notifications";
	public static String ALERT_TOPIC = "alerts";
	public static String STATUS_TOPIC = "status";
	public static String TRANSACTION_TOPIC = "transactions";
	public static String METRICS_TOPIC = "metrics";
}
