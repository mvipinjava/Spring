package com.efx.common.logging;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

import com.efx.common.utils.PropertyUtils;

public class LogManager
{
	static final String PROPERTY_NAME = "efx.logging.enable.aggregation";
	static String DEFAULT_VALUE = "false";
	
	boolean useAggregation = false;
	
	Map<String, EFXLogger> loggers = new HashMap<String, EFXLogger>();

	static PropertyUtils propertyUtils = PropertyUtils.getInstance();
	
	public static LogManager instance = null;
	
	LogManager() { }
	
	public static LogManager getInstance()
	{
		if (instance == null)
		{
			instance = new LogManager();
			String useAggregationServer = propertyUtils.getProperty (PROPERTY_NAME, DEFAULT_VALUE);
			instance.useAggregation = Boolean.parseBoolean(useAggregationServer);
		}
		return instance;
	}
	
	public Logger getLogger (String name)
	{
		EFXLogger retval = loggers.get(name);
		if (retval == null)
		{
			retval = new EFXLogger(name, this.useAggregation);
			loggers.put(name, retval);
		}
		return retval;
	}
}
