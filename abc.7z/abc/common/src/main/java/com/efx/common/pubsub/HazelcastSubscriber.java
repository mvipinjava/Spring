package com.efx.common.pubsub;

import java.util.function.Consumer;

import com.efx.common.utils.HazelcastUtils;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.core.ITopic;
import com.hazelcast.core.Message;
import com.hazelcast.core.MessageListener;

import lombok.Getter;

public class HazelcastSubscriber implements Subscriber, MessageListener<Object>
{
	static HazelcastUtils utils = HazelcastUtils.getInstance();
	
	static HazelcastInstance hazelcastInstance = null;

	@Getter
	String topicName;

	Consumer<Object> consumer;
	
    ITopic<Object> topic;

    HazelcastSubscriber () { }
    
	public HazelcastSubscriber (String topicName)
	{
		this.topicName = topicName;
		if (utils == null)
		{
			utils = HazelcastUtils.getInstance();
		}
		if (hazelcastInstance == null)
		{
			hazelcastInstance = utils.getHazelcastInstance();
		}
		topic = hazelcastInstance.getTopic(topicName);
	}

	@Override
	public void startConsumer(Consumer<Object> consumer)
	{
		this.consumer = consumer;
		
        // Add a Listener to the Topic
        topic.addMessageListener(this);
	}

	@Override
	public void onMessage(Message<Object> message)
	{
		consumer.accept(message.getMessageObject());
	}

}
