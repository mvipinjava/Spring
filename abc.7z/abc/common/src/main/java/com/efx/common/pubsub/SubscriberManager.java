package com.efx.common.pubsub;

import java.util.HashMap;
import java.util.Map;

public class SubscriberManager
{
	static SubscriberManager instance = null;
	
	Map<String, Subscriber> inUseSubscribers = new HashMap<String, Subscriber>();
	
	SubscriberManager () { }
	
	public static SubscriberManager getInstance()
	{
		if (instance == null)
		{
			instance = new SubscriberManager();
		}
		return instance;
	}
	
    public Subscriber getSubscriber(String name)
	{
    	// see if there is already a Subscriber of this name in use
    	Subscriber thisSubscriber = inUseSubscribers.get(name);
    	if (thisSubscriber == null)
    	{
        	// only Hazelcast Subscriber, at this time
    		thisSubscriber = new HazelcastSubscriber(name);
    		inUseSubscribers.put(name,  thisSubscriber);
    	}
    	
    	return thisSubscriber;
	}

}
