package com.efx.common.utils;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PropertyUtils
{
	static PropertyUtils instance = null;
	
	Properties properties = null;
	
	PropertyUtils () { }
	
	public static synchronized PropertyUtils getInstance()
	{
		if (instance == null)
		{
			instance = new PropertyUtils();
			instance.loadProperties();
		}
		return instance;
	}
	
	void loadProperties ()
	{
		ClassLoader loader = Thread.currentThread().getContextClassLoader();
		properties = new Properties();
		try (InputStream resourceStream = loader.getResourceAsStream("application.properties"))
		{
		    properties.load(resourceStream);
		} catch (IOException e) {
		    e.printStackTrace();
		}
	}
	
	public String getProperty (String name)
	{
		String retval = properties.getProperty(name);
		if (retval != null)
		{
			retval = retval.trim();
		}
		return retval;
	}


	public String getProperty (String name, String defaultValue)
	{
		String retval = getProperty(name);
		return (retval == null) ? defaultValue : retval;
	}
}
