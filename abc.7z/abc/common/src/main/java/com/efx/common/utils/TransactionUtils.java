package com.efx.common.utils;

import java.util.Map;

import com.efx.common.constants.TopicNameConstants;
import com.efx.common.shared.TransactionMap;
import com.efx.common.shared.TransactionWrapper;
import com.hazelcast.core.IMap;

public class TransactionUtils implements TopicNameConstants
{
    String queueName = REQUEST_TOPIC_NAME;

    IMap<String, TransactionWrapper> queue;

    static TransactionUtils instance = null;
	
	TransactionUtils () { }
	
	void init()
	{
		queue = HazelcastUtils.getInstance().getHazelcastInstance().getMap(queueName);
	}
	
	public static TransactionUtils getInstance()
	{
		if (instance == null)
		{
			instance = new TransactionUtils();
			instance.init();
		}
		return instance;
	}
	
	public TransactionMap getTransactionMap (String sha)
	{
		TransactionWrapper wrapper = queue.get(sha);
		return wrapper.getTransactionMap();
	}
	
	public Map<String, String> getResponseMap (String sha)
	{
		TransactionWrapper wrapper = queue.get(sha);
		return wrapper.getResponseMap();
	}
	
	public void addResponseMap (String sha, Map<String, String> map)
	{
		TransactionWrapper wrapper = queue.get(sha);
		wrapper.setResponseMap(map);
		queue.put(sha, wrapper);
	}
}
