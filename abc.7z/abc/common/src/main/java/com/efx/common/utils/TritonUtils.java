package com.efx.common.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.efx.common.constants.TransactionMapConstants;
import com.efx.common.constants.TritonConstants;

public class TritonUtils implements TransactionMapConstants, TritonConstants
{
	static TritonUtils instance = null;
	
	int sysTraceAuditNum = 0;
	
	TritonUtils () { }
	
	public static TritonUtils getInstance()
	{
		if (instance == null)
		{
			instance = new TritonUtils();
		}
		return instance;
	}
	
	public List<String> getRequestList(Map<String, String> map)
	{
		List<String> retval = new ArrayList<String>();
		String incomingRequest = map.get(TM_PARSED_ISO_REQUEST);
		String messageParams[] = incomingRequest.split(FS);
		
		int index = 0;
		for (String reqParam : messageParams)
		{
			if (reqParam.contains(STX))
			{
				messageParams[index] = reqParam.replace(STX, "");
			}
			if (reqParam.contains(ETX))
			{
				messageParams[index] = reqParam.replace(ETX, "");
			}
			index++;
		}

		retval = new ArrayList<String>();
		for (String reqParams : messageParams)
		{
			retval.add(reqParams);
		}
		return retval;
	}
	
	public synchronized String getSysTraceAuditNumber() {
		
		if (sysTraceAuditNum < 999999)
		{
			sysTraceAuditNum++;
		} else {
			sysTraceAuditNum = 1;
		}
		return String.format("%06d", sysTraceAuditNum);
	}
}
