package com.efx.common.base;

import java.util.Date;

import lombok.*;

@Getter
@Setter
public class ExpObjTest implements ExportableObject
{
	Long id;
	String name;
	long longValue;
	int intValue;
	Date dateValue;
	boolean booleanValue;
/*	
	public static void main(String[] args)
	{
		ExpObjTest test1 = new ExpObjTest();
		ExpObjTest test2 = new ExpObjTest();
		
		test1.id = 6809L;
		test1.name = "foo";
		test1.longValue = 6502;
		
		test2.id = 6809L;
		test2.longValue = 6502;

		test2.name = "bar";
		test2.booleanValue = true;
		test2.intValue = 73;
		test2.dateValue = new Date();
		
		try {
			test1.exportAdd(null, 1);
		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			test2.exportUpdate(null, test1, 1);
		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			test2.exportDelete(null, 1);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
*/
}
