package com.efx.common.pubsub;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.*;
import org.mockito.junit.jupiter.*;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.*;

import com.efx.common.utils.HazelcastUtils;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.core.ITopic;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("PublisherManager")
class TestPublisherManager
{
	PublisherManager cut = null;	// cut = class under test

	@Mock
	HazelcastUtils utils;
	
	@Mock
	HazelcastInstance hazelcastInstance;
	
	@Mock
	ITopic<String> topic;
	
	@Mock
	Publisher pub;
	
	@BeforeEach
	void init()
	{
		cut = new PublisherManager();
	}
	
	@AfterEach
	void cleanup()
	{
		PublisherManager.instance = null;
		HazelcastPublisher.utils = null;
	}
	
	// Constructor
	@Test
	@DisplayName("constructor")
	void testPublisherManager ()
	{
		assertAll (() -> assertNull (PublisherManager.instance, () -> "The default constructor did not initialze the instance property to the expected value"),
				   () -> assertNotNull (cut.inUsePublishers, () -> "The default constructor did not initialze the inUsePublishers property to the expected value"));
	}

	@Nested
	@DisplayName("static getInstance method")
	class getInstance
	{
		@Test
		@DisplayName("executed properly")
		void testGetInstance ()
		{
			// this is for testing the static method: getInstance
			assertNotNull (PublisherManager.getInstance(), () -> "Test of getInstance did not return the expected results");
		}
		
		@Test
		@DisplayName("retrieved saved value properly")
		void testGetInstance_retrieved ()
		{
			// now try for when instance is already initialized
			com.efx.common.pubsub.PublisherManager val = new com.efx.common.pubsub.PublisherManager();
			PublisherManager.instance = val;
			assertEquals (val, PublisherManager.getInstance(), () -> "Test of getInstance did not return the expected results");
		}
	}

	@Test
	@DisplayName("getPublisher method")
	void testGetPublisher ()
	{
		// First call creates it new
		HazelcastPublisher.utils = utils;
		when(utils.getHazelcastInstance()).thenReturn(hazelcastInstance);
		Publisher pub = cut.getPublisher("test");

		assertEquals(pub, cut.getPublisher("test"), () -> "The second call to getPublisher did not return the expected value");
	}
}
