package com.efx.common.shared;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.*;
import org.mockito.junit.jupiter.*;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

@ExtendWith(MockitoExtension.class)
@DisplayName("TransactionMap")
class TestTransactionMap
{
	TransactionMap cut = null;	// cut = class under test

	@BeforeEach
	void init()
	{
		cut = new TransactionMap();
	}
	
	// Test all 2 Constructors in this method
	@Nested
	@DisplayName("constructors")
	class constructors
	{
		@Test
		@DisplayName("default constructor")
		void testTransactionMap ()
		{
			assertNotNull (cut.innerMap, () -> "The default constructor did not initialize the innerMap");
		}
		
		@Test
		@DisplayName("constructor with map")
		void testTransactionMap_withMap ()
		{
			Map<String, String> fromMap = new HashMap<String, String>();
			cut = new TransactionMap(fromMap);
			assertEquals (fromMap, cut.innerMap, () -> "The constructor did not initialize the innerMap");
		}
	}
	
	@Nested
	@DisplayName("innerMap property")
	class innerMap
	{
		@Test
		@DisplayName("getter")
		void testGetInnerMap()
		{
			Map<String, String> fromMap = new HashMap<String, String>();
			cut.innerMap = fromMap;
			assertEquals (fromMap, cut.getInnerMap(), () -> "The getInnerMap method did not return the expected value");
		}
		
		@Test
		@DisplayName("setter")
		void testSetInnerMap()
		{
			Map<String, String> fromMap = new HashMap<String, String>();
			cut.innerMap = null;
			cut.setInnerMap(fromMap);
			assertEquals (fromMap, cut.innerMap, () -> "The setInnerMap method did not return the expected value");
		}
	}
	
	@Nested
	@DisplayName("size method")
	class size
	{
		@Test
		@DisplayName("initial value tested")
		void testSize ()
		{
			assertEquals (0, cut.size(), () -> "The size method did not return the expected value");
		}
		
		@Test
		@DisplayName("value checked after addition")
		void testSize_changed ()
		{
			cut.innerMap.put("1", "test");
			assertEquals (1, cut.size(), () -> "The size method did not return the expected value");
		}
	}
	
	@Nested
	@DisplayName("isEmpty method")
	class isEmpty
	{
		@Test
		@DisplayName("initial value tested")
		void testIsEmpty ()
		{
			assertTrue (cut.isEmpty(), () -> "The isEmpty method did not return the expected value");
		}
		
		@Test
		@DisplayName("value checked after addition")
		void testIsEmpty_changed ()
		{
			cut.innerMap.put("1", "test");
			assertFalse (cut.isEmpty(), () -> "The isEmpty method did not return the expected value");
		}
	}
	
	@Nested
	@DisplayName("containsKey method")
	class containsKey
	{
		@Test
		@DisplayName("initial value tested")
		void testContainsKey ()
		{
			assertFalse (cut.containsKey("1"), () -> "The containsKey method did not return the expected value");
		}
		
		@Test
		@DisplayName("value checked after addition")
		void testContainsKey_changed ()
		{
			cut.innerMap.put("1", "test");
			assertTrue (cut.containsKey("1"), () -> "The containsKey method did not return the expected value");
		}
	}
	
	@Nested
	@DisplayName("containsValue method")
	class containsValue
	{
		@Test
		@DisplayName("initial value tested")
		void testContainsValue ()
		{
			assertFalse (cut.containsValue("test"), () -> "The containsValue method did not return the expected value");
		}
		
		@Test
		@DisplayName("value checked after addition")
		void testContainsValue_changed ()
		{
			cut.innerMap.put("1", "test");
			assertTrue (cut.containsValue("test"), () -> "The containsValue method did not return the expected value");
		}
	}
	
	@Nested
	@DisplayName("get method")
	class get
	{
		@Test
		@DisplayName("initial value tested")
		void testGet ()
		{
			assertNull (cut.get("1"), () -> "The get method did not return the expected value");
		}
		
		@Test
		@DisplayName("value checked after addition")
		void testGet_changed ()
		{
			cut.innerMap.put("1", "test");
			assertEquals ("test", cut.get("1"), () -> "The get method did not return the expected value");
		}
	}
	
	@Test
	@DisplayName("put method")
	void testPut ()
	{
		assertThrows(UnsupportedOperationException.class, () -> cut.put("1", "test"), () -> "The put method should throw the UnsupportedOperationException");
	}

	@Test
	@DisplayName("remove method")
	void testRemove ()
	{
		assertThrows(UnsupportedOperationException.class, () -> cut.remove("1"), () -> "The remove method should throw the UnsupportedOperationException");
	}

	@Test
	@DisplayName("putAll method")
	void testPutAll ()
	{
		assertThrows(UnsupportedOperationException.class, () -> cut.putAll(null), () -> "The putAll method should throw the UnsupportedOperationException");
	}

	@Test
	@DisplayName("clear method")
	void testClear ()
	{
		assertThrows(UnsupportedOperationException.class, () -> cut.clear(), () -> "The clear method should throw the UnsupportedOperationException");
	}

	@Nested
	@DisplayName("keySet method")
	class keySet
	{
		@Test
		@DisplayName("initial value tested")
		void testKeySet ()
		{
			Set<String> results = cut.keySet();
			assertAll(() -> assertNotNull (results, () -> "The keySet method did not return the expected value"),
					  () -> assertEquals (0, results.size(), () -> "The keySet method did not return the expected value"));
		}
		
		@Test
		@DisplayName("value checked after addition")
		void testKeySet_changed ()
		{
			cut.innerMap.put("1", "test");
			Set<String> results = cut.keySet();
			assertAll (() -> assertNotNull (results, () -> "The keySet method did not return the expected value"),
					   () -> assertEquals (1, results.size(), () -> "The keySet method did not return the expected value"),
					   () -> assertTrue (results.contains("1"), () -> "The keySet method did not return the expected value"));
		}
	}
	
	@Nested
	@DisplayName("values method")
	class values
	{
		@Test
		@DisplayName("initial value tested")
		void testValues ()
		{
			Collection<String> results = cut.values();
			assertAll (() -> assertNotNull (results, () -> "The values method did not return the expected value"),
					   () -> assertEquals (0, results.size(), () -> "The values method did not return the expected value"));
		}
		
		@Test
		@DisplayName("value checked after addition")
		void testValues_changed ()
		{
			cut.innerMap.put("1", "test");
			Collection<String> results = cut.values();
			assertAll (() -> assertNotNull (results, () -> "The values method did not return the expected value"),
					   () -> assertEquals (1, results.size(), () -> "The values method did not return the expected value"),
					   () -> assertTrue (results.contains("test"), () -> "The values method did not return the expected value"));
		}
	}
	
	@Nested
	@DisplayName("entrySet method")
	class entrySet
	{
		@Test
		@DisplayName("initial value tested")
		void testEntrySet ()
		{
			Set<Entry<String, String>> results = cut.entrySet();
			assertNotNull (results, () -> "The entrySet method did not return the expected value");
			assertEquals (0, results.size(), () -> "The entrySet method did not return the expected value");
		}
		
		@Test
		@DisplayName("value checked after addition")
		void testEntrySet_changed ()
		{
			cut.innerMap.put("1", "test");
			Set<Entry<String, String>> results = cut.entrySet();
			assertAll (() -> assertNotNull (results, () -> "The entrySet method did not return the expected value"),
					   () -> assertEquals (1, results.size(), () -> "The entrySet method did not return the expected value"));
		}
	}
}
