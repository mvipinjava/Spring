package com.efx.common.utils;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.*;
import org.mockito.junit.jupiter.*;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.*;

import com.hazelcast.core.HazelcastInstance;

@ExtendWith(MockitoExtension.class)
@DisplayName("HazelcastUtils")
class TestHazelcastUtils
{
	HazelcastUtils cut = null;	// cut = class under test

	@Mock
	HazelcastInstance hazelcastInstance;
	
	@BeforeEach
	void init()
	{
		HazelcastUtils.instance = null;
		cut = new HazelcastUtils();
	}
	
	@AfterEach
	void cleanup()
	{
		HazelcastUtils.instance = null;
	}
	
	// Constructor
	@Test
	@DisplayName ("constructor")
	void testHazelcastUtils ()
	{
		assertAll (() -> assertNull(HazelcastUtils.instance, () -> "The constructor did not initialize the instance property to the expected value"),
				   () -> assertNull(cut.hazelcastInstance, () -> "The constructor did not initialize the hazelcastInstance property to the expected value"));
	}

	@Nested
	@DisplayName ("static getInstance method")
	class getInstance
	{
		@Test
		@DisplayName ("executes correctly")
		void testGetInstance ()
		{
			// this is for testing the static method: getInstance
			HazelcastUtils results = HazelcastUtils.getInstance();
			assertEquals (results, HazelcastUtils.instance, () -> "The 1st call to getInstance did not return the expected value");
		}
		
		@Test
		@DisplayName ("retrieves saved instance properly")
		void testGetInstance_retrieve ()
		{
			com.efx.common.utils.HazelcastUtils val = new com.efx.common.utils.HazelcastUtils();
			HazelcastUtils.instance = val;
			assertEquals (val, HazelcastUtils.getInstance(), () -> "The 2nd call to getInstance did not return the expected results");
		}
	}
	
	@Nested
	@DisplayName ("getHazelcastInstance method")
	class getHazelcastInstance
	{
		@Test
		@DisplayName ("returns value correctly")
		void testGetHazelcastInstance ()
		{
			assertNull (cut.getHazelcastInstance(), () -> "The 1st test of getHazelcastInstance did not return the expected results");
		}
		
		@Test
		@DisplayName ("retrieves saved value correctly")
		void testGetHazelcastInstance_retrieves ()
		{
			cut.hazelcastInstance = hazelcastInstance;
			assertEquals (hazelcastInstance, cut.getHazelcastInstance(), () -> "The 2nd test of getHazelcastInstance did not return the expected results");
		}
	}
	
	@Nested
	@DisplayName ("createHazelcastInstance method")
	class createHazelcastInstance
	{
		@Test
		@DisplayName ("returns value correctly")
		void testCreateHazelcastInstance ()
		{
			HazelcastInstance results = cut.createHazelcastInstance(true);
			assertAll (() -> assertNotNull(results, () -> "The first call to createHazelcastInstance did not return the expected results"),
					   () -> assertEquals(results, cut.hazelcastInstance, () -> "The first call to createHazelcastInstance did not return the expected value"));
		}
		
		@Test
		@DisplayName ("retrieves saved value correctly")
		void testCreateHazelcastInstance_retrieved ()
		{
			cut.hazelcastInstance = hazelcastInstance;
			// now should return the same value
			assertEquals(hazelcastInstance, cut.createHazelcastInstance(true), () -> "The second call to createHazelcastInstance did not return the expected value");
		}
		
		@Disabled
		@Test
		@DisplayName ("returns value if reset to null")
		void testCreateHazelcastInstance_returns ()
		{
			// and this is to test creating a client instance
			cut.hazelcastInstance = null;
			HazelcastInstance results = cut.createHazelcastInstance(false);
			assertNotNull(results, () -> "The third call to createHazelcastInstance did not return the expected value");
		}
	}
}
