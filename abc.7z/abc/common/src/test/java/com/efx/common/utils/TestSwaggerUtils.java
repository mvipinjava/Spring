package com.efx.common.utils;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.*;
import org.mockito.junit.jupiter.*;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("SwaggerUtils")
class TestSwaggerUtils
{
	SwaggerUtils cut = null;	// cut = class under test

	@BeforeEach
	void init()
	{
		cut = new SwaggerUtils();
	}
	
	// Constructor
	@Test
	@DisplayName("constructor")
	void testSwaggerUtils ()
	{
		assertNull (SwaggerUtils.instance, () -> "The constructor did not initialize the instance property to the expected value");
	}

	@Nested
	@DisplayName("static getInstance method")
	class getInstance
	{
		@Test
		@DisplayName("executed properly")
		void testGetInstance ()
		{
			// this is for testing the static method: getInstance
			SwaggerUtils results = SwaggerUtils.getInstance();
			assertEquals(results, SwaggerUtils.instance, () -> "The 1st call to getInstance did not return the expected results");
		}
		
		@Test
		@DisplayName("retrieved saved value properly")
		void testGetInstance_retrieved ()
		{
			com.efx.common.utils.SwaggerUtils val = new com.efx.common.utils.SwaggerUtils();
			SwaggerUtils.instance = val;
			assertEquals (val, SwaggerUtils.getInstance(), () -> "The 2nd call to getInstance did not return the expected results");
		}
	}
	
	@Test
	@DisplayName("getSwaggerDocket method")
	void testGetSwaggerDocket ()
	{
		assertNotNull (cut.getSwaggerDocket("test", "Description"), () -> "The call to the getSwaggerDocket method did not return the expected value");
	}

}
