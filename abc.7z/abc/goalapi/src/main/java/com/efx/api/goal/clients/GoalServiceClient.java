package com.efx.api.goal.clients;

import javax.validation.constraints.NotNull;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.efx.api.goal.pojos.ServiceRequest;

@FeignClient("GoalService")
public interface GoalServiceClient
{
    @PostMapping(path = "/goal/update/id", consumes = MediaType.APPLICATION_JSON_VALUE)
    boolean updateGoalById (@RequestBody @NotNull ServiceRequest request);

    @PostMapping(path = "/goal/update/name", consumes = MediaType.APPLICATION_JSON_VALUE)
    boolean updateGoalByGoalTypeName (@RequestBody @NotNull ServiceRequest request);
}
