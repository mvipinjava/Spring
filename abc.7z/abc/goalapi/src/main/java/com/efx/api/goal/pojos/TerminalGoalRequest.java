package com.efx.api.goal.pojos;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class TerminalGoalRequest implements Serializable
{
	private static final long serialVersionUID = 1L;

	long goal_value;
	long terminal_id;
}
