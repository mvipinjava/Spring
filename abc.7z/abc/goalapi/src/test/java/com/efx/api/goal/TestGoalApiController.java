package com.efx.api.goal;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import static org.mockito.Mockito.*;

import java.util.Optional;

import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.efx.api.goal.clients.GoalServiceClient;
import com.efx.api.goal.clients.UserServiceClient;
import com.efx.api.goal.pojos.GoalRequest;
import com.efx.api.goal.pojos.TerminalGoalRequest;

@ExtendWith(MockitoExtension.class)
@DisplayName("GoalApiController")
class TestGoalApiController
{
	GoalApiController cut;
	
	@Mock
	GoalServiceClient client;
	
	@Mock
	UserServiceClient userClient;
	
	@Mock
	GoalRequest request;
	
	@Mock
	TerminalGoalRequest termRequest;

	@BeforeEach
	void init()
	{
		cut = new GoalApiController();
	}
	
	@DisplayName ("initialization")
	@Test
	void testInit()
	{
		cut.init();
		assertNotNull (cut.logger, () -> "The init method did not set the logger variable with the expected value");
	}
	
	@Nested
	@DisplayName ("getUserId method")
	class getUserId
	{
		@Test
		@DisplayName ("found successfully")
		void testGetUserId()
		{
			Optional<Long> opt = Optional.of(12L);
			cut.userClient = userClient;
			when(userClient.getUserIdByUserName("foo")).thenReturn(opt);
			assertEquals(cut.getUserId("foo"), 12L, () -> "The call to getUserId did not return the expected value");
		}
		
		@Test
		@DisplayName ("not found")
		void testGetUserId_notFound()
		{
			Optional<Long> opt = Optional.empty();
			cut.userClient = userClient;
			when(userClient.getUserIdByUserName("foo")).thenReturn(opt);
			assertEquals(cut.getUserId("foo"), 0L, () -> "The call to getUserId did not return the expected value");
		}
	}
	
	@DisplayName ("constructor")
	@Test
	void testConstructor()
	{
		assertAll(
				() -> assertNull (cut.logger, () -> "Constructor did not have logger variable set with the expected value"),
				() -> assertNull (cut.restTemplate, () -> "Constructor did not have restTemplate variable set with the expected value"),
				() -> assertNull (cut.client, () -> "Constructor did not have client variable set with the expected value"),
				() -> assertNull (cut.userClient, () -> "Constructor did not have userClient variable set with the expected value"));
	}

	@Test
	@DisplayName ("updateGlobalGoalById method")
	void testUpdateGlobalGoalById()
	{
		GoalApiController spy = spy (cut);
		doReturn(null).when(spy).updateGoalById(1L, 2L, "test", 0);
		when(request.getGoal_value()).thenReturn(2L);
		spy.updateGlobalGoalById(1L, request, "test");
	}
	
	@Test
	@DisplayName ("updateGlobalGoalByGoalTypeName method")
	void testUpdateGlobalGoalByGoalTypeName()
	{
		GoalApiController spy = spy (cut);
		doReturn(null).when(spy).updateGoalByTypeName("foo", 2L, "test", 0);
		when(request.getGoal_value()).thenReturn(2L);
		spy.updateGlobalGoalByGoalTypeName("foo", request, "test");
	}
	
	@Test
	@DisplayName ("updateTerminalGoalById method")
	void testUpdateTerminalGoalById()
	{
		GoalApiController spy = spy (cut);
		doReturn(null).when(spy).updateGoalById(1L, 2L, "test", 99L);
		when(termRequest.getGoal_value()).thenReturn(2L);
		when(termRequest.getTerminal_id()).thenReturn(99L);
		spy.updateTerminalGoalById(1L, termRequest, "test");
	}
	
	@Test
	@DisplayName ("updateTerminalGoalByGoalTypeName method")
	void testUpdateTerminalGoalByGoalTypeName()
	{
		GoalApiController spy = spy (cut);
		doReturn(null).when(spy).updateGoalByTypeName("foo", 2L, "test", 99L);
		when(termRequest.getGoal_value()).thenReturn(2L);
		when(termRequest.getTerminal_id()).thenReturn(99L);
		spy.updateTerminalGoalByGoalTypeName("foo", termRequest, "test");
	}
	
	@Nested
	@DisplayName ("updateGoalById method")
	class byId
	{
		@Test
		@DisplayName ("successful update")
		void testUpdateGoalById()
		{
			when(client.updateGoalById(any())).thenReturn(true);
			cut.client = client;
			GoalApiController spy = spy(cut);
			doReturn(12L).when(spy).getUserId("test");
			@SuppressWarnings("rawtypes")
			ResponseEntity reply = spy.updateGoalById(1L, 2L, "test", 0);
			assertEquals (reply.getStatusCode(), HttpStatus.NO_CONTENT, () -> "The value for updateGoalById for a true result was incorrect");
		}
		
		@Test
		@DisplayName ("failed update")
		void testUpdateGoalById_failed()
		{
			cut.client = client;
			GoalApiController spy = spy(cut);
			doReturn(12L).when(spy).getUserId("test");
			@SuppressWarnings("rawtypes")
			ResponseEntity reply = spy.updateGoalById(1L, 2L, "test", 0);
			assertEquals (reply.getStatusCode(), HttpStatus.INTERNAL_SERVER_ERROR, () -> "The value for updateGoalById for a false result was incorrect");
		}
	}
	
	@Nested
	@DisplayName ("updateGoalByTypeName method")
	class byTypeName
	{
		@Test
		@DisplayName ("successful update")
		void testUpdateGoalByTypeName()
		{
			cut.client = client;
			GoalApiController spy = spy(cut);
			doReturn(12L).when(spy).getUserId("test");
			when(client.updateGoalByGoalTypeName(any())).thenReturn(true);
			@SuppressWarnings("rawtypes")
			ResponseEntity reply = spy.updateGoalByTypeName("foo", 2L, "test", 99L);
			assertEquals (reply.getStatusCode(), HttpStatus.NO_CONTENT, () -> "The value for updateGoalByTypeName for a true result was incorrect");
		}
	
		@Test
		@DisplayName ("failed update")
		void testUpdateGoalByTypeName_failed()
		{
			cut.client = client;
			GoalApiController spy = spy(cut);
			doReturn(12L).when(spy).getUserId("test");
			when(client.updateGoalByGoalTypeName(any())).thenReturn(false);
			@SuppressWarnings("rawtypes")
			ResponseEntity reply = spy.updateGoalByTypeName("foo", 2L, "test", 99L);
			assertEquals (reply.getStatusCode(), HttpStatus.INTERNAL_SERVER_ERROR, () -> "The value for updateGoalByTypeName for a false result was incorrect");
		}
	}
}
