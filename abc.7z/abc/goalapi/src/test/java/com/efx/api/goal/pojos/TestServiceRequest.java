package com.efx.api.goal.pojos;

import java.beans.IntrospectionException;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.efx.POJOTester.POJOTester;

@DisplayName("ServiceRequest")
class TestServiceRequest
{
	@Test
	public void testBeanProperties() throws IntrospectionException
	{
	    POJOTester.test(ServiceRequest.class);
	}
	
	@Test
	void testConstructor ()
	{
		new ServiceRequest(1L, "test", 2L, 3L, 4L);
	}
}
