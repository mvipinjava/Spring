package com.efx.goal.pojos;

import com.efx.common.base.ExportableObject;

import lombok.*;

@Setter
@Getter
public class Goal implements ExportableObject
{
	Long id;
	Long userId;
	Long deviceId;		// if this is 0, then this is a global goal for the dashboard
	Long goalTypeId;
	Long goalValuePerMonth;		// this is assigned
	Long goalValuePerWeek;		// this is derived from monthly value
	Long goalValuePerDay;		// this is derived from monthly value
	
	void setGoalValuePerMonth (long value)
	{
		this.goalValuePerMonth = value;
		this.goalValuePerWeek = value / 4;
		this.goalValuePerDay = value / 30;
	}
}
