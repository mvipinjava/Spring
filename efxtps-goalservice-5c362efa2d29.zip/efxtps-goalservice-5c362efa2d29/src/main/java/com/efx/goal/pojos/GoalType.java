package com.efx.goal.pojos;

import com.efx.common.base.ExportableObject;

import lombok.*;

@Setter
@Getter
public class GoalType implements ExportableObject
{
	Long id;
	String name;
}
