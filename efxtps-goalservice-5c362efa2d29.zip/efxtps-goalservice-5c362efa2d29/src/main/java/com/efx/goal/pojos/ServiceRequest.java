package com.efx.goal.pojos;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
public class ServiceRequest implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	long id;
	String name;
	long value;
	long userid;
	long terminal_id;
}
