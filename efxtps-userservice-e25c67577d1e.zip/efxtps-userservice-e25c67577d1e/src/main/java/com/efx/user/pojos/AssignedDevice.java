package com.efx.user.pojos;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class AssignedDevice
{
	Long id;
	Long userId;
	Long deviceId;
}
