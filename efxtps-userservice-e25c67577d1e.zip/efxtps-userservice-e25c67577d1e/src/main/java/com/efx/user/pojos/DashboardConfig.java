package com.efx.user.pojos;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class DashboardConfig
{
	Boolean dccTransactionCount;
	Boolean transactionCount;
	Boolean topEarningTerminal;
	Boolean goals;
	Boolean achievements;
	Boolean alerts;
	Boolean totalTerminals;
}
