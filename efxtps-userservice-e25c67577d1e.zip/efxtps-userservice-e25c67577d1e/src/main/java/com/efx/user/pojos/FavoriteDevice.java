package com.efx.user.pojos;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class FavoriteDevice
{
	Long id;
	Long userId;
	Long deviceId;
}