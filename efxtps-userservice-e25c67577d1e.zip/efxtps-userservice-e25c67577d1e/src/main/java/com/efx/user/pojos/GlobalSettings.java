package com.efx.user.pojos;

import java.util.Date;

import com.efx.common.base.ExportableObject;

import lombok.*;

@Setter
@Getter
public class GlobalSettings implements ExportableObject
{
	Long id;
	Long userId;
	
	DashboardConfig dashboardConfig;
	
	Long termsVersion = 0L;
	Date termsAgreement;
}
