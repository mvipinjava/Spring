package com.efx.user.pojos;

public enum UserStatus
{
    ACTIVE("A"), LOCKED("L"), DISABLED("D");

    private String code;
 
    private UserStatus(String code)
    {
        this.code = code;
    }
 
    public String getCode()
    {
        return code;
    }
}