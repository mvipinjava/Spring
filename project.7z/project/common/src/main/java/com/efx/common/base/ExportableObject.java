package com.efx.common.base;

import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.efx.common.pubsub.Publisher;

/**
 * For an update operation, in the code, instead of this:
 * 		repo.save(obj);
 * Do this:
 * 		origObj = repo.findById (obj.getId());
 * 		obj.exportUpdate(pub, origObj, userid);
 * 		repo.save(obj);
 * 
 * For an add operation, in the code, instead of this:
 * 		obj.setId(0);
 * 		repo.save(obj);
 * Do this:
 * 		obj.setId(0);
 * 		repo.save(obj);
 * 		obj.exportAdd (pub, userid);
 * 
 * For a delete operation, in the code, instead of this:
 * 		repo.remove(obj);
 * Do this:
 * 		obj.exportDelete (pub, userid);
 * 		repo.remove(obj);
 * 
 * @author brianlantz
 *
 */
public interface ExportableObject
{
	public static final String DATE_FORMAT_PATTERN = "yyyy-MM-dd HH:mm:ss.SSS Z";
	public static final String DELETE_ACTION = "delete";
	public static final String ADD_ACTION = "add";
	public static final String UPDATE_ACTION = "update";
	
	Long getId();
	
	public default void exportUpdate (Publisher pub, ExportableObject original, long userId)
	{
		// build the data needed for sending to the publisher connected to the export topic
		pub.publish(exportDiffMap(original, userId));
	}

	public default void exportAdd (Publisher pub, long userId)
	{
		// build the data needed for sending to the publisher connected to the export topic
		pub.publish(exportNewMap(userId));
	}

	public default void exportDelete (Publisher pub, long userid)
	{
		// build the data needed for sending to the publisher connected to the export topic
		Map<String,String> map = exportStartMap(userid);
		map.put("exportAction", DELETE_ACTION);
		map.put("id", "" + this.getId());
		pub.publish(map);
	}

	default Map<String,String> exportStartMap (long userid)
	{
		Map<String,String> retval = new HashMap<String,String>();
		retval.put("exportUserid", "" + userid);
		SimpleDateFormat format = new SimpleDateFormat(DATE_FORMAT_PATTERN);		
		retval.put("exportedAt", format.format(new Date()));
		retval.put("class", this.getClass().getSimpleName());
		return retval;
	}

	default Map<String,String> exportNewMap (long userid)
	{
		Map<String,String> retval = exportStartMap (userid);
		retval.put("exportAction", ADD_ACTION);
		
		// add all fields
        try
        {
	        final PropertyDescriptor[] props = Introspector.getBeanInfo(this.getClass()).getPropertyDescriptors();
	        nextProp: for (PropertyDescriptor prop : props)
	        {
	        	String propName = prop.getName();
	        	if (propName.equals("class"))
	        	{
	        		continue nextProp;
	        	}
	            Field field = this.getClass().getDeclaredField(propName);
	            final Object myValue = field.get(this);
	            String value = exportGetFieldValue(myValue);
	            // next line will need some work
	            retval.put(propName, value);
	        }
        } catch (Exception e) {
        	e.printStackTrace();
        }
		return retval;
	}

	default Map<String,String> exportDiffMap (ExportableObject original, long userid)
	{
		Map<String,String> retval = exportStartMap (userid);
		Class<?> clazz = this.getClass();
		if(! clazz.equals(original.getClass()))
		{
			System.err.println ("The original class is not the same as the current class get getDiffMap");
			return retval;
		}
		retval.put("exportAction", UPDATE_ACTION);
		retval.put("id", "" + this.getId());

		// add all changed fields
        try
        {
	        final PropertyDescriptor[] props = Introspector.getBeanInfo(clazz).getPropertyDescriptors();
	        nextProp: for (PropertyDescriptor prop : props)
	        {
	        	String propName = prop.getName();
	        	if (propName.equals("class") || propName.equals("id"))
	        	{
	        		continue nextProp;
	        	}
	            Field field = this.getClass().getDeclaredField(propName);
	            final Object myValue = field.get(this);
	            final Object origValue = field.get(original);
	            if (myValue != null && ! myValue.equals(origValue))
	            {
		            // next lines will need some work
		            String value = exportGetFieldValue(myValue);;
		            retval.put(propName, value.toString());
		            value = exportGetFieldValue(origValue);
		            retval.put("exportOrig-" + propName, value);
	            }
	        }
        } catch (Exception e) {
        	e.printStackTrace();
        }
		return retval;
	}
	
	default String exportGetFieldValue(Object field)
	{
		String retval = "";
		if (field != null)
		{
			if (field.getClass().getSimpleName().equals("Date"))
			{
				SimpleDateFormat format = new SimpleDateFormat(DATE_FORMAT_PATTERN);		
				retval = format.format((Date) field);
			} else {
				retval = field.toString();
			}
		}
		return retval;
	}
}
