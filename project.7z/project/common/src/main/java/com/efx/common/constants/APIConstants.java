package com.efx.common.constants;

public interface APIConstants
{
	public static final String JWT_CACHEMAP_NAME = "jwt";
	public static final String API_VERSION_HEADER = "API_VERSION";
}
