package com.efx.common.constants;

public interface AllConstants extends TopicNameConstants, TransactionMapConstants, ServiceConstants
{

}
