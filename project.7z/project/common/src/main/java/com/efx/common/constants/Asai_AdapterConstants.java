package com.efx.common.constants;

public interface Asai_AdapterConstants {
	/*  EMAIL CONSTANTS */
	/** The Constant EMAIL_PROP_SMTP_HOST. */
	static final String EMAIL_PROP_SMTP_HOST = "mail.smtp.host";
	
	/** The Constant EMAIL_PROP_USER_ID. */
	static final String EMAIL_PROP_USER_ID = "mail.smtp.username";
	
	/** The Constant EMAIL_PROP_PASSWORD. */
	static final String EMAIL_PROP_PASSWORD = "mail.smtp.password";
	
	/** The Constant EMAIL_PROP_PORT. */
	static final String EMAIL_PROP_PORT = "mail.smtp.port";
	
	/** The Constant EMAIL_PROP_SOCKET_PORT. */
	static final String EMAIL_PROP_SOCKET_PORT = "mail.smtp.socketFactory.port";
	
	/** The Constant EMAIL_PROP_SOCKET_CLASS. */
	static final String EMAIL_PROP_SOCKET_CLASS = "mail.smtp.socketFactory.class";
	
	/** The Constant EMAIL_PROP_TLS_FLAG. */
	static final String EMAIL_PROP_TLS_FLAG = "mail.smtp.starttls.enable";
	
	/** The Constant EMAIL_PROP_AUTH. */
	static final String EMAIL_PROP_AUTH = "mail.smtp.auth";
	
	public static final int TRITON = 1;
	public static final int M91X = 2;
	public static final int TIDEL = 3;
	public static final int CSP = 4;
	
	public static final String STX = "" + (char)0x02;
	public static final String FS = "" + (char)0x1c;
	public static final String ETX = "" + (char)0x03;
	public static final String EOT = "" + (char)0x04;
	public static final String ENQ = "" + (char)0x05;
	public static final String ACK = "" + (char)0x06;
	public static final String EMPTY = "";
	public static final String SYNC = ""+ (char)0x16;
	
	
	public static final int MAX_SSL_SOCKETS = 500;
	public static final String STATUS_ACTIVE = "AC";
	
	static final int EVENT_TRACK = 1;
	static final int TXN_TRACE = 2;
	static final int ALERT_OBJ = 3;
	static final int TXN_OBJ = 4;

	static final int INFO_LOG = 1;
	static final int WARN_LOG = 2;
	static final int DEBUG_LOG = 3;
	static final int ERROR_LOG = 4;
	static final int ERROR_LOG_STACK = 5;
	
	static final String TXN_QUE = "Transaction_Queue";
	static final String ALERT_QUE = "Alert_Queue";
	static final String EVENT_QUE = "Event_Queue";
	static final String TXNDB_QUE = "Transaction_Database_Queue";
	static final String MSGKEY = "Message_Key";
	public String EMULATION_TYPE_1="EmulationType";
	public String MODEL_ID_1="ModelID";
	
	static final int ADAPTER_TRITON_LISTENPORT=4000;
	static final int ADAPTER_91X_LISTENPORT=4141;
	static final String SERVER_IP = "localhost";
	
	static final String RESOURCE_FILE_PATH="adapter-config.xml";
	static final String PROPERTIES_FILE_PATH="server-configure.properties";
	
	static final String ZERO="0";
	static final int TWO=2;
	
	// Adapter Config PATH
		public static final String ADPTRPATH="resources/adapter/adapter-config.properties";
		
	public static final String HSM_HOST = "HSM_IP";
	public static final String HSM_PORT = "HSM_PORT";
	
	public static final String HSM_HOST1 = "HSM_IP1";
	public static final String HSM_PORT1 = "HSM_PORT1";
	
	public static final String VTWO_HSM_HOST = "VTWO_HSM_HOST";
	public static final String VTWO_HSM_PORT = "VTWO_HSM_PORT";
	
	public static final String VTWO_HSM_HOST_S = "VTWO_HSM_HOST_S";
	public static final String VTWO_HSM_PORT_S = "VTWO_HSM_PORT_S";
	
	public static final String PULSE_HSM_HOST1 = "PULSE_HSM_HOST1";
	public static final String PULSE_HSM_PORT1 = "PULSE_HSM_PORT1";
	
	
	public static final String VTWO_BDK = "VTWO_BDK";	
	public static final String VTHREE_BDK = "VTHREE_BDK";
}

