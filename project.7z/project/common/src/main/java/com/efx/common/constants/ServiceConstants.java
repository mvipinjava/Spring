package com.efx.common.constants;

public interface ServiceConstants
{
	static final String PROCESSOR_TYPE = "processorType";

	static final Long SYSTEM_USER = 0L;
}
