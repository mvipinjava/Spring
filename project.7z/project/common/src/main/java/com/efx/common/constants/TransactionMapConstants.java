package com.efx.common.constants;

public interface TransactionMapConstants
{
	// TransactionMap fields that align to ISO fields
	public static final String TM_REQUEST = "0";

	/*
	 * Transaction Common Parameters
	 */
	/** The record format. */
//	public static final String TM_RECORD_FORMAT = "2";
	
	/** The merchant number. */
	public static final String TM_MERCHANT_NUMBER = "3.0";
	/** The user name. */
//	public static final String TM_USER_NAME = "3.2";
	/** The password. */
//	public static final String TM_PASSWORD = "3.3";
	/** The transaction created by. */
//	public static final String TM_TRANSACTION_CREATED_BY = "3.4";
//	public static final String TM_MERCHANT_TYPE = "3.5";
	/** The terminal location. */
//	public static final String TM_TERMINAL_LOCATION = "3.6";
	/** The terminal address. */
//	public static final String TM_TERMINAL_ADDRESS = "3.7";
//	public static final String TM_WPDE43 = "3.8";
//	public static final String TM_USDE43 = "3.9";
//	public static final String TM_USDE48 = "3.10";
//	public static final String TM_USDE120 = "3.11";
//	public static final String TM_USDE127 = "3.12";
//	public static final String TM_PULSEADDRESS = "3.20";

	/** The terminal number. */
	public static final String TM_TERMINAL_NUMBER = "4.0";
	/** The trans seq no. */
//	public static final String TM_TRANS_SEQ_NO = "4.1";
	/** The batch number. */
//	public static final String TM_BATCH_NUMBER = "4.2";
	/** The vt batch id. */
//	public static final String TM_VT_BATCH_ID = "4.3";
	/** The device id. */
//	public static final String TM_DEVICE_ID = "4.5";
//	public static final String TM_PIN_BLOCK = "4.7";
//	public static final String TM_MISC_1 = "4.8";
//	public static final String TM_MISC_2 = "4.9";
//	public static final String TM_MISC_X = "4.10";
//	public static final String TM_MODEL_ID = "4.11";
//	public static final String TM_HOST_TOTALS = "4.12";
//	public static final String TM_WITHDRAWAL_TOTALS = "4.13";
//	public static final String TM_INQUIRY_TOTALS = "4.14";
//	public static final String TM_TRANSFER_TOTALS = "4.15";
//	public static final String TM_SETT_AMOUNT = "4.16";
//	public static final String TM_MGMTDATA = "4.17";
//	public static final String TM_LASTTXNTIME = "4.18";
//	public static final String TM_LASTTXNDATA = "4.19";
//	public static final String TM_DEFAULT_FEE = "4.20";
	public static final String TM_FUNCTION_FLAG = "4.21";
	public static final String TM_IS_EMV = "4.22";
	public static final String TM_IS_FALL_BACK = "4.23";
	public static final String TM_ROUTING_CODE = "4.25";
//	public static final String TM_REVERSAL_TOTAL = "4.26";
//	public static final String TM_FEE_TOTAL = "4.27";
//	public static final String TM_NON_CASH_SETT_AMOUNT = "4.28";

	// ------------------------------------------------------
	/*
	 * Customer Billing and Shipping Addresses
	 */
	/** The avs data flag. */
//	public static final String TM_AVS_DATA_FLAG = "5.0";
	/** The customer first name. */
//	public static final String TM_CUSTOMER_FIRST_NAME = "5.1";
	/** The customer last name. */
//	public static final String TM_CUSTOMER_LAST_NAME = "5.2";
	/** The customer company name. */
//	public static final String TM_CUSTOMER_COMPANY_NAME = "5.3";
	/** The customer job title. */
//	public static final String TM_CUSTOMER_JOB_TITLE = "5.4";
	/** The customer email id. */
//	public static final String TM_CUSTOMER_EMAIL_ID = "5.5";
	/** The customer web. */
//	public static final String TM_CUSTOMER_WEB = "5.6";
	/** The customer phone number. */
//	public static final String TM_CUSTOMER_PHONE_NUMBER = "5.7";
	/** The customer phone ext. */
//	public static final String TM_CUSTOMER_PHONE_EXT = "5.8";
	/** The customer phone type. */
//	public static final String TM_CUSTOMER_PHONE_TYPE = "5.9";
	/** The CUSTOME r_ billin g_ addres s1. */
//	public static final String TM_CUSTOMER_BILLING_ADDRESS1 = "5.10";
	/** The CUSTOME r_ billin g_ addres s2. */
//	public static final String TM_CUSTOMER_BILLING_ADDRESS2 = "5.11";
	/** The customer billing add city. */
//	public static final String TM_CUSTOMER_BILLING_ADD_CITY = "5.12";
	/** The customer billing add state. */
//	public static final String TM_CUSTOMER_BILLING_ADD_STATE = "5.13";
	/** The customer billing add zip. */
//	public static final String TM_CUSTOMER_BILLING_ADD_ZIP = "5.14";
	/** The customer shipping add name. */
//	public static final String TM_CUSTOMER_SHIPPING_ADD_NAME = "5.15";
	/** The CUSTOME r_ shippin g_ addres s1. */
//	public static final String TM_CUSTOMER_SHIPPING_ADDRESS1 = "5.16";
	/** The CUSTOME r_ shippin g_ addres s2. */
//	public static final String TM_CUSTOMER_SHIPPING_ADDRESS2 = "5.17";
	/** The customer shipping add city. */
//	public static final String TM_CUSTOMER_SHIPPING_ADD_CITY = "5.18";
	/** The customer shipping add state. */
//	public static final String TM_CUSTOMER_SHIPPING_ADD_STATE = "5.19";
	/** The customer shipping add zip. */
//	public static final String TM_CUSTOMER_SHIPPING_ADD_ZIP = "5.20";

	/** The transaction code. */
//	public static final String TM_TRANSACTION_CODE = "6.0";
//	public static final String TM_FIELD_ID_CODE = "6.1";
//	public static final String TM_ENCRYPTED_PIN_KEY = "6.2";
//	public static final String TM_TRANSACTION_IS_AUTH = "6.3";
//	public static final String TM_OFFLINE_APPROVAL_CODE = "6.4";
	/** The PROCESSING code. */
//	public static final String TM_TRANSACTION_REFERENCE_ID = "6.5";
//	public static final String TM_PROCESSING_CODE = "6.6";
//	public static final String TM_ENCRYPTED_PIN_KEY2 = "6.7";
//	public static final String TM_ENCRYPTED_COMMS_KEY = "6.8";

	/** The transaction is auth. */
	/** The offline approval code. */
	/** The transaction reference id. */
	/** The card holderid data. */
//	public static final String TM_CARD_HOLDERID_DATA = "7.1";
	/** The account data src. */
//	public static final String TM_ACCOUNT_DATA_SRC = "7.2";
	public static final String TM_TRACK2_DATA_KEY = "7.3";
	/** The cvv code. */
//	public static final String TM_CVV_CODE = "7.4";
	/** The cvv data. */
//	public static final String TM_CVV_DATA = "7.5";
	/** The account type. */
	public static final String TM_ACCOUNT_TYPE = "7.6";

	/** The trans amt. */
	public static final String TM_TRANS_AMT = "8.1";
	/** The secondary amount. */
	public static final String TM_SECONDARY_AMOUNT = "8.2";
	/** The secondary amount. */
//	public static final String TM_AMOUNT_3 = "8.3";
	/** The surcharge amount. */
//	public static final String TM_SURCHARGE_AMOUNT = "8.4";
//	public static final String TM_REQUESTED_AMOUNT = "8.5";
//	public static final String TM_IS_COMMUNICATION_HEADER_PRESENT = "8.6";	
//	public static final String TM_ADD_FEE = "8.7";	
//	public static final String TM_SURCHARGE_CHARGED = "8.8";
	
	
//	public static final String TM_COMMUNICATIONS_ID = "9.0";
//	public static final String TM_TERMINAL_IDENTIFIER = "9.1";
//	public static final String TM_SOFTWARE_VER_NO = "9.2";
//	public static final String TM_ENCRYPTION_MODE = "9.3";
//	public static final String TM_INFORMATION_HEADER = "9.4";
	/** The transaction date. */
//	public static final String TM_TRANSACTION_DATE = "9.5";
	/** The transaction time. */
//	public static final String TM_TRANSACTION_TIME = "9.6";
	/** The transmission date and time format. */
// 	public static final String TM_TRANSMISSION_DATE_TIME = "9.7";
	/** The Capture date. */
//	public static final String TM_CAPTURE_DATE = "9.8";
	/** The Expiration date. */
//	public static final String TM_EXP_DATE = "9.9";
	public static final String TM_TERMINAL_TRANSACTION_DATE = "9.10";
	/** The transaction time. */
	public static final String TM_TERMINAL_TRANSACTION_TIME = "9.11";
	/** The transmission date and time format. */
//	public static final String TM_TERMINAL_TRANSMISSION_DATE_TIME = "9.12";
//	public static final String TM_VTWO_TERMINAL_TRANSACTION_DATE = "9.13";
//	public static final String TM_VTWO_TERMINAL_TRANSACTION_TIME = "9.14";
//	public static final String TM_VTHREE_TERMINAL_TRANSACTION_DATE = "9.15";
//	public static final String TM_VTHREE_TERMINAL_TRANSACTION_TIME = "9.16";
//	public static final String TM_TERMINAL_SETTLEMENT_DATE = "9.17";
//	public static final String TM_NETWORK_SETTLEMENT_DATE = "9.18";
//	public static final String TM_GATEWAY_SETTLEMENT_DATE = "9.19";

	/** The requested aci. */
//	public static final String TM_REQUESTED_ACI = "10.0";
	/** The commercial card request indicator code. */
//	public static final String TM_COMMERCIAL_CARD_REQUEST_INDICATOR_CODE = "10.2";
//	public static final String TM_TXNPINCOMMSKEY = "10.3";
//	public static final String TM_CURRENT_TXN_DATE_TIME = "10.4";
//	public static final String TM_PROCESSOR_TYPE = "10.10";

//	public static final String TM_UNIQUE_REQUEST_ID = "11";

	// ------------------------------------------------------
	/*
	 * Response Data(Both for Credit and Debit)
	 */
	/** The transaction response source. */
//	public static final String TM_TRANSACTION_RESPONSE_SOURCE = "12.0";
	/** The response code. */
//	public static final String TM_RESPONSE_CODE = "12.1";
	/** The approval code. */
//	public static final String TM_APPROVAL_CODE = "12.2";
	/** The response text. */
//	public static final String TM_RESPONSE_TEXT = "12.3";
	/** The transaction identifier. */
//	public static final String TM_TRANSACTION_IDENTIFIER = "12.4";
	/** The response transaction date. */
	/** The retrieval reference no. */
//	public static final String TM_RETRIEVAL_REFERENCE_NO = "12.7";
	/** The avs result code. */
//	public static final String TM_AVS_RESULT_CODE = "12.8";
	/** The authorization source code. */
//	public static final String TM_AUTHORIZATION_SOURCE_CODE = "12.9";
	/** The validation code. */
//	public static final String TM_VALIDATION_CODE = "12.10";
	/** The returned aci. */
//	public static final String TM_RETURNED_ACI = "12.11";
	/** The verification result. */
//	public static final String TM_VERIFICATION_RESULT = "12.12";
	/** The commercial card response indicator. */
//	public static final String TM_COMMERCIAL_CARD_RESPONSE_INDICATOR = "12.13";
	/** The partial approved amt. */
//	public static final String TM_PARTIAL_APPROVED_AMT = "12.14";
	/** The ph reference number. */
//	public static final String TM_PH_REFERENCE_NUMBER = "12.15";
	/** The risk status response code. */
//	public static final String TM_RISK_STATUS_RESPONSE_CODE = "12.16";
	/** The date time. */
//	public static final String TM_DATE_TIME = "12.17";
//	public static final String TM_MULTIBLOCK_INDICATOR = "12.18";
	public static final String TM_AUTH_NUMBER = "12.19";
//	public static final String TM_BUSINESS_DATE = "12.20";
	public static final String TM_ACCOUNT_BALANCE = "12.21";
//	public static final String TM_PAN_NUMBER = "12.22";
	/** The velocity update. */
//	public static final String TM_VELOCITY_UPDATE = "12.23";
	/** The velocity disp amt */
//	public static final String TM_VELOCITY_DISP_AMOUNT = "12.24";
	/** The velocity column. */
//	public static final String TM_VELOCITY_COLUMN = "12.25";
//	public static final String TM_AUTH_NUMBER_PULSE = "12.26";

	// -----------------------------------------------------------
	/*
	 * For Refund and Void Request Only(Credit and
	 * Debit(13.0,13.1,13.2,13.4),Debit(13.5,13.6))
	 */

	/** The reversal transaction identifier. */
//	public static final String TM_REVERSAL_TRANSACTION_IDENTIFIER = "13.0";
	/** The reversal approval code. */
//	public static final String TM_REVERSAL_APPROVAL_CODE = "13.1";
	/** The reversal transaction date. */
//	public static final String TM_REVERSAL_TRANSACTION_DATE = "13.2";
	/** The reversal transaction time. */
//	public static final String TM_REVERSAL_TRANSACTION_TIME = "13.3";
	/** The reversal retrieval reference no. */
//	public static final String TM_REVERSAL_RETRIEVAL_REFERENCE_NO = "13.4";
	/** The reversal system trace audit number. */
	public static final String TM_REVERSAL_SYSTEM_TRACE_AUDIT_NUMBER = "13.5";
	/** The reversal network identification code. */
//	public static final String TM_REVERSAL_NETWORK_IDENTIFICATION_CODE = "13.6";
	/** Datar return from processor DE - 44 */
//	public static final String TM_PROCESSOR_RET_DATA = "13.7";
	/** Datar return from Transcation Code MTI Change */
//	public static final String TM_REVERSAL_MTI_CHANGE = "13.8";

	// ------------------------------------------------------
	/*
	 * Response Data for Debit Card.
	 */
	/** The host message identifier. */
//	public static final String TM_HOST_MESSAGE_IDENTIFIER = "14.1";
	/** The system trace audit number. */
//	public static final String TM_SYSTEM_TRACE_AUDIT_NUMBER = "14.2";
	/** The network identification code. */
	public static final String TM_NETWORK_IDENTIFICATION_CODE = "14.3";
	/** The settlement date. */
	public static final String TM_SETTLEMENT_DATE = "14.4";
	/** The reimbursement attribute. */
//	public static final String TM_REIMBURSEMENT_ATTRIBUTE = "14.5";
	// For Database Insertion/Updation

//	public static final String TM_TXN_DATABASE = "15.0";
	// public static final String TM_Error Check
	public static final String TM_ErrorCheck = "15.1";
	/** Flag to check whether the txn came from abort participant */
//	public static final String TM_ABORTTXN = "15.2";

	public static final String TM_SYS_TIME = "16.0";
	// denomination of cassette balance
//	public static final String TM_CASSETTE_A_DENOMINATION = "16.1";
//	public static final String TM_CASSETTE_B_DENOMINATION = "16.2";
//	public static final String TM_CASSETTE_C_DENOMINATION = "16.3";
//	public static final String TM_CASSETTE_D_DENOMINATION = "16.4";

	// NOTES LOADED IN CASSETTE
//	public static final String TM_CASSETTE_A_NOTESLOADED = "16.5";
//	public static final String TM_CASSETTE_B_NOTESLOADED = "16.6";
//	public static final String TM_CASSETTE_C_NOTESLOADED = "16.7";
//	public static final String TM_CASSETTE_D_NOTESLOADED = "16.8";

	// NOTES DISPENSED FROM CASSETTE
//	public static final String TM_CASSETTE_A_NOTESDISPENSED = "16.9";
//	public static final String TM_CASSETTE_B_NOTESDISPENSED = "16.10";
//	public static final String TM_CASSETTE_C_NOTESDISPENSED = "16.11";
//	public static final String TM_CASSETTE_D_NOTESDISPENSED = "16.12";

//	public static final String TM_ISO_REQ = "17.0";
//	public static final String TM_ISO_RESP = "17.1";
//	public static final String TM_REQ_PORT = "17.2";
//	public static final String TM_REQ_LL = "17.3";
//	public static final String TM_REQ_SMFLAGS = "17.4";
	public static final String TM_STATUS_MONITORING_FIELD_KEY = "17.5";

	public static final String TM_DESTACC = "18.0";
	public static final String TM_TRANSACTIONDESC = "18.1";
	
//	public static final String TM_UNIQUE_REQUEST_ID1 = "41";

	// -----------------------------------------------------------
	/*
	 * Batch Request Fields
	 */
	/** The batch record count. */
//	public static final String TM_BATCH_RECORD_COUNT = "50.0";
	/** The batch transmission date. */
//	public static final String TM_BATCH_TRANSMISSION_DATE = "50.1";
	/** The batch hashing total. */
//	public static final String TM_BATCH_HASHING_TOTAL = "50.2";
	/** The batch net deposit. */
//	public static final String TM_BATCH_NET_DEPOSIT = "50.3";

	/** The batch detail data. */
//	public static final String TM_BATCH_DETAIL_DATA = "51";

	// ------------------------------------------------------
	/*
	 * Batch Response Fields For GB(Good Batch),QD(Duplicate Batch),RB(Rejected
	 * Batch)
	 */
	/** The batch record format. */
//	public static final String TM_BATCH_RECORD_FORMAT = "52.0";
	/** The batch application type. */
//	public static final String TM_BATCH_APPLICATION_TYPE = "52.1";
	/** The batch message delimiter. */
//	public static final String TM_BATCH_MESSAGE_DELIMITER = "52.2";
	/** The BATC h_ x25_ routin g_ id. */
//	public static final String TM_BATCH_X25_ROUTING_ID = "52.3";
	/** The batch record type. */
//	public static final String TM_BATCH_RECORD_TYPE = "52.4";
	/** The batch res record count. */
//	public static final String TM_BATCH_RES_RECORD_COUNT = "52.5";
	/** The batch response code. */
//	public static final String TM_BATCH_RESPONSE_CODE = "52.6";
	/** The batch res number. */
//	public static final String TM_BATCH_RES_NUMBER = "52.7";
	/** The batch filler zeros. */
//	public static final String TM_BATCH_FILLER_ZEROS = "52.8";
	/** The batch filler spaces. */
//	public static final String TM_BATCH_FILLER_SPACES = "52.9";
	// ------------------------------------------------------
	/*
	 * Both for ADLL Good Batch and Good Batch
	 */
	/** The batch res net deposit. */
//	public static final String TM_BATCH_RES_NET_DEPOSIT = "52.11";
	/** The batch response text. */
//	public static final String TM_BATCH_RESPONSE_TEXT = "52.12";
	// ------------------------------------------------------
	/*
	 * Only for ADLL Good Batch
	 */
	/** The batch adll type. */
//	public static final String TM_BATCH_ADLL_TYPE = "52.13";
	/** The batch terminal application. */
	public static final String TM_BATCH_TERMINAL_APPLICATION = "52.14";
	/** The batch download phone number. */
//	public static final String TM_BATCH_DOWNLOAD_PHONE_NUMBER = "52.15";
	/** The batch terminal id number. */
//	public static final String TM_BATCH_TERMINAL_ID_NUMBER = "52.16";
	/** The batch res transmission date. */
//	public static final String TM_BATCH_RES_TRANSMISSION_DATE = "52.17";
	// ------------------------------------------------------
	/*
	 * Only for Rejected Batch
	 */
	/** The batch error type. */
//	public static final String TM_BATCH_ERROR_TYPE = "52.18";
	/** The batch error record sequence number. */
//	public static final String TM_BATCH_ERROR_RECORD_SEQUENCE_NUMBER = "52.19";
	/** The batch error record type. */
//	public static final String TM_BATCH_ERROR_RECORD_TYPE = "52.20";
	/** The batch error data field number. */
//	public static final String TM_BATCH_ERROR_DATA_FIELD_NUMBER = "52.21";
	/** The batch error data. */
//	public static final String TM_BATCH_ERROR_DATA = "52.22";

//	public static final String TM_JMS_DBCALL = "53.1";
	/** Destination Message type to insert into database */
	public static final String TM_DEST_MSG_TYPE = "53.2";
	
//	public static final String TM_PROCESS_TYPE = "60.0";

	/** Teminal location zip code to send it to gateway for transaction */
//	public static final String TM_TERMINAL_ZIP = "70.1";

	/**
	 * Terminal time zone to generate time and date it to gateway for transaction
	 */
	public static final String TM_TERMINAL_TIME_ZONE = "70.2";
	/** Terminal location State code to send it to gateway for transaction */
//	public static final String TM_TERMINAL_STATE = "70.3";

	/** Terminal location Country code to send it to gateway for transaction */
//	public static final String TM_TERMINAL_COUNTRY = "70.4";

	/** Terminal location Address code to send it to gateway for transaction */
//	public static final String TM_TERMINAL_STREET_ADDRESS = "70.5";

	/** Terminal location Location name to send it to gateway for transaction */
//	public static final String TM_TERMINAL_LOCATION_NAME = "70.6";

	/** Terminal location city to send it to gateway for transaction */
//	public static final String TM_TERMINAL_CITY = "70.7";

	/** Terminal allowable max transaction amount to validate requested amount */
//	public static final String TM_MAX_TRANSACTION_AMOUNT = "70.8";
	/**
	 * Terminal capability if EMV/non-EMV to send it to gateway for transaction
	 */
//	public static final String TM_TERMINAL_EMV_CAPABILITY = "70.9";

	/** If sanity error generate working key for some terminals */
//	public static final String TM_GENERATE_WORKING_KEY = "80.1";
	/** Key serial number to translate PIN for DUKPT PIN */
//	public static final String TM_DUKPT_KSN = "80.2";

	/** IF card holder accepted or denied DCC quotation */
//	public static final String TM_DCC_QUOTE_ACCEPTANCE = "90.0";
	/** IF card holder accepted or denied DCC quotation */
//	public static final String TM_DCC_QUOTE_RESPONSE_FROM_TERMINAL = "90.1";
	/** Currency code of card for DCC */
	public static final String TM_DCC_CARD_HOLDER_CURRENCY_CODE = "90.2";
	/** Transaction Amount in Card holder currency */
//	public static final String TM_DCC_CARD_HOLDER_TRANSACTION_AMT = "90.3";
	/** Surcharge Amount in Card holder currency */
//	public static final String TM_DCC_CARD_HOLDER_SURCHARGE_AMT = "90.4";
	/** Conversion rate for DCC */
//	public static final String TM_DCC_CONVERSION_RATE = "90.5";
	/**
	 * Settlement Transaction Amount from Network after DCC Transaction is
	 * approved
	 */
//	public static final String TM_DCC_NETWORK_CONVERSION_RATE = "90.6";
	/**
	 * Settlement Transaction Amount from Network after DCC Transaction is
	 * approved
	 */
//	public static final String TM_DCC_NETWORK_SETT_TRAN_AMT = "90.7";
	/**
	 * Settlement Surcharge Amount from Network after DCC Transaction is
	 * approved
	 */
//	public static final String TM_DCC_NETWORK_SETT_SUR_AMT = "90.8";

//	public static final String TM_ACE_RESPONSE_CODE = "100.1";
	
//	public static final String TM_TERMINAL_EMULATION = "101.2";
//	public static final String TM_TERMINAL_CONFIG_DATE_TIME = "101.3";
//	public static final String TM_TERMINAL_CONFIG_HEALTH_TIMER = "101.4";	
//	public static final String TM_TERMINAL_CONFIG_INITIATOR = "101.5";	
//	public static final String TM_TERMINAL_TOTAL_RESET = "101.6";	
//	public static final String TM_TERMINAL_MAC = "101.7";	
//	public static final String TM_TERMINAL_MAC_RESULT = "101.8";
	
//	public static final String TM_CASH_SOURCE_DATE_TIME_REFERENCE  = "102.1";	
//	public static final String TM_CASH_SOURCE_SETTLEMENT_DATE_TIME  = "102.2";	
//	public static final String TM_CASH_SOURCE_RESPONSE_TEXT= "102.3";

	
	
	
	
	// constants for internal use TransactionMap fields
	public static final String TM_SHA_NAME = "1000";
	public static final String TM_RECEIVED_SYSTEM_TIME_IN_MILLS = "1001";
	public static final String TM_REQUESTER_NAME = "1002";
	public static final String TM_RELATIVE_COUNTER = "1003";
}
