package com.efx.common.logging;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.logging.LogRecord;
import java.util.logging.Logger;

import com.efx.common.constants.TopicNameConstants;
import com.efx.common.pubsub.Publisher;
import com.efx.common.pubsub.PublisherManager;

public class EFXLogger extends Logger implements TopicNameConstants
{
	String API_LOGGING = "java.util.logging";
	String LOGGING_PACKAGE = EFXLogger.class.getPackage().getName();
	
	static Publisher pub = null;
	
	boolean useAggregation;
	
	static PublisherManager mgr = PublisherManager.getInstance();
	
	EFXLogger()
	{
		super("test", null);
	}
	
	public EFXLogger(String name, boolean useAggregation) {
		super(name, null);

		this.useAggregation = useAggregation;
		if (pub == null && useAggregation)
		{
			pub = mgr.getPublisher(LOG_TOPIC_NAME);
		}
	}

   @Override
   public void log(LogRecord record)
   {
	   alterLogRecord(record);

	   if (!useAggregation)
	   {
		   super.log(record);
	   } else {
	       try {
			   String entry = format(record);
			   pub.publish(entry);
	       } catch (Exception e) {
	           e.printStackTrace();
	       }
	   }
   }
	 
   // This method will adjust the LogRecord
   void alterLogRecord (LogRecord record)
   {
       Map<Thread,StackTraceElement[]> traces = Thread.getAllStackTraces();
       StackTraceElement[] st = traces.get(Thread.currentThread());
       boolean foundIt = false;
       int counter = 0;
       while (foundIt == false)
       {
           if (counter == st.length)
               break;
           if (st[counter].getClassName().equals(getClass().getName()))
           {
               while (st[counter].getClassName().startsWith(API_LOGGING) || st[counter].getClassName().startsWith(LOGGING_PACKAGE))
               {
                   counter++;
                   if (counter == st.length)
                       break;
               }
               break;
           }
           counter++;
       }
       if (counter < st.length)
       {
           record.setSourceMethodName(st[counter].getMethodName());
           record.setSourceClassName(st[counter].getClassName());
           record.setSequenceNumber(st[counter].getLineNumber());
       }
   }
   
   void forTestingFormatException() throws Exception
   {
	   // does nothing, used only for unit testing the format method's exception handling
   }
   
   public String format(LogRecord record) throws Exception
   {
       StringBuffer output = new StringBuffer();
       try {
    	   forTestingFormatException();
           output.append(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date().getTime()) + "  ");
           output.append(record.getLevel() + " ");
           output.append(Class.forName(record.getSourceClassName()).getSimpleName() + "." + record.getSourceMethodName() + "(" + record.getSequenceNumber() + ") : ");
           output.append(record.getMessage());
       } catch (Exception e) {
    	   // TODO - after redirecting System.out/err, this will have to be changed
           e.printStackTrace();
           return null;
       }
       return output.toString();
   }
}
