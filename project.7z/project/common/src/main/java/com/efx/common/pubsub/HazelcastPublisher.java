package com.efx.common.pubsub;

import com.efx.common.utils.HazelcastUtils;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.core.ITopic;

import lombok.Getter;

public class HazelcastPublisher implements Publisher
{
	@Getter
	String topicName;
	
	ITopic<Object> topic;
	
	static HazelcastUtils utils = null;
	
	static HazelcastInstance hazelcastInstance = null;

	HazelcastPublisher () { }
	
	public HazelcastPublisher (String topicName)
	{
		this.topicName = topicName;
		if (utils == null)
		{
			utils = HazelcastUtils.getInstance();
		}
		if (hazelcastInstance == null)
		{
			hazelcastInstance = utils.getHazelcastInstance();
		}
		topic = hazelcastInstance.getTopic(topicName);
	}
	
	@Override
	public void publish(Object value)
	{
		topic.publish(value);
	}

	@Override
	public String getTopicName() {
		// TODO Auto-generated method stub
		return null;
	}

}
