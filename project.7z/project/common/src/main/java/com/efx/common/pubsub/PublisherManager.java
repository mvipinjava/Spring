package com.efx.common.pubsub;

import java.util.HashMap;
import java.util.Map;

public class PublisherManager
{
	public static PublisherManager instance = null;
	
	Map<String, Publisher> inUsePublishers = new HashMap<String, Publisher>();
	
	PublisherManager () { }
	
	public static PublisherManager getInstance()
	{
		if (instance == null)
		{
			instance = new PublisherManager();
		}
		return instance;
	}
	
    public Publisher getPublisher(String name)
	{
    	// see if there is already a Publisher of this name in use
    	Publisher thisPublisher = inUsePublishers.get(name);
    	if (thisPublisher == null)
    	{
        	// only Hazelcast Publisher, at this time
    		thisPublisher = new HazelcastPublisher(name);
    		inUsePublishers.put(name,  thisPublisher);
    	}
    	
    	return thisPublisher;
	}
}
