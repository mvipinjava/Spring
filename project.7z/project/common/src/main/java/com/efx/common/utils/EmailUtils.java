package com.efx.common.utils;

import java.io.File;

import javax.mail.internet.MimeMessage;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.InputStreamSource;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;

public class EmailUtils
{
	static EmailUtils instance = null;
	
    JavaMailSender emailSender;
    JavaMailSenderImpl emailSenderImpl;
    
	EmailUtils (JavaMailSender emailSender)
	{
		this.emailSender = emailSender;
		this.emailSenderImpl = (JavaMailSenderImpl) emailSender;
	}
	
	void correctProtocol()
	{
	    if (emailSenderImpl.getPort() == 110)
	    {
	    	emailSenderImpl.setProtocol("pop");
	    }
	}
	public static EmailUtils getInstance(JavaMailSender emailSender)
	{
		if (instance == null)
		{
			instance = new EmailUtils(emailSender);
			instance.correctProtocol();
		}
		return instance;
	}
	
    public boolean sendMessage(String to, String subject, String text)
    {
    	boolean retval = false;
        SimpleMailMessage message = new SimpleMailMessage(); 
        message.setTo(to); 
        message.setSubject(subject); 
        message.setText(text);
        try
        {
        	emailSender.send(message);
        	retval = true;
        } catch (Exception e) {
			e.printStackTrace();
        }
        return retval;
     }
    
    public boolean sendMessageWithFileAttachment(String to, String subject, String text, String attachmentLabel, String pathToAttachment)
    {
    	InputStreamSource resource = new FileSystemResource(new File(pathToAttachment));
    	return sendMessageWithAttachment(to, subject, text, true, attachmentLabel, resource);
    }

    public boolean sendMessageWithResourceAttachment(String to, String subject, String text, String attachmentLabel, String resourceName)
    {
    	ClassPathResource resource = new ClassPathResource(resourceName);
    	return sendMessageWithAttachment(to, subject, text, false, attachmentLabel, resource);
    }

    public boolean sendMessageWithAttachment(String to, String subject, String text, boolean isFile, String attachmentLabel, Object attachment)
    {
    	boolean retval = false;
	    MimeMessage message = emailSender.createMimeMessage();
	      
	    MimeMessageHelper helper;
		try {
			helper = new MimeMessageHelper(message, true);
		    helper.setTo(to);
		    helper.setSubject(subject);
		    helper.setText(text);
		    
		    helper.addAttachment(attachmentLabel, (isFile) ? (InputStreamSource) attachment : (ClassPathResource) attachment);
		    emailSender.send(message);
		    retval = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
	    return retval;
    }
}
