package com.efx.common.utils;

import java.util.Collections;

import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;

public class SwaggerUtils
{
	static SwaggerUtils instance = null;
	
	SwaggerUtils() { }
	
	public static SwaggerUtils getInstance()
	{
		if (instance == null)
		{
			instance = new SwaggerUtils();
		}
		return instance;
	}
	
	public Docket getSwaggerDocket(String appName, String description)
	{
        return new Docket(DocumentationType.SWAGGER_2)  
                .select()                                  
                .apis(RequestHandlerSelectors.basePackage("com.efx"))              
                .paths(PathSelectors.any())                          
                .build()
                .apiInfo(apiInfo(appName, description));                                    
          }

          private ApiInfo apiInfo(String appName, String description) {
              return new ApiInfo(
                appName + " API", 
                description, 
                "0.0.1-SNAPSHOT", 
                "Terms of service URL", 
                new Contact("Brian Lantz", "www.efxfs.com", "blantz@efxfs.com"), 
                "License of API", "API license URL", Collections.emptyList());
          }
}
