package com.efx.POJOTester;

import static org.junit.jupiter.api.Assertions.*;

import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/**
 * This helper class can be used to unit test the get/set methods of JavaBean-style Value Objects.
 *  
 */
public class POJOTester
{
    /**
     * Tests the get/set methods of the specified class.
     * 
     * @param <T> the type parameter associated with the class under test
     * @param clazz the Class under test
     * @param skipThese the names of any properties that should not be tested
     * @throws IntrospectionException thrown if the Introspector.getBeanInfo() method throws this exception 
     * for the class under test
     */
    public static <T> void test(final Class<T> clazz, final String... skipThese) throws IntrospectionException
    {
        final PropertyDescriptor[] props = Introspector.getBeanInfo(clazz).getPropertyDescriptors();
        nextProp: for (PropertyDescriptor prop : props)
        {
        	String propName = prop.getName();
        	if (propName.equals("class"))
        	{
                continue nextProp;
        	}

        	// Check the list of properties that we don't want to test
            for (String skipThis : skipThese)
            {
                if (skipThis.equals(propName))
                {
                    continue nextProp;
                }
            }

            final Method getter = prop.getReadMethod();
            final Method setter = prop.getWriteMethod();
            
            if (getter != null)
            {
            	testGetter(clazz, getter, prop);
            }
            
            if (setter != null)
            {
            	testSetter(clazz, getter, setter, prop);
            }            
        }
    }
    
    static <T> void testSetter(Class<T> clazz, Method getter, Method setter, PropertyDescriptor prop)
    {
        final Class<?> returnType = getter.getReturnType();
        final Class<?>[] params = setter.getParameterTypes();
        
        if (params.length == 1 && params[0] == returnType)
        {
            try
            {
                // Build a value of the correct type to be passed to the set method
                Object value = buildValue(returnType);
                
                // Build an instance of the bean that we are testing (each property test gets a new instance)
                T bean = clazz.newInstance();
                
                // Call the set method, then check the same value comes back out of the get method
                setter.invoke(bean, value);

                Field field = clazz.getDeclaredField(prop.getName());
                field.setAccessible(true);
                final Object actualValue = field.get(bean);

                assertEquals(value, actualValue, () -> String.format("Failed while testing property %s", prop.getName()));
            } catch (Exception ex) {
                fail(() -> String.format("An exception was thrown while testing the property %s: %s", prop.getName(), ex.toString()));
            }    	
        }
    }
    
    static <T> void testGetter(Class<T> clazz, Method getter, PropertyDescriptor prop)
    {
        final Class<?> returnType = getter.getReturnType();
        try
        {
            // Build a value of the correct type to be set directly
               Object value = buildValue(returnType);
 
               // Build an instance of the bean that we are testing (each property test gets a new instance)
               T bean = clazz.newInstance();
               Field field = clazz.getDeclaredField(prop.getName());
               field.setAccessible(true);
               field.set(bean, value);

               final Object actualValue = getter.invoke(bean);
               
               assertEquals(value, actualValue, () -> String.format("Failed while testing property %s", prop.getName()));
        } catch (Exception ex) {
            fail(() -> String.format("An exception was thrown while testing the property %s: %s", prop.getName(), ex.toString()));
        }    	
    }
    
    static Object buildValue(Class<?> clazz) throws InstantiationException, IllegalAccessException, IllegalArgumentException, SecurityException, InvocationTargetException
    {
     // Check for a no-arg constructor
        final Constructor<?>[] ctrs = clazz.getConstructors();
        for (Constructor<?> ctr : ctrs)
        {
            if (ctr.getParameterTypes().length == 0)
            {
             // The class has a no-arg constructor, so just call it
                return ctr.newInstance();
            }
        }
        
     // Specific rules for common classes
        if (clazz == String.class)
        {
            return "testvalue";
            
        } else if (clazz.isArray()) {
            return Array.newInstance(clazz.getComponentType(), 1);
            
        } else if (clazz == boolean.class || clazz == Boolean.class) {
            return Boolean.TRUE;            
        } else if (clazz == int.class || clazz == Integer.class) {
            return Integer.valueOf(1);            
        } else if (clazz == long.class || clazz == Long.class) {
            return Long.valueOf(1L);            
        } else if (clazz == double.class || clazz == Double.class) {
            return Double.valueOf(1.0D);
        } else if (clazz == float.class || clazz == Float.class) {
            return Float.valueOf(1.0F);
        } else if (clazz == char.class || clazz == Character.class) {
            return Character.valueOf('Y');
        } else if (clazz.isEnum()) {
            return clazz.getEnumConstants()[0];
        } else if (clazz == List.class) {
        	return new ArrayList<Object>();
        } else {
            fail(() -> "Unable to build an instance of class " + clazz.getName() + ", please add some code to the " 
                    + POJOTester.class.getName() + " class to do this.");
            return null; // for the compiler
        }
    }

}
