package com.efx.api.session.pojos;

import java.io.Serializable;
import java.util.List;




public class LoginResponse implements Serializable
{
	private static final long serialVersionUID = 1L;

	String token;
	TermsData terms;
	PrivacyData privacy;
	List<UserPermissionData> userPermissions;
	List<AlarmData> alertTypes;
	List<GoalData> goalTypes;
	List<PhotoData> photoTypes;
	List<PermissionData> permissions;
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public TermsData getTerms() {
		return terms;
	}
	public void setTerms(TermsData terms) {
		this.terms = terms;
	}
	public PrivacyData getPrivacy() {
		return privacy;
	}
	public void setPrivacy(PrivacyData privacy) {
		this.privacy = privacy;
	}
	public List<UserPermissionData> getUserPermissions() {
		return userPermissions;
	}
	public void setUserPermissions(List<UserPermissionData> userPermissions) {
		this.userPermissions = userPermissions;
	}
	public List<AlarmData> getAlertTypes() {
		return alertTypes;
	}
	public void setAlertTypes(List<AlarmData> alertTypes) {
		this.alertTypes = alertTypes;
	}
	public List<GoalData> getGoalTypes() {
		return goalTypes;
	}
	public void setGoalTypes(List<GoalData> goalTypes) {
		this.goalTypes = goalTypes;
	}
	public List<PhotoData> getPhotoTypes() {
		return photoTypes;
	}
	public void setPhotoTypes(List<PhotoData> photoTypes) {
		this.photoTypes = photoTypes;
	}
	public List<PermissionData> getPermissions() {
		return permissions;
	}
	public void setPermissions(List<PermissionData> permissions) {
		this.permissions = permissions;
	}
	
}
